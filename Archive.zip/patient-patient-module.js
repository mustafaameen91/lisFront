(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["patient-patient-module"],{

/***/ "1aR6":
/*!************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-modal.component.js ***!
  \************************************************************************************************************************************/
/*! exports provided: IonicSelectableModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableModalComponent", function() { return IonicSelectableModalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");







const _c0 = ["searchbarComponent"];
function IonicSelectableModalComponent_ion_toolbar_1_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 12);
} if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r10.selectComponent.closeButtonTemplate);
} }
function IonicSelectableModalComponent_ion_toolbar_1_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r11.selectComponent.closeButtonText, " ");
} }
function IonicSelectableModalComponent_ion_toolbar_1_span_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 12);
} if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r12.selectComponent.titleTemplate);
} }
function IonicSelectableModalComponent_ion_toolbar_1_span_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r13.selectComponent.label, " ");
} }
function IonicSelectableModalComponent_ion_toolbar_1_Template(rf, ctx) { if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-toolbar", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-buttons", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ion-button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_toolbar_1_Template_ion_button_click_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r15); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r14.selectComponent._close(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, IonicSelectableModalComponent_ion_toolbar_1_span_3_Template, 1, 1, "span", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, IonicSelectableModalComponent_ion_toolbar_1_span_4_Template, 2, 1, "span", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, IonicSelectableModalComponent_ion_toolbar_1_span_6_Template, 1, 1, "span", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, IonicSelectableModalComponent_ion_toolbar_1_span_7_Template, 2, 1, "span", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r0.selectComponent.headerColor ? ctx_r0.selectComponent.headerColor : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("slot", ctx_r0.selectComponent.closeButtonSlot);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.selectComponent.closeButtonTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.selectComponent.closeButtonTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.selectComponent.titleTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.selectComponent.titleTemplate);
} }
function IonicSelectableModalComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 12);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r1.selectComponent.headerTemplate);
} }
function IonicSelectableModalComponent_ion_toolbar_3_ion_searchbar_1_Template(rf, ctx) { if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-searchbar", 15, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function IonicSelectableModalComponent_ion_toolbar_3_ion_searchbar_1_Template_ion_searchbar_ngModelChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r20); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r19.selectComponent._searchText = $event; })("ionChange", function IonicSelectableModalComponent_ion_toolbar_3_ion_searchbar_1_Template_ion_searchbar_ionChange_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r20); const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r21.selectComponent._filterItems(); })("ionClear", function IonicSelectableModalComponent_ion_toolbar_3_ion_searchbar_1_Template_ion_searchbar_ionClear_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r20); const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r22.selectComponent._onSearchbarClear(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r16.selectComponent._searchText)("placeholder", ctx_r16.selectComponent.searchPlaceholder)("debounce", ctx_r16.selectComponent.searchDebounce);
} }
function IonicSelectableModalComponent_ion_toolbar_3_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r17.selectComponent.messageTemplate);
} }
function IonicSelectableModalComponent_ion_toolbar_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-toolbar");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_toolbar_3_ion_searchbar_1_Template, 2, 3, "ion-searchbar", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_ion_toolbar_3_div_2_Template, 2, 1, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r2.selectComponent.canSearch);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r2.selectComponent.messageTemplate);
} }
function IonicSelectableModalComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "ion-spinner");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
const _c1 = function (a0) { return { group: a0 }; };
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_divider_1_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 26);
} if (rf & 2) {
    const group_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
    const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r27.selectComponent.groupTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c1, group_r24));
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_divider_1_ion_label_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const group_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", group_r24.text, " ");
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_divider_1_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const group_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
    const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r29.selectComponent.groupEndTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c1, group_r24));
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_divider_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-item-divider", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_divider_1_span_1_Template, 1, 4, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_divider_1_ion_label_2_Template, 2, 1, "ion-label", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_divider_1_div_3_Template, 2, 4, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r25.selectComponent.groupColor ? ctx_r25.selectComponent.groupColor : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r25.selectComponent.groupTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r25.selectComponent.groupTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r25.selectComponent.groupEndTemplate);
} }
const _c2 = function (a0, a1) { return { item: a0, isItemSelected: a1 }; };
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 26);
} if (rf & 2) {
    const item_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r34.selectComponent.itemTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c2, item_r33, ctx_r34.selectComponent._isItemSelected(item_r33)));
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_label_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r35.selectComponent._formatItem(item_r33), " ");
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r36.selectComponent.itemEndTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c2, item_r33, ctx_r36.selectComponent._isItemSelected(item_r33)));
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 26);
} if (rf & 2) {
    const item_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r37.selectComponent.itemIconTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c2, item_r33, ctx_r37.selectComponent._isItemSelected(item_r33)));
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_icon_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ion-icon", 31);
} if (rf & 2) {
    const item_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r38.selectComponent._isItemSelected(item_r33) ? "checkmark-circle" : "radio-button-off")("color", ctx_r38.selectComponent._isItemSelected(item_r33) ? "primary" : null)("slot", ctx_r38.selectComponent.itemIconSlot);
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_button_6_Template_ion_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48); const item_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit; const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r46.selectComponent._saveItem($event, item_r33); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ion-icon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_button_7_Template(rf, ctx) { if (rf & 1) {
    const _r51 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_button_7_Template_ion_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r51); const item_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit; const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r49.selectComponent._deleteItemClick($event, item_r33); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ion-icon", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
const _c3 = function (a0, a1) { return { "ionic-selectable-item-is-selected": a0, "ionic-selectable-item-is-disabled": a1 }; };
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_Template(rf, ctx) { if (rf & 1) {
    const _r53 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-item", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_Template_ion_item_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r53); const item_r33 = ctx.$implicit; const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r52.selectComponent._select(item_r33); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_span_1_Template, 1, 5, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_label_2_Template, 2, 1, "ion-label", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_div_3_Template, 2, 5, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_span_4_Template, 1, 5, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_icon_5_Template, 1, 3, "ion-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_button_6_Template, 2, 0, "ion-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_ion_button_7_Template, 2, 0, "ion-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r33 = ctx.$implicit;
    const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](9, _c3, ctx_r26.selectComponent._isItemSelected(item_r33), ctx_r26.selectComponent._isItemDisabled(item_r33)))("disabled", ctx_r26.selectComponent._isItemDisabled(item_r33));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r26.selectComponent.itemTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r26.selectComponent.itemTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r26.selectComponent.itemEndTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r26.selectComponent.itemIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r26.selectComponent.itemIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r26.selectComponent.canSaveItem);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r26.selectComponent.canDeleteItem);
} }
function IonicSelectableModalComponent_ion_list_6_ion_item_group_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-item-group", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_divider_1_Template, 4, 4, "ion-item-divider", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_ion_item_2_Template, 8, 12, "ion-item", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const group_r24 = ctx.$implicit;
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r23.selectComponent._hasGroups);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", group_r24.items);
} }
function IonicSelectableModalComponent_ion_list_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-list", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_list_6_ion_item_group_1_Template, 3, 2, "ion-item-group", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r4.selectComponent._filteredGroups);
} }
function IonicSelectableModalComponent_div_7_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 12);
} if (rf & 2) {
    const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r54.selectComponent.searchFailTemplate);
} }
function IonicSelectableModalComponent_div_7_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r55.selectComponent.searchFailText, " ");
} }
function IonicSelectableModalComponent_div_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_div_7_span_1_Template, 1, 1, "span", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_div_7_div_2_Template, 2, 1, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.selectComponent.searchFailTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r5.selectComponent.searchFailTemplate);
} }
function IonicSelectableModalComponent_ion_infinite_scroll_8_Template(rf, ctx) { if (rf & 1) {
    const _r57 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-infinite-scroll", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ionInfinite", function IonicSelectableModalComponent_ion_infinite_scroll_8_Template_ion_infinite_scroll_ionInfinite_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r57); const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r56.selectComponent._getMoreItems(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ion-infinite-scroll-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx_r6.selectComponent.hasInfiniteScroll);
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_divider_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-item-divider", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const header_r60 = ctx.$implicit;
    const ctx_r58 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r58.selectComponent.groupColor ? ctx_r58.selectComponent.groupColor : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", header_r60, " ");
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 26);
} if (rf & 2) {
    const item_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r62.selectComponent.itemTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c2, item_r61, ctx_r62.selectComponent._isItemSelected(item_r61)));
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_label_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r63.selectComponent._formatItem(item_r61), " ");
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r64 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r64.selectComponent.itemEndTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c2, item_r61, ctx_r64.selectComponent._isItemSelected(item_r61)));
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 26);
} if (rf & 2) {
    const item_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r65.selectComponent.itemIconTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](2, _c2, item_r61, ctx_r65.selectComponent._isItemSelected(item_r61)));
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_icon_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ion-icon", 31);
} if (rf & 2) {
    const item_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r66.selectComponent._isItemSelected(item_r61) ? "checkmark-circle" : "radio-button-off")("color", ctx_r66.selectComponent._isItemSelected(item_r61) ? "primary" : null)("slot", ctx_r66.selectComponent.itemIconSlot);
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r76 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_button_6_Template_ion_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r76); const item_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit; const ctx_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r74.selectComponent._saveItem($event, item_r61); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ion-icon", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_button_7_Template(rf, ctx) { if (rf & 1) {
    const _r79 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_button_7_Template_ion_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r79); const item_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit; const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r77.selectComponent._deleteItemClick($event, item_r61); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ion-icon", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_Template(rf, ctx) { if (rf & 1) {
    const _r81 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-item", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_Template_ion_item_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r81); const item_r61 = ctx.$implicit; const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r80.selectComponent._select(item_r61); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_span_1_Template, 1, 5, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_label_2_Template, 2, 1, "ion-label", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_div_3_Template, 2, 5, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_span_4_Template, 1, 5, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_icon_5_Template, 1, 3, "ion-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_button_6_Template, 2, 0, "ion-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_ion_button_7_Template, 2, 0, "ion-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r61 = ctx.$implicit;
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](9, _c3, ctx_r59.selectComponent._isItemSelected(item_r61), ctx_r59.selectComponent._isItemDisabled(item_r61)))("disabled", ctx_r59.selectComponent._isItemDisabled(item_r61));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r59.selectComponent.itemTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r59.selectComponent.itemTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r59.selectComponent.itemEndTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r59.selectComponent.itemIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r59.selectComponent.itemIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r59.selectComponent.canSaveItem);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r59.selectComponent.canDeleteItem);
} }
function IonicSelectableModalComponent_ion_virtual_scroll_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-virtual-scroll", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_divider_1_Template, 2, 2, "ion-item-divider", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_ion_virtual_scroll_9_ion_item_2_Template, 8, 12, "ion-item", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("items", ctx_r7.selectComponent._filteredGroups[0].items)("headerFn", ctx_r7.selectComponent.virtualScrollHeaderFn)("approxItemHeight", ctx_r7.selectComponent.virtualScrollApproxItemHeight);
} }
const _c4 = function (a0) { return { "top.px": a0 }; };
const _c5 = function (a0) { return { "height": a0 }; };
const _c6 = function (a0, a1) { return { item: a0, isAdd: a1 }; };
function IonicSelectableModalComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "span", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c4, ctx_r8._header.offsetHeight));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](6, _c5, ctx_r8.selectComponent._addItemTemplateFooterHeight));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r8.selectComponent.addItemTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](8, _c6, ctx_r8.selectComponent._itemToAdd, ctx_r8.selectComponent._itemToAdd === null));
} }
function IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_2_Template(rf, ctx) { if (rf & 1) {
    const _r88 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_2_Template_ion_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r88); const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r87.selectComponent._clear(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r84 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx_r84.selectComponent._selectedItems.length);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r84.selectComponent.clearButtonText, " ");
} }
function IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_3_Template(rf, ctx) { if (rf & 1) {
    const _r90 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_3_Template_ion_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r90); const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r89.selectComponent._addItemClick(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r85 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r85.selectComponent.addButtonText, " ");
} }
function IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_4_Template(rf, ctx) { if (rf & 1) {
    const _r92 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_4_Template_ion_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r92); const ctx_r91 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r91.selectComponent._confirm(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r86 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx_r86.selectComponent.isConfirmButtonEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r86.selectComponent.confirmButtonText, " ");
} }
function IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-toolbar");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_2_Template, 3, 2, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_3_Template, 3, 1, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_ion_col_4_Template, 3, 2, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r82 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r82.selectComponent.canClear);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r82.selectComponent.canAddItem);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r82.selectComponent.isMultiple || ctx_r82.selectComponent.hasConfirmButton);
} }
function IonicSelectableModalComponent_ion_footer_11_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 12);
} if (rf & 2) {
    const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r83.selectComponent.footerTemplate);
} }
const _c7 = function (a0) { return { "visibility": a0 }; };
function IonicSelectableModalComponent_ion_footer_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-footer", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_footer_11_ion_toolbar_1_Template, 5, 3, "ion-toolbar", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_ion_footer_11_div_2_Template, 1, 1, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](3, _c7, ctx_r9.selectComponent._isFooterVisible ? "initial" : "hidden"));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r9.selectComponent.footerTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r9.selectComponent.footerTemplate);
} }
class IonicSelectableModalComponent {
    constructor(navParams, _element) {
        this.navParams = navParams;
        this._element = _element;
        this._cssClass = true;
        this.selectComponent = this.navParams.get('selectComponent');
        this.selectComponent._modalComponent = this;
        this.selectComponent._selectedItems = [];
        if (!this.selectComponent._isNullOrWhiteSpace(this.selectComponent.value)) {
            if (this.selectComponent.isMultiple) {
                this.selectComponent.value.forEach(item => {
                    this.selectComponent._selectedItems.push(item);
                });
            }
            else {
                this.selectComponent._selectedItems.push(this.selectComponent.value);
            }
        }
        this.selectComponent._setItemsToConfirm(this.selectComponent._selectedItems);
    }
    get _canClearCssClass() {
        return this.selectComponent.canClear;
    }
    get _isMultipleCssClass() {
        return this.selectComponent.isMultiple;
    }
    get _isSearchingCssClass() {
        return this.selectComponent._isSearching;
    }
    get _isIos() {
        return this.selectComponent._isIos;
    }
    _isMD() {
        return this.selectComponent._isMD;
    }
    get _isAddItemTemplateVisibleCssClass() {
        return this.selectComponent._isAddItemTemplateVisible;
    }
    onResize() {
        // ion-footer inside the template might change its height when
        // device orientation changes.
        this.selectComponent._positionAddItemTemplate();
    }
    ngAfterViewInit() {
        this._header = this._element.nativeElement.querySelector('ion-header');
        if (this._searchbarComponent && this.selectComponent.shouldFocusSearchbar) {
            // Focus after a delay because focus doesn't work without it.
            setTimeout(() => {
                this._searchbarComponent.setFocus();
            }, 1000);
        }
    }
}
IonicSelectableModalComponent.ɵfac = function IonicSelectableModalComponent_Factory(t) { return new (t || IonicSelectableModalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavParams"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])); };
IonicSelectableModalComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: IonicSelectableModalComponent, selectors: [["ionic-selectable-modal"]], viewQuery: function IonicSelectableModalComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonContent"], 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonInfiniteScroll"], 1);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._content = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._searchbarComponent = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._infiniteScroll = _t.first);
    } }, hostVars: 14, hostBindings: function IonicSelectableModalComponent_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("resize", function IonicSelectableModalComponent_resize_HostBindingHandler() { return ctx.onResize(); }, false, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresolveWindow"]);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("ionic-selectable-modal", ctx._cssClass)("ionic-selectable-modal-can-clear", ctx._canClearCssClass)("ionic-selectable-modal-is-multiple", ctx._isMultipleCssClass)("ionic-selectable-modal-is-searching", ctx._isSearchingCssClass)("ionic-selectable-modal-ios", ctx._isIos)("ionic-selectable-modal-md", ctx._isMD)("ionic-selectable-modal-is-add-item-template-visible", ctx._isAddItemTemplateVisibleCssClass);
    } }, decls: 12, vars: 10, consts: [[3, "color", 4, "ngIf"], [3, "ngTemplateOutlet", 4, "ngIf"], [4, "ngIf"], ["class", "ionic-selectable-spinner", 4, "ngIf"], ["class", "ion-no-margin", 4, "ngIf"], [3, "disabled", "ionInfinite", 4, "ngIf"], ["class", "ion-no-margin", 3, "items", "headerFn", "approxItemHeight", 4, "ngIf"], ["class", "ionic-selectable-add-item-template", 3, "ngStyle", 4, "ngIf"], [3, "ngStyle", 4, "ngIf"], [3, "color"], [3, "slot"], [3, "click"], [3, "ngTemplateOutlet"], [3, "ngModel", "placeholder", "debounce", "ngModelChange", "ionChange", "ionClear", 4, "ngIf"], ["class", "ionic-selectable-message", 4, "ngIf"], [3, "ngModel", "placeholder", "debounce", "ngModelChange", "ionChange", "ionClear"], ["searchbarComponent", ""], [1, "ionic-selectable-message"], [1, "ionic-selectable-spinner"], [1, "ionic-selectable-spinner-background"], [1, "ion-no-margin"], ["class", "ionic-selectable-group", 4, "ngFor", "ngForOf"], [1, "ionic-selectable-group"], ["button", "true", "detail", "false", "class", "ionic-selectable-item", 3, "ngClass", "disabled", "click", 4, "ngFor", "ngForOf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf"], ["slot", "end", 4, "ngIf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], ["slot", "end"], ["button", "true", "detail", "false", 1, "ionic-selectable-item", 3, "ngClass", "disabled", "click"], [3, "name", "color", "slot", 4, "ngIf"], ["class", "ionic-selectable-item-button", "slot", "end", "fill", "outline", 3, "click", 4, "ngIf"], [3, "name", "color", "slot"], ["slot", "end", "fill", "outline", 1, "ionic-selectable-item-button", 3, "click"], ["slot", "icon-only", "ios", "create", "md", "create-sharp"], ["slot", "icon-only", "ios", "trash", "md", "trash-sharp"], ["class", "ion-margin", 4, "ngIf"], [1, "ion-margin"], [3, "disabled", "ionInfinite"], [1, "ion-no-margin", 3, "items", "headerFn", "approxItemHeight"], [3, "color", 4, "virtualHeader"], ["button", "true", "detail", "false", "class", "ionic-selectable-item", 3, "ngClass", "disabled", "click", 4, "virtualItem"], ["slot", "icon-only", "name", "md-create"], ["slot", "icon-only", "name", "md-trash"], [1, "ionic-selectable-add-item-template", 3, "ngStyle"], [1, "ionic-selectable-add-item-template-inner", 3, "ngStyle"], [3, "ngStyle"], ["expand", "full", 3, "disabled", "click"], ["expand", "full", 3, "click"]], template: function IonicSelectableModalComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableModalComponent_ion_toolbar_1_Template, 8, 6, "ion-toolbar", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableModalComponent_div_2_Template, 1, 1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, IonicSelectableModalComponent_ion_toolbar_3_Template, 3, 2, "ion-toolbar", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ion-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, IonicSelectableModalComponent_div_5_Template, 3, 0, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, IonicSelectableModalComponent_ion_list_6_Template, 2, 1, "ion-list", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, IonicSelectableModalComponent_div_7_Template, 3, 2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, IonicSelectableModalComponent_ion_infinite_scroll_8_Template, 2, 1, "ion-infinite-scroll", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, IonicSelectableModalComponent_ion_virtual_scroll_9_Template, 3, 3, "ion-virtual-scroll", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, IonicSelectableModalComponent_div_10_Template, 3, 11, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, IonicSelectableModalComponent_ion_footer_11_Template, 3, 5, "ion-footer", 8);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.selectComponent.headerTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectComponent.headerTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectComponent.canSearch || ctx.selectComponent.messageTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectComponent._isSearching);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.selectComponent.hasVirtualScroll && ctx.selectComponent._hasFilteredItems);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.selectComponent._hasFilteredItems);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.selectComponent.hasVirtualScroll);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectComponent.hasVirtualScroll && ctx.selectComponent._hasFilteredItems);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectComponent._isAddItemTemplateVisible);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectComponent._footerButtonsCount > 0 || ctx.selectComponent.footerTemplate);
    } }, directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonHeader"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonButtons"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonTitle"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgTemplateOutlet"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonSearchbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["TextValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonSpinner"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonList"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonItemGroup"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonItemDivider"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonLabel"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonItem"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonIcon"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonInfiniteScroll"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonInfiniteScrollContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonVirtualScroll"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["VirtualHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["VirtualItem"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgStyle"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonFooter"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonCol"]], encapsulation: 2 });
/** @nocollapse */
IonicSelectableModalComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavParams"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }
];
IonicSelectableModalComponent.propDecorators = {
    _content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonContent"],] }],
    _searchbarComponent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['searchbarComponent',] }],
    _infiniteScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonInfiniteScroll"],] }],
    _cssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-modal',] }],
    _canClearCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-modal-can-clear',] }],
    _isMultipleCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-modal-is-multiple',] }],
    _isSearchingCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-modal-is-searching',] }],
    _isIos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-modal-ios',] }],
    _isMD: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-modal-md',] }],
    _isAddItemTemplateVisibleCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-modal-is-add-item-template-visible',] }],
    onResize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"], args: ['window:resize',] }]
};
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableModalComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'ionic-selectable-modal',
                template: "<ion-header>\n  <ion-toolbar *ngIf=\"!selectComponent.headerTemplate\"\n    [color]=\"selectComponent.headerColor ? selectComponent.headerColor : null\">\n    <ion-buttons [slot]=\"selectComponent.closeButtonSlot\">\n      <ion-button (click)=\"selectComponent._close()\">\n        <span *ngIf=\"selectComponent.closeButtonTemplate\"\n          [ngTemplateOutlet]=\"selectComponent.closeButtonTemplate\">\n        </span>\n        <span *ngIf=\"!selectComponent.closeButtonTemplate\">\n          {{selectComponent.closeButtonText}}\n        </span>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>\n      <!-- Need span for for text ellipsis. -->\n      <span *ngIf=\"selectComponent.titleTemplate\"\n        [ngTemplateOutlet]=\"selectComponent.titleTemplate\">\n      </span>\n      <span *ngIf=\"!selectComponent.titleTemplate\">\n        {{selectComponent.label}}\n      </span>\n    </ion-title>\n  </ion-toolbar>\n  <div *ngIf=\"selectComponent.headerTemplate\"\n    [ngTemplateOutlet]=\"selectComponent.headerTemplate\">\n  </div>\n  <ion-toolbar\n    *ngIf=\"selectComponent.canSearch || selectComponent.messageTemplate\">\n    <ion-searchbar *ngIf=\"selectComponent.canSearch\" #searchbarComponent\n      [(ngModel)]=\"selectComponent._searchText\"\n      (ionChange)=\"selectComponent._filterItems()\"\n      (ionClear)=\"selectComponent._onSearchbarClear()\"\n      [placeholder]=\"selectComponent.searchPlaceholder\"\n      [debounce]=\"selectComponent.searchDebounce\">\n    </ion-searchbar>\n    <div class=\"ionic-selectable-message\"\n      *ngIf=\"selectComponent.messageTemplate\">\n      <div [ngTemplateOutlet]=\"selectComponent.messageTemplate\">\n      </div>\n    </div>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <div class=\"ionic-selectable-spinner\" *ngIf=\"selectComponent._isSearching\">\n    <div class=\"ionic-selectable-spinner-background\"></div>\n    <ion-spinner></ion-spinner>\n  </div>\n  <ion-list class=\"ion-no-margin\"\n    *ngIf=\"!selectComponent.hasVirtualScroll && selectComponent._hasFilteredItems\">\n    <ion-item-group *ngFor=\"let group of selectComponent._filteredGroups\"\n      class=\"ionic-selectable-group\">\n      <ion-item-divider *ngIf=\"selectComponent._hasGroups\"\n        [color]=\"selectComponent.groupColor ? selectComponent.groupColor : null\">\n        <!-- Need span for for text ellipsis. -->\n        <span *ngIf=\"selectComponent.groupTemplate\"\n          [ngTemplateOutlet]=\"selectComponent.groupTemplate\"\n          [ngTemplateOutletContext]=\"{ group: group }\">\n        </span>\n        <!-- Need ion-label for text ellipsis. -->\n        <ion-label *ngIf=\"!selectComponent.groupTemplate\">\n          {{group.text}}\n        </ion-label>\n        <div *ngIf=\"selectComponent.groupEndTemplate\" slot=\"end\">\n          <div [ngTemplateOutlet]=\"selectComponent.groupEndTemplate\"\n            [ngTemplateOutletContext]=\"{ group: group }\">\n          </div>\n        </div>\n      </ion-item-divider>\n      <ion-item button=\"true\" detail=\"false\" *ngFor=\"let item of group.items\"\n        (click)=\"selectComponent._select(item)\" class=\"ionic-selectable-item\"\n        [ngClass]=\"{\n          'ionic-selectable-item-is-selected': selectComponent._isItemSelected(item),\n          'ionic-selectable-item-is-disabled': selectComponent._isItemDisabled(item)\n        }\" [disabled]=\"selectComponent._isItemDisabled(item)\">\n        <!-- Need span for text ellipsis. -->\n        <span *ngIf=\"selectComponent.itemTemplate\"\n          [ngTemplateOutlet]=\"selectComponent.itemTemplate\"\n          [ngTemplateOutletContext]=\"{ item: item, isItemSelected: selectComponent._isItemSelected(item) }\">\n        </span>\n        <!-- Need ion-label for text ellipsis. -->\n        <ion-label *ngIf=\"!selectComponent.itemTemplate\">\n          {{selectComponent._formatItem(item)}}\n        </ion-label>\n        <div *ngIf=\"selectComponent.itemEndTemplate\" slot=\"end\">\n          <div [ngTemplateOutlet]=\"selectComponent.itemEndTemplate\"\n            [ngTemplateOutletContext]=\"{ item: item, isItemSelected: selectComponent._isItemSelected(item) }\">\n          </div>\n        </div>\n        <span *ngIf=\"selectComponent.itemIconTemplate\"\n          [ngTemplateOutlet]=\"selectComponent.itemIconTemplate\"\n          [ngTemplateOutletContext]=\"{ item: item, isItemSelected: selectComponent._isItemSelected(item) }\">\n        </span>\n        <ion-icon *ngIf=\"!selectComponent.itemIconTemplate\"\n          [name]=\"selectComponent._isItemSelected(item) ? 'checkmark-circle' : 'radio-button-off'\"\n          [color]=\"selectComponent._isItemSelected(item) ? 'primary' : null\"\n          [slot]=\"selectComponent.itemIconSlot\">\n        </ion-icon>\n        <ion-button *ngIf=\"selectComponent.canSaveItem\"\n          class=\"ionic-selectable-item-button\" slot=\"end\" fill=\"outline\"\n          (click)=\"selectComponent._saveItem($event, item)\">\n          <ion-icon slot=\"icon-only\" ios=\"create\" md=\"create-sharp\"></ion-icon>\n        </ion-button>\n        <ion-button *ngIf=\"selectComponent.canDeleteItem\"\n          class=\"ionic-selectable-item-button\" slot=\"end\" fill=\"outline\"\n          (click)=\"selectComponent._deleteItemClick($event, item)\">\n          <ion-icon slot=\"icon-only\" ios=\"trash\" md=\"trash-sharp\"></ion-icon>\n        </ion-button>\n      </ion-item>\n    </ion-item-group>\n  </ion-list>\n  <!-- Fail text should be above InfiniteScroll to avoid a gap when no items are found. -->\n  <div *ngIf=\"!selectComponent._hasFilteredItems\">\n    <span *ngIf=\"selectComponent.searchFailTemplate\"\n      [ngTemplateOutlet]=\"selectComponent.searchFailTemplate\">\n    </span>\n    <div *ngIf=\"!selectComponent.searchFailTemplate\" class=\"ion-margin\">\n      {{selectComponent.searchFailText}}\n    </div>\n  </div>\n  <ion-infinite-scroll *ngIf=\"!selectComponent.hasVirtualScroll\"\n    [disabled]=\"!selectComponent.hasInfiniteScroll\"\n    (ionInfinite)=\"selectComponent._getMoreItems()\">\n    <ion-infinite-scroll-content></ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n  <ion-virtual-scroll class=\"ion-no-margin\"\n    *ngIf=\"selectComponent.hasVirtualScroll && selectComponent._hasFilteredItems\"\n    [items]=\"selectComponent._filteredGroups[0].items\"\n    [headerFn]=\"selectComponent.virtualScrollHeaderFn\"\n    [approxItemHeight]=\"selectComponent.virtualScrollApproxItemHeight\">\n    <ion-item-divider *virtualHeader=\"let header\"\n      [color]=\"selectComponent.groupColor ? selectComponent.groupColor : null\">\n      {{header}}\n    </ion-item-divider>\n    <ion-item button=\"true\" detail=\"false\" *virtualItem=\"let item\"\n      (click)=\"selectComponent._select(item)\" class=\"ionic-selectable-item\"\n      [ngClass]=\"{\n        'ionic-selectable-item-is-selected': selectComponent._isItemSelected(item),\n        'ionic-selectable-item-is-disabled': selectComponent._isItemDisabled(item)\n      }\" [disabled]=\"selectComponent._isItemDisabled(item)\">\n      <!-- Need span for text ellipsis. -->\n      <span *ngIf=\"selectComponent.itemTemplate\"\n        [ngTemplateOutlet]=\"selectComponent.itemTemplate\"\n        [ngTemplateOutletContext]=\"{ item: item, isItemSelected: selectComponent._isItemSelected(item) }\">\n      </span>\n      <!-- Need ion-label for text ellipsis. -->\n      <ion-label *ngIf=\"!selectComponent.itemTemplate\">\n        {{selectComponent._formatItem(item)}}\n      </ion-label>\n      <div *ngIf=\"selectComponent.itemEndTemplate\" slot=\"end\">\n        <div [ngTemplateOutlet]=\"selectComponent.itemEndTemplate\"\n          [ngTemplateOutletContext]=\"{ item: item, isItemSelected: selectComponent._isItemSelected(item) }\">\n        </div>\n      </div>\n      <span *ngIf=\"selectComponent.itemIconTemplate\"\n        [ngTemplateOutlet]=\"selectComponent.itemIconTemplate\"\n        [ngTemplateOutletContext]=\"{ item: item, isItemSelected: selectComponent._isItemSelected(item) }\">\n      </span>\n      <ion-icon *ngIf=\"!selectComponent.itemIconTemplate\"\n        [name]=\"selectComponent._isItemSelected(item) ? 'checkmark-circle' : 'radio-button-off'\"\n        [color]=\"selectComponent._isItemSelected(item) ? 'primary' : null\"\n        [slot]=\"selectComponent.itemIconSlot\">\n      </ion-icon>\n      <ion-button *ngIf=\"selectComponent.canSaveItem\"\n        class=\"ionic-selectable-item-button\" slot=\"end\" fill=\"outline\"\n        (click)=\"selectComponent._saveItem($event, item)\">\n        <ion-icon slot=\"icon-only\" name=\"md-create\"></ion-icon>\n      </ion-button>\n      <ion-button *ngIf=\"selectComponent.canDeleteItem\"\n        class=\"ionic-selectable-item-button\" slot=\"end\" fill=\"outline\"\n        (click)=\"selectComponent._deleteItemClick($event, item)\">\n        <ion-icon slot=\"icon-only\" name=\"md-trash\"></ion-icon>\n      </ion-button>\n    </ion-item>\n  </ion-virtual-scroll>\n</ion-content>\n<div class=\"ionic-selectable-add-item-template\"\n  *ngIf=\"selectComponent._isAddItemTemplateVisible\"\n  [ngStyle]=\"{ 'top.px': _header.offsetHeight }\">\n  <div class=\"ionic-selectable-add-item-template-inner\"\n    [ngStyle]=\"{ 'height': selectComponent._addItemTemplateFooterHeight }\">\n    <span [ngTemplateOutlet]=\"selectComponent.addItemTemplate\"\n      [ngTemplateOutletContext]=\"{ item: selectComponent._itemToAdd, isAdd: selectComponent._itemToAdd === null }\">\n    </span>\n  </div>\n</div>\n<ion-footer\n  *ngIf=\"selectComponent._footerButtonsCount > 0 || selectComponent.footerTemplate\"\n  [ngStyle]=\"{ 'visibility': selectComponent._isFooterVisible ? 'initial' : 'hidden' }\">\n  <ion-toolbar *ngIf=\"!selectComponent.footerTemplate\">\n    <ion-row>\n      <ion-col *ngIf=\"selectComponent.canClear\">\n        <ion-button expand=\"full\" (click)=\"selectComponent._clear()\"\n          [disabled]=\"!selectComponent._selectedItems.length\">\n          {{selectComponent.clearButtonText}}\n        </ion-button>\n      </ion-col>\n      <ion-col *ngIf=\"selectComponent.canAddItem\">\n        <ion-button expand=\"full\" (click)=\"selectComponent._addItemClick()\">\n          {{selectComponent.addButtonText}}\n        </ion-button>\n      </ion-col>\n      <ion-col\n        *ngIf=\"selectComponent.isMultiple || selectComponent.hasConfirmButton\">\n        <ion-button expand=\"full\" (click)=\"selectComponent._confirm()\"\n          [disabled]=\"!selectComponent.isConfirmButtonEnabled\">\n          {{selectComponent.confirmButtonText}}\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n  <div *ngIf=\"selectComponent.footerTemplate\"\n    [ngTemplateOutlet]=\"selectComponent.footerTemplate\">\n  </div>\n</ion-footer>\n"
            }]
    }], function () { return [{ type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavParams"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }]; }, { _cssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-modal']
        }], _canClearCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-modal-can-clear']
        }], _isMultipleCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-modal-is-multiple']
        }], _isSearchingCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-modal-is-searching']
        }], _isIos: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-modal-ios']
        }], _isMD: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-modal-md']
        }], _isAddItemTemplateVisibleCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-modal-is-add-item-template-visible']
        }], onResize: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['window:resize']
        }], _content: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonContent"]]
        }], _searchbarComponent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ['searchbarComponent']
        }], _infiniteScroll: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonInfiniteScroll"]]
        }] }); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1tb2RhbC5jb21wb25lbnQuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUtbW9kYWwuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBaUIsU0FBUyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzRyxPQUFPLEVBQUUsVUFBVSxFQUFFLGlCQUFpQixFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBT3hGLE1BQU0sT0FBTyw2QkFBNkI7QUFBRyxJQTBDM0MsWUFDVSxTQUFvQixFQUNyQixRQUFvQjtBQUM3QixRQUZVLGNBQVMsR0FBVCxTQUFTLENBQVc7QUFBQyxRQUN0QixhQUFRLEdBQVIsUUFBUSxDQUFZO0FBQUMsUUFsQzlCLGNBQVMsR0FBRyxJQUFJLENBQUM7QUFDbkIsUUFtQ0ksSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ2pFLFFBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO0FBQ2hELFFBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQzdDLFFBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUMvRSxZQUFNLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUU7QUFDM0MsZ0JBQVEsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2xELG9CQUFVLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6RCxnQkFBUSxDQUFDLENBQUMsQ0FBQztBQUNYLGFBQU87QUFBQyxpQkFBSztBQUNiLGdCQUFRLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdFLGFBQU87QUFDUCxTQUFLO0FBQ0wsUUFDSSxJQUFJLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDakYsSUFBRSxDQUFDO0FBQ0gsSUFuREUsSUFDSSxpQkFBaUI7QUFBSyxRQUN4QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDO0FBQ3pDLElBQUUsQ0FBQztBQUNILElBQUUsSUFDSSxtQkFBbUI7QUFBSyxRQUMxQixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDO0FBQzNDLElBQUUsQ0FBQztBQUNILElBQUUsSUFDSSxvQkFBb0I7QUFBSyxRQUMzQixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO0FBQzdDLElBQUUsQ0FBQztBQUNILElBQUUsSUFDSSxNQUFNO0FBQUssUUFDYixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDO0FBQ3ZDLElBQUUsQ0FBQztBQUNILElBQ0UsS0FBSztBQUFLLFFBQ1IsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztBQUN0QyxJQUFFLENBQUM7QUFDSCxJQUFFLElBQ0ksaUNBQWlDO0FBQUssUUFDeEMsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLHlCQUF5QixDQUFDO0FBQzFELElBQUUsQ0FBQztBQUNILElBQ0UsUUFBUTtBQUNWLFFBQUksOERBQThEO0FBQ2xFLFFBQUksOEJBQThCO0FBQ2xDLFFBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO0FBQ3BELElBQUUsQ0FBQztBQUNILElBc0JFLGVBQWU7QUFDakIsUUFBSSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUMzRSxRQUNJLElBQUksSUFBSSxDQUFDLG1CQUFtQixJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsb0JBQW9CLEVBQUU7QUFDL0UsWUFBTSw2REFBNkQ7QUFDbkUsWUFBTSxVQUFVLENBQUMsR0FBRyxFQUFFO0FBQ3RCLGdCQUFRLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM1QyxZQUFNLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUNmLFNBQUs7QUFDTCxJQUFFLENBQUM7QUFDSDt5REE3RUMsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSx3QkFBd0Isa0JBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztvbkJBRUc7QUFBQztBQUFtQjtBQUNmLFlBUjRDLFNBQVM7QUFBSSxZQURoQyxVQUFVO0FBQUc7QUFBRztBQUFpRCx1QkFTakcsU0FBUyxTQUFDLFVBQVU7QUFDbEIsa0NBR0YsU0FBUyxTQUFDLG9CQUFvQjtBQUM1Qiw4QkFDRixTQUFTLFNBQUMsaUJBQWlCO0FBQ3pCLHdCQUNGLFdBQVcsU0FBQyw4QkFBOEI7QUFDeEMsZ0NBQ0YsV0FBVyxTQUFDLHdDQUF3QztBQUNsRCxrQ0FHRixXQUFXLFNBQUMsMENBQTBDO0FBQ3BELG1DQUdGLFdBQVcsU0FBQywyQ0FBMkM7QUFDckQscUJBR0YsV0FBVyxTQUFDLGtDQUFrQztBQUM1QyxvQkFHRixXQUFXLFNBQUMsaUNBQWlDO0FBQzNDLGdEQUdGLFdBQVcsU0FBQywyREFBMkQ7QUFDckUsdUJBR0YsWUFBWSxTQUFDLGVBQWU7QUFDM0I7Ozs7Ozg2RUF0Q29ELGNBQ3ZEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztvQkFxQ0s7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFmdGVyVmlld0luaXQsIENvbXBvbmVudCwgRWxlbWVudFJlZiwgSG9zdEJpbmRpbmcsIEhvc3RMaXN0ZW5lciwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJb25Db250ZW50LCBJb25JbmZpbml0ZVNjcm9sbCwgSW9uU2VhcmNoYmFyLCBOYXZQYXJhbXMgfSBmcm9tICdAaW9uaWMvYW5ndWxhcic7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVDb21wb25lbnQgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUuY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnaW9uaWMtc2VsZWN0YWJsZS1tb2RhbCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9pb25pYy1zZWxlY3RhYmxlLW1vZGFsLmNvbXBvbmVudC5odG1sJ1xufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVNb2RhbENvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICBAVmlld0NoaWxkKElvbkNvbnRlbnQpXG4gIF9jb250ZW50OiBJb25Db250ZW50O1xuICBfaGVhZGVyOiBIVE1MRWxlbWVudDtcbiAgc2VsZWN0Q29tcG9uZW50OiBJb25pY1NlbGVjdGFibGVDb21wb25lbnQ7XG4gIEBWaWV3Q2hpbGQoJ3NlYXJjaGJhckNvbXBvbmVudCcpXG4gIF9zZWFyY2hiYXJDb21wb25lbnQ6IElvblNlYXJjaGJhcjtcbiAgQFZpZXdDaGlsZChJb25JbmZpbml0ZVNjcm9sbClcbiAgX2luZmluaXRlU2Nyb2xsOiBJb25JbmZpbml0ZVNjcm9sbDtcbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5pb25pYy1zZWxlY3RhYmxlLW1vZGFsJylcbiAgX2Nzc0NsYXNzID0gdHJ1ZTtcbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5pb25pYy1zZWxlY3RhYmxlLW1vZGFsLWNhbi1jbGVhcicpXG4gIGdldCBfY2FuQ2xlYXJDc3NDbGFzcygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5zZWxlY3RDb21wb25lbnQuY2FuQ2xlYXI7XG4gIH1cbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5pb25pYy1zZWxlY3RhYmxlLW1vZGFsLWlzLW11bHRpcGxlJylcbiAgZ2V0IF9pc011bHRpcGxlQ3NzQ2xhc3MoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuc2VsZWN0Q29tcG9uZW50LmlzTXVsdGlwbGU7XG4gIH1cbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5pb25pYy1zZWxlY3RhYmxlLW1vZGFsLWlzLXNlYXJjaGluZycpXG4gIGdldCBfaXNTZWFyY2hpbmdDc3NDbGFzcygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5zZWxlY3RDb21wb25lbnQuX2lzU2VhcmNoaW5nO1xuICB9XG4gIEBIb3N0QmluZGluZygnY2xhc3MuaW9uaWMtc2VsZWN0YWJsZS1tb2RhbC1pb3MnKVxuICBnZXQgX2lzSW9zKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnNlbGVjdENvbXBvbmVudC5faXNJb3M7XG4gIH1cbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5pb25pYy1zZWxlY3RhYmxlLW1vZGFsLW1kJylcbiAgX2lzTUQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuc2VsZWN0Q29tcG9uZW50Ll9pc01EO1xuICB9XG4gIEBIb3N0QmluZGluZygnY2xhc3MuaW9uaWMtc2VsZWN0YWJsZS1tb2RhbC1pcy1hZGQtaXRlbS10ZW1wbGF0ZS12aXNpYmxlJylcbiAgZ2V0IF9pc0FkZEl0ZW1UZW1wbGF0ZVZpc2libGVDc3NDbGFzcygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5zZWxlY3RDb21wb25lbnQuX2lzQWRkSXRlbVRlbXBsYXRlVmlzaWJsZTtcbiAgfVxuICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJylcbiAgb25SZXNpemUoKSB7XG4gICAgLy8gaW9uLWZvb3RlciBpbnNpZGUgdGhlIHRlbXBsYXRlIG1pZ2h0IGNoYW5nZSBpdHMgaGVpZ2h0IHdoZW5cbiAgICAvLyBkZXZpY2Ugb3JpZW50YXRpb24gY2hhbmdlcy5cbiAgICB0aGlzLnNlbGVjdENvbXBvbmVudC5fcG9zaXRpb25BZGRJdGVtVGVtcGxhdGUoKTtcbiAgfVxuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgbmF2UGFyYW1zOiBOYXZQYXJhbXMsXG4gICAgcHVibGljIF9lbGVtZW50OiBFbGVtZW50UmVmLFxuICApIHtcbiAgICB0aGlzLnNlbGVjdENvbXBvbmVudCA9IHRoaXMubmF2UGFyYW1zLmdldCgnc2VsZWN0Q29tcG9uZW50Jyk7XG4gICAgdGhpcy5zZWxlY3RDb21wb25lbnQuX21vZGFsQ29tcG9uZW50ID0gdGhpcztcbiAgICB0aGlzLnNlbGVjdENvbXBvbmVudC5fc2VsZWN0ZWRJdGVtcyA9IFtdO1xuXG4gICAgaWYgKCF0aGlzLnNlbGVjdENvbXBvbmVudC5faXNOdWxsT3JXaGl0ZVNwYWNlKHRoaXMuc2VsZWN0Q29tcG9uZW50LnZhbHVlKSkge1xuICAgICAgaWYgKHRoaXMuc2VsZWN0Q29tcG9uZW50LmlzTXVsdGlwbGUpIHtcbiAgICAgICAgdGhpcy5zZWxlY3RDb21wb25lbnQudmFsdWUuZm9yRWFjaChpdGVtID0+IHtcbiAgICAgICAgICB0aGlzLnNlbGVjdENvbXBvbmVudC5fc2VsZWN0ZWRJdGVtcy5wdXNoKGl0ZW0pO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuc2VsZWN0Q29tcG9uZW50Ll9zZWxlY3RlZEl0ZW1zLnB1c2godGhpcy5zZWxlY3RDb21wb25lbnQudmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuc2VsZWN0Q29tcG9uZW50Ll9zZXRJdGVtc1RvQ29uZmlybSh0aGlzLnNlbGVjdENvbXBvbmVudC5fc2VsZWN0ZWRJdGVtcyk7XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgdGhpcy5faGVhZGVyID0gdGhpcy5fZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJ2lvbi1oZWFkZXInKTtcblxuICAgIGlmICh0aGlzLl9zZWFyY2hiYXJDb21wb25lbnQgJiYgdGhpcy5zZWxlY3RDb21wb25lbnQuc2hvdWxkRm9jdXNTZWFyY2hiYXIpIHtcbiAgICAgIC8vIEZvY3VzIGFmdGVyIGEgZGVsYXkgYmVjYXVzZSBmb2N1cyBkb2Vzbid0IHdvcmsgd2l0aG91dCBpdC5cbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLl9zZWFyY2hiYXJDb21wb25lbnQuc2V0Rm9jdXMoKTtcbiAgICAgIH0sIDEwMDApO1xuICAgIH1cbiAgfVxufVxuIl19

/***/ }),

/***/ "8Vd6":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-item-icon-template.directive.js ***!
  \*************************************************************************************************************************************************/
/*! exports provided: IonicSelectableItemIconTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemIconTemplateDirective", function() { return IonicSelectableItemIconTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableItemIconTemplateDirective {
}
IonicSelectableItemIconTemplateDirective.ɵfac = function IonicSelectableItemIconTemplateDirective_Factory(t) { return new (t || IonicSelectableItemIconTemplateDirective)(); };
IonicSelectableItemIconTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableItemIconTemplateDirective, selectors: [["", "ionicSelectableItemIconTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableItemIconTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableItemIconTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1pdGVtLWljb24tdGVtcGxhdGUuZGlyZWN0aXZlLmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL2NvbXBvbmVudHMvaW9uaWMtc2VsZWN0YWJsZS9pb25pYy1zZWxlY3RhYmxlLWl0ZW0taWNvbi10ZW1wbGF0ZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLMUMsTUFBTSxPQUFPLHdDQUF3QztBQUFHO29FQUh2RCxTQUFTLFNBQUMsa0JBQ1QsUUFBUSxFQUFFLG1DQUFtQyxjQUM5Qzs7Ozs7OzswQkFDSTtBQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tpb25pY1NlbGVjdGFibGVJdGVtSWNvblRlbXBsYXRlXSdcbn0pXG5leHBvcnQgY2xhc3MgSW9uaWNTZWxlY3RhYmxlSXRlbUljb25UZW1wbGF0ZURpcmVjdGl2ZSB7IH1cbiJdfQ==

/***/ }),

/***/ "8xsl":
/*!************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/ionic-selectable.min.js ***!
  \************************************************************************************/
/*! exports provided: IonicSelectableAddItemTemplateDirective, IonicSelectableCloseButtonTemplateDirective, IonicSelectableFooterTemplateDirective, IonicSelectableGroupEndTemplateDirective, IonicSelectableGroupTemplateDirective, IonicSelectableHeaderTemplateDirective, IonicSelectableItemEndTemplateDirective, IonicSelectableItemIconTemplateDirective, IonicSelectableItemTemplateDirective, IonicSelectableMessageTemplateDirective, IonicSelectableModalComponent, IonicSelectablePlaceholderTemplateDirective, IonicSelectableSearchFailTemplateDirective, IonicSelectableTitleTemplateDirective, IonicSelectableValueTemplateDirective, IonicSelectableIconTemplateDirective, IonicSelectableComponent, IonicSelectableModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index */ "FZGG");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableAddItemTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableAddItemTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableCloseButtonTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableCloseButtonTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableFooterTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableFooterTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableGroupEndTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableGroupEndTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableGroupTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableGroupTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableHeaderTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableHeaderTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemEndTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableItemEndTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemIconTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableItemIconTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableItemTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableMessageTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableMessageTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableModalComponent", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableModalComponent"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectablePlaceholderTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectablePlaceholderTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableSearchFailTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableSearchFailTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableTitleTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableTitleTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableValueTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableValueTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableIconTemplateDirective", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableIconTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableComponent", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableComponent"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableModule", function() { return _index__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableModule"]; });


//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS5taW4uanMiLCJzb3VyY2VzIjpbImlvbmljLXNlbGVjdGFibGUubWluLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0KmZyb21cIi4vaW5kZXhcIjsiXX0=

/***/ }),

/***/ "AKYK":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-title-template.directive.js ***!
  \*********************************************************************************************************************************************/
/*! exports provided: IonicSelectableTitleTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableTitleTemplateDirective", function() { return IonicSelectableTitleTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableTitleTemplateDirective {
}
IonicSelectableTitleTemplateDirective.ɵfac = function IonicSelectableTitleTemplateDirective_Factory(t) { return new (t || IonicSelectableTitleTemplateDirective)(); };
IonicSelectableTitleTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableTitleTemplateDirective, selectors: [["", "ionicSelectableTitleTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableTitleTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableTitleTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS10aXRsZS10ZW1wbGF0ZS5kaXJlY3RpdmUuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUtdGl0bGUtdGVtcGxhdGUuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzFDLE1BQU0sT0FBTyxxQ0FBcUM7QUFBRztpRUFIcEQsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSxnQ0FBZ0MsZUFDM0M7Ozs7Ozs7MEJBQ0k7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaW9uaWNTZWxlY3RhYmxlVGl0bGVUZW1wbGF0ZV0nLFxufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVUaXRsZVRlbXBsYXRlRGlyZWN0aXZlIHsgfVxuIl19

/***/ }),

/***/ "AMsP":
/*!*******************************************!*\
  !*** ./src/app/patient/patient.module.ts ***!
  \*******************************************/
/*! exports provided: PatientPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientPageModule", function() { return PatientPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _patient_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./patient-routing.module */ "dP2w");
/* harmony import */ var _patient_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./patient.page */ "gpqs");
/* harmony import */ var ngx_webcam__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-webcam */ "QKVY");
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ionic-selectable */ "8xsl");









let PatientPageModule = class PatientPageModule {
};
PatientPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _patient_routing_module__WEBPACK_IMPORTED_MODULE_5__["PatientPageRoutingModule"],
            ngx_webcam__WEBPACK_IMPORTED_MODULE_7__["WebcamModule"],
            ionic_selectable__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableModule"]
        ],
        declarations: [_patient_page__WEBPACK_IMPORTED_MODULE_6__["PatientPage"]]
    })
], PatientPageModule);



/***/ }),

/***/ "AYeB":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-group-template.directive.js ***!
  \*********************************************************************************************************************************************/
/*! exports provided: IonicSelectableGroupTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableGroupTemplateDirective", function() { return IonicSelectableGroupTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableGroupTemplateDirective {
}
IonicSelectableGroupTemplateDirective.ɵfac = function IonicSelectableGroupTemplateDirective_Factory(t) { return new (t || IonicSelectableGroupTemplateDirective)(); };
IonicSelectableGroupTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableGroupTemplateDirective, selectors: [["", "ionicSelectableGroupTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableGroupTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableGroupTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1ncm91cC10ZW1wbGF0ZS5kaXJlY3RpdmUuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUtZ3JvdXAtdGVtcGxhdGUuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzFDLE1BQU0sT0FBTyxxQ0FBcUM7QUFBRztpRUFIcEQsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSxnQ0FBZ0MsZUFDM0M7Ozs7Ozs7MEJBQ0k7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaW9uaWNTZWxlY3RhYmxlR3JvdXBUZW1wbGF0ZV0nLFxufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVHcm91cFRlbXBsYXRlRGlyZWN0aXZlIHsgfVxuIl19

/***/ }),

/***/ "CH/f":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable.module.js ***!
  \***************************************************************************************************************************/
/*! exports provided: IonicSelectableAddItemTemplateDirective, IonicSelectableCloseButtonTemplateDirective, IonicSelectableFooterTemplateDirective, IonicSelectableGroupEndTemplateDirective, IonicSelectableGroupTemplateDirective, IonicSelectableHeaderTemplateDirective, IonicSelectableItemEndTemplateDirective, IonicSelectableItemIconTemplateDirective, IonicSelectableItemTemplateDirective, IonicSelectableMessageTemplateDirective, IonicSelectableModalComponent, IonicSelectablePlaceholderTemplateDirective, IonicSelectableSearchFailTemplateDirective, IonicSelectableTitleTemplateDirective, IonicSelectableValueTemplateDirective, IonicSelectableIconTemplateDirective, IonicSelectableComponent, IonicSelectableModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableModule", function() { return IonicSelectableModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ionic-selectable-add-item-template.directive */ "TnqW");
/* harmony import */ var _ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ionic-selectable-close-button-template.directive */ "J7sm");
/* harmony import */ var _ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ionic-selectable-footer-template.directive */ "Ys55");
/* harmony import */ var _ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ionic-selectable-group-end-template.directive */ "VqCF");
/* harmony import */ var _ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ionic-selectable-group-template.directive */ "AYeB");
/* harmony import */ var _ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./ionic-selectable-header-template.directive */ "FdPp");
/* harmony import */ var _ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ionic-selectable-item-end-template.directive */ "R7F3");
/* harmony import */ var _ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ionic-selectable-item-icon-template.directive */ "8Vd6");
/* harmony import */ var _ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ionic-selectable-item-template.directive */ "j+ev");
/* harmony import */ var _ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ionic-selectable-message-template.directive */ "t6yK");
/* harmony import */ var _ionic_selectable_modal_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./ionic-selectable-modal.component */ "1aR6");
/* harmony import */ var _ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./ionic-selectable-placeholder-template.directive */ "kNd2");
/* harmony import */ var _ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./ionic-selectable-search-fail-template.directive */ "GL5m");
/* harmony import */ var _ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./ionic-selectable-title-template.directive */ "AKYK");
/* harmony import */ var _ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./ionic-selectable-value-template.directive */ "qPfB");
/* harmony import */ var _ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./ionic-selectable-icon-template.directive */ "UY7p");
/* harmony import */ var _ionic_selectable_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./ionic-selectable.component */ "JmBq");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableAddItemTemplateDirective", function() { return _ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_4__["IonicSelectableAddItemTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableCloseButtonTemplateDirective", function() { return _ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_5__["IonicSelectableCloseButtonTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableFooterTemplateDirective", function() { return _ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_6__["IonicSelectableFooterTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableGroupEndTemplateDirective", function() { return _ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_7__["IonicSelectableGroupEndTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableGroupTemplateDirective", function() { return _ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableGroupTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableHeaderTemplateDirective", function() { return _ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_9__["IonicSelectableHeaderTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemEndTemplateDirective", function() { return _ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_10__["IonicSelectableItemEndTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemIconTemplateDirective", function() { return _ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_11__["IonicSelectableItemIconTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemTemplateDirective", function() { return _ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_12__["IonicSelectableItemTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableMessageTemplateDirective", function() { return _ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_13__["IonicSelectableMessageTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableModalComponent", function() { return _ionic_selectable_modal_component__WEBPACK_IMPORTED_MODULE_14__["IonicSelectableModalComponent"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectablePlaceholderTemplateDirective", function() { return _ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_15__["IonicSelectablePlaceholderTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableSearchFailTemplateDirective", function() { return _ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_16__["IonicSelectableSearchFailTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableTitleTemplateDirective", function() { return _ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_17__["IonicSelectableTitleTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableValueTemplateDirective", function() { return _ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_18__["IonicSelectableValueTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableIconTemplateDirective", function() { return _ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_19__["IonicSelectableIconTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableComponent", function() { return _ionic_selectable_component__WEBPACK_IMPORTED_MODULE_20__["IonicSelectableComponent"]; });








































const components = [_ionic_selectable_component__WEBPACK_IMPORTED_MODULE_20__["IonicSelectableComponent"], _ionic_selectable_modal_component__WEBPACK_IMPORTED_MODULE_14__["IonicSelectableModalComponent"]], directives = [
    _ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_18__["IonicSelectableValueTemplateDirective"],
    _ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_12__["IonicSelectableItemTemplateDirective"],
    _ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_10__["IonicSelectableItemEndTemplateDirective"],
    _ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_17__["IonicSelectableTitleTemplateDirective"],
    _ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_15__["IonicSelectablePlaceholderTemplateDirective"],
    _ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_13__["IonicSelectableMessageTemplateDirective"],
    _ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableGroupTemplateDirective"],
    _ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_7__["IonicSelectableGroupEndTemplateDirective"],
    _ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_5__["IonicSelectableCloseButtonTemplateDirective"],
    _ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_16__["IonicSelectableSearchFailTemplateDirective"],
    _ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_4__["IonicSelectableAddItemTemplateDirective"],
    _ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_6__["IonicSelectableFooterTemplateDirective"],
    _ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_9__["IonicSelectableHeaderTemplateDirective"],
    _ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_11__["IonicSelectableItemIconTemplateDirective"],
    _ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_19__["IonicSelectableIconTemplateDirective"]
];
class IonicSelectableModule {
}
IonicSelectableModule.ɵfac = function IonicSelectableModule_Factory(t) { return new (t || IonicSelectableModule)(); };
IonicSelectableModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: IonicSelectableModule });
IonicSelectableModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](IonicSelectableModule, { declarations: function () { return [_ionic_selectable_component__WEBPACK_IMPORTED_MODULE_20__["IonicSelectableComponent"], _ionic_selectable_modal_component__WEBPACK_IMPORTED_MODULE_14__["IonicSelectableModalComponent"], _ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_18__["IonicSelectableValueTemplateDirective"],
        _ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_12__["IonicSelectableItemTemplateDirective"],
        _ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_10__["IonicSelectableItemEndTemplateDirective"],
        _ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_17__["IonicSelectableTitleTemplateDirective"],
        _ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_15__["IonicSelectablePlaceholderTemplateDirective"],
        _ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_13__["IonicSelectableMessageTemplateDirective"],
        _ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableGroupTemplateDirective"],
        _ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_7__["IonicSelectableGroupEndTemplateDirective"],
        _ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_5__["IonicSelectableCloseButtonTemplateDirective"],
        _ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_16__["IonicSelectableSearchFailTemplateDirective"],
        _ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_4__["IonicSelectableAddItemTemplateDirective"],
        _ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_6__["IonicSelectableFooterTemplateDirective"],
        _ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_9__["IonicSelectableHeaderTemplateDirective"],
        _ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_11__["IonicSelectableItemIconTemplateDirective"],
        _ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_19__["IonicSelectableIconTemplateDirective"]]; }, imports: function () { return [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"]]; }, exports: function () { return [_ionic_selectable_component__WEBPACK_IMPORTED_MODULE_20__["IonicSelectableComponent"], _ionic_selectable_modal_component__WEBPACK_IMPORTED_MODULE_14__["IonicSelectableModalComponent"], _ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_18__["IonicSelectableValueTemplateDirective"],
        _ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_12__["IonicSelectableItemTemplateDirective"],
        _ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_10__["IonicSelectableItemEndTemplateDirective"],
        _ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_17__["IonicSelectableTitleTemplateDirective"],
        _ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_15__["IonicSelectablePlaceholderTemplateDirective"],
        _ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_13__["IonicSelectableMessageTemplateDirective"],
        _ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableGroupTemplateDirective"],
        _ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_7__["IonicSelectableGroupEndTemplateDirective"],
        _ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_5__["IonicSelectableCloseButtonTemplateDirective"],
        _ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_16__["IonicSelectableSearchFailTemplateDirective"],
        _ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_4__["IonicSelectableAddItemTemplateDirective"],
        _ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_6__["IonicSelectableFooterTemplateDirective"],
        _ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_9__["IonicSelectableHeaderTemplateDirective"],
        _ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_11__["IonicSelectableItemIconTemplateDirective"],
        _ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_19__["IonicSelectableIconTemplateDirective"]]; } }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](IonicSelectableModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
                imports: [
                    _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                    _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"]
                ],
                declarations: [
                    ...components,
                    ...directives
                ],
                exports: [
                    ...components,
                    ...directives
                ],
                entryComponents: components
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS5tb2R1bGUuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUM3QyxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDN0MsT0FBTyxFQUFFLHVDQUF1QyxFQUFFLE1BQU0sZ0RBQWdELENBQUM7QUFDekcsT0FBTyxFQUFFLDJDQUEyQyxFQUFFLE1BQU0sb0RBQW9ELENBQUM7QUFDakgsT0FBTyxFQUFFLHNDQUFzQyxFQUFFLE1BQU0sOENBQThDLENBQUM7QUFDdEcsT0FBTyxFQUFFLHdDQUF3QyxFQUFFLE1BQU0saURBQWlELENBQUM7QUFDM0csT0FBTyxFQUFFLHFDQUFxQyxFQUFFLE1BQU0sNkNBQTZDLENBQUM7QUFDcEcsT0FBTyxFQUFFLHNDQUFzQyxFQUFFLE1BQU0sOENBQThDLENBQUM7QUFDdEcsT0FBTyxFQUFFLHVDQUF1QyxFQUFFLE1BQU0sZ0RBQWdELENBQUM7QUFDekcsT0FBTyxFQUFFLHdDQUF3QyxFQUFFLE1BQU0saURBQWlELENBQUM7QUFDM0csT0FBTyxFQUFFLG9DQUFvQyxFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFDbEcsT0FBTyxFQUFFLHVDQUF1QyxFQUFFLE1BQU0sK0NBQStDLENBQUM7QUFDeEcsT0FBTyxFQUFFLDZCQUE2QixFQUFFLE1BQU0sb0NBQW9DLENBQUM7QUFDbkYsT0FBTyxFQUFFLDJDQUEyQyxFQUFFLE1BQU0sbURBQW1ELENBQUM7QUFDaEgsT0FBTyxFQUFFLDBDQUEwQyxFQUFFLE1BQU0sbURBQW1ELENBQUM7QUFDL0csT0FBTyxFQUFFLHFDQUFxQyxFQUFFLE1BQU0sNkNBQTZDLENBQUM7QUFDcEcsT0FBTyxFQUFFLHFDQUFxQyxFQUFFLE1BQU0sNkNBQTZDLENBQUM7QUFDcEcsT0FBTyxFQUFFLG9DQUFvQyxFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFDbEcsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sOEJBQThCLENBQUM7O0FBQ3hFLE9BQU8sRUFBRSx1Q0FBdUMsRUFBRSxNQUFNLGdEQUFnRCxDQUFDO0FBQ3pHLE9BQU8sRUFBRSwyQ0FBMkMsRUFBRSxNQUFNLG9EQUFvRCxDQUFDO0FBQ2pILE9BQU8sRUFBRSxzQ0FBc0MsRUFBRSxNQUFNLDhDQUE4QyxDQUFDO0FBQ3RHLE9BQU8sRUFBRSx3Q0FBd0MsRUFBRSxNQUFNLGlEQUFpRCxDQUFDO0FBQzNHLE9BQU8sRUFBRSxxQ0FBcUMsRUFBRSxNQUFNLDZDQUE2QyxDQUFDO0FBQ3BHLE9BQU8sRUFBRSxzQ0FBc0MsRUFBRSxNQUFNLDhDQUE4QyxDQUFDO0FBQ3RHLE9BQU8sRUFBRSx1Q0FBdUMsRUFBRSxNQUFNLGdEQUFnRCxDQUFDO0FBQ3pHLE9BQU8sRUFBRSx3Q0FBd0MsRUFBRSxNQUFNLGlEQUFpRCxDQUFDO0FBQzNHLE9BQU8sRUFBRSxvQ0FBb0MsRUFBRSxNQUFNLDRDQUE0QyxDQUFDO0FBQ2xHLE9BQU8sRUFBRSx1Q0FBdUMsRUFBRSxNQUFNLCtDQUErQyxDQUFDO0FBQ3hHLE9BQU8sRUFBRSw2QkFBNkIsRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ25GLE9BQU8sRUFBRSwyQ0FBMkMsRUFBRSxNQUFNLG1EQUFtRCxDQUFDO0FBQ2hILE9BQU8sRUFBRSwwQ0FBMEMsRUFBRSxNQUFNLG1EQUFtRCxDQUFDO0FBQy9HLE9BQU8sRUFBRSxxQ0FBcUMsRUFBRSxNQUFNLDZDQUE2QyxDQUFDO0FBQ3BHLE9BQU8sRUFBRSxxQ0FBcUMsRUFBRSxNQUFNLDZDQUE2QyxDQUFDO0FBQ3BHLE9BQU8sRUFBRSxvQ0FBb0MsRUFBRSxNQUFNLDRDQUE0QyxDQUFDO0FBQ2xHLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBRXhFLE1BQU0sVUFBVSxHQUFHLENBQUMsd0JBQXdCLEVBQUUsNkJBQTZCLENBQUMsRUFDMUUsVUFBVSxHQUFHO0FBQ2YsSUFBSSxxQ0FBcUM7QUFDekMsSUFBSSxvQ0FBb0M7QUFDeEMsSUFBSSx1Q0FBdUM7QUFDM0MsSUFBSSxxQ0FBcUM7QUFDekMsSUFBSSwyQ0FBMkM7QUFDL0MsSUFBSSx1Q0FBdUM7QUFDM0MsSUFBSSxxQ0FBcUM7QUFDekMsSUFBSSx3Q0FBd0M7QUFDNUMsSUFBSSwyQ0FBMkM7QUFDL0MsSUFBSSwwQ0FBMEM7QUFDOUMsSUFBSSx1Q0FBdUM7QUFDM0MsSUFBSSxzQ0FBc0M7QUFDMUMsSUFBSSxzQ0FBc0M7QUFDMUMsSUFBSSx3Q0FBd0M7QUFDNUMsSUFBSSxvQ0FBb0M7QUFDeEMsQ0FBRyxDQUFDO0FBa0JKLE1BQU0sT0FBTyxxQkFBcUI7QUFBRztpREFoQnBDLFFBQVEsU0FBQyxrQkFDUixPQUFPLEVBQUUsc0JBQ1A7UUFBWSxzQkFDWixXQUFXLHNCQUNYLFdBQVc7S0FDWixrQkFDRCxZQUFZLEVBQUUsc0JBQ1osR0FBRztLQUFVO0NBQ2IsR0FBRyxVQUFVO09BQ2Q7Q0FDRCxPQUFPLEVBQUU7aUJBQ1AsR0FBRyxVQUFVLHNCQUNiLEdBQUcsVUFBVSxrQkFDZCxrQkFDRCxlQUFlLEVBQUUsVUFBVSxjQUM1Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFDSTtBQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IElvbmljTW9kdWxlIH0gZnJvbSAnQGlvbmljL2FuZ3VsYXInO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlQWRkSXRlbVRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWFkZC1pdGVtLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVDbG9zZUJ1dHRvblRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWNsb3NlLWJ1dHRvbi10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlRm9vdGVyVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtZm9vdGVyLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVHcm91cEVuZFRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWdyb3VwLWVuZC10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlR3JvdXBUZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1ncm91cC10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlSGVhZGVyVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaGVhZGVyLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVJdGVtRW5kVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaXRlbS1lbmQtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZUl0ZW1JY29uVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaXRlbS1pY29uLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVJdGVtVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaXRlbS10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlTWVzc2FnZVRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLW1lc3NhZ2UtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZU1vZGFsQ29tcG9uZW50IH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLW1vZGFsLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVQbGFjZWhvbGRlclRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLXBsYWNlaG9sZGVyLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVTZWFyY2hGYWlsVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtc2VhcmNoLWZhaWwtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZVRpdGxlVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtdGl0bGUtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZVZhbHVlVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtdmFsdWUtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZUljb25UZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1pY29uLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVDb21wb25lbnQgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUuY29tcG9uZW50JztcbmV4cG9ydCB7IElvbmljU2VsZWN0YWJsZUFkZEl0ZW1UZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1hZGQtaXRlbS10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuZXhwb3J0IHsgSW9uaWNTZWxlY3RhYmxlQ2xvc2VCdXR0b25UZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1jbG9zZS1idXR0b24tdGVtcGxhdGUuZGlyZWN0aXZlJztcbmV4cG9ydCB7IElvbmljU2VsZWN0YWJsZUZvb3RlclRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWZvb3Rlci10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuZXhwb3J0IHsgSW9uaWNTZWxlY3RhYmxlR3JvdXBFbmRUZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1ncm91cC1lbmQtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmV4cG9ydCB7IElvbmljU2VsZWN0YWJsZUdyb3VwVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtZ3JvdXAtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmV4cG9ydCB7IElvbmljU2VsZWN0YWJsZUhlYWRlclRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWhlYWRlci10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuZXhwb3J0IHsgSW9uaWNTZWxlY3RhYmxlSXRlbUVuZFRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWl0ZW0tZW5kLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5leHBvcnQgeyBJb25pY1NlbGVjdGFibGVJdGVtSWNvblRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWl0ZW0taWNvbi10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuZXhwb3J0IHsgSW9uaWNTZWxlY3RhYmxlSXRlbVRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWl0ZW0tdGVtcGxhdGUuZGlyZWN0aXZlJztcbmV4cG9ydCB7IElvbmljU2VsZWN0YWJsZU1lc3NhZ2VUZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1tZXNzYWdlLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5leHBvcnQgeyBJb25pY1NlbGVjdGFibGVNb2RhbENvbXBvbmVudCB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1tb2RhbC5jb21wb25lbnQnO1xuZXhwb3J0IHsgSW9uaWNTZWxlY3RhYmxlUGxhY2Vob2xkZXJUZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1wbGFjZWhvbGRlci10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuZXhwb3J0IHsgSW9uaWNTZWxlY3RhYmxlU2VhcmNoRmFpbFRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLXNlYXJjaC1mYWlsLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5leHBvcnQgeyBJb25pY1NlbGVjdGFibGVUaXRsZVRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLXRpdGxlLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5leHBvcnQgeyBJb25pY1NlbGVjdGFibGVWYWx1ZVRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLXZhbHVlLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5leHBvcnQgeyBJb25pY1NlbGVjdGFibGVJY29uVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaWNvbi10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuZXhwb3J0IHsgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50IH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLmNvbXBvbmVudCc7XG5cbmNvbnN0IGNvbXBvbmVudHMgPSBbSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50LCBJb25pY1NlbGVjdGFibGVNb2RhbENvbXBvbmVudF0sXG4gIGRpcmVjdGl2ZXMgPSBbXG4gICAgSW9uaWNTZWxlY3RhYmxlVmFsdWVUZW1wbGF0ZURpcmVjdGl2ZSxcbiAgICBJb25pY1NlbGVjdGFibGVJdGVtVGVtcGxhdGVEaXJlY3RpdmUsXG4gICAgSW9uaWNTZWxlY3RhYmxlSXRlbUVuZFRlbXBsYXRlRGlyZWN0aXZlLFxuICAgIElvbmljU2VsZWN0YWJsZVRpdGxlVGVtcGxhdGVEaXJlY3RpdmUsXG4gICAgSW9uaWNTZWxlY3RhYmxlUGxhY2Vob2xkZXJUZW1wbGF0ZURpcmVjdGl2ZSxcbiAgICBJb25pY1NlbGVjdGFibGVNZXNzYWdlVGVtcGxhdGVEaXJlY3RpdmUsXG4gICAgSW9uaWNTZWxlY3RhYmxlR3JvdXBUZW1wbGF0ZURpcmVjdGl2ZSxcbiAgICBJb25pY1NlbGVjdGFibGVHcm91cEVuZFRlbXBsYXRlRGlyZWN0aXZlLFxuICAgIElvbmljU2VsZWN0YWJsZUNsb3NlQnV0dG9uVGVtcGxhdGVEaXJlY3RpdmUsXG4gICAgSW9uaWNTZWxlY3RhYmxlU2VhcmNoRmFpbFRlbXBsYXRlRGlyZWN0aXZlLFxuICAgIElvbmljU2VsZWN0YWJsZUFkZEl0ZW1UZW1wbGF0ZURpcmVjdGl2ZSxcbiAgICBJb25pY1NlbGVjdGFibGVGb290ZXJUZW1wbGF0ZURpcmVjdGl2ZSxcbiAgICBJb25pY1NlbGVjdGFibGVIZWFkZXJUZW1wbGF0ZURpcmVjdGl2ZSxcbiAgICBJb25pY1NlbGVjdGFibGVJdGVtSWNvblRlbXBsYXRlRGlyZWN0aXZlLFxuICAgIElvbmljU2VsZWN0YWJsZUljb25UZW1wbGF0ZURpcmVjdGl2ZVxuICBdO1xuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgQ29tbW9uTW9kdWxlLFxuICAgIEZvcm1zTW9kdWxlLFxuICAgIElvbmljTW9kdWxlXG4gIF0sXG4gIGRlY2xhcmF0aW9uczogW1xuICAgIC4uLmNvbXBvbmVudHMsXG4gICAgLi4uZGlyZWN0aXZlc1xuICBdLFxuICBleHBvcnRzOiBbXG4gICAgLi4uY29tcG9uZW50cyxcbiAgICAuLi5kaXJlY3RpdmVzXG4gIF0sXG4gIGVudHJ5Q29tcG9uZW50czogY29tcG9uZW50c1xufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVNb2R1bGUgeyB9XG4iXX0=

/***/ }),

/***/ "FZGG":
/*!*********************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/index.js ***!
  \*********************************************************************/
/*! exports provided: IonicSelectableAddItemTemplateDirective, IonicSelectableCloseButtonTemplateDirective, IonicSelectableFooterTemplateDirective, IonicSelectableGroupEndTemplateDirective, IonicSelectableGroupTemplateDirective, IonicSelectableHeaderTemplateDirective, IonicSelectableItemEndTemplateDirective, IonicSelectableItemIconTemplateDirective, IonicSelectableItemTemplateDirective, IonicSelectableMessageTemplateDirective, IonicSelectableModalComponent, IonicSelectablePlaceholderTemplateDirective, IonicSelectableSearchFailTemplateDirective, IonicSelectableTitleTemplateDirective, IonicSelectableValueTemplateDirective, IonicSelectableIconTemplateDirective, IonicSelectableComponent, IonicSelectableModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/app/components/ionic-selectable/ionic-selectable.module */ "CH/f");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableAddItemTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableAddItemTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableCloseButtonTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableCloseButtonTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableFooterTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableFooterTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableGroupEndTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableGroupEndTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableGroupTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableGroupTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableHeaderTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableHeaderTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemEndTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableItemEndTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemIconTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableItemIconTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableItemTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableMessageTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableMessageTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableModalComponent", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableModalComponent"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectablePlaceholderTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectablePlaceholderTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableSearchFailTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableSearchFailTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableTitleTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableTitleTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableValueTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableValueTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableIconTemplateDirective", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableIconTemplateDirective"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableComponent", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableComponent"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableModule", function() { return _src_app_components_ionic_selectable_ionic_selectable_module__WEBPACK_IMPORTED_MODULE_0__["IonicSelectableModule"]; });


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxjQUFjLCtEQUErRCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0ICogZnJvbSAnLi9zcmMvYXBwL2NvbXBvbmVudHMvaW9uaWMtc2VsZWN0YWJsZS9pb25pYy1zZWxlY3RhYmxlLm1vZHVsZSc7XG5cbiJdfQ==

/***/ }),

/***/ "FdPp":
/*!**********************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-header-template.directive.js ***!
  \**********************************************************************************************************************************************/
/*! exports provided: IonicSelectableHeaderTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableHeaderTemplateDirective", function() { return IonicSelectableHeaderTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableHeaderTemplateDirective {
}
IonicSelectableHeaderTemplateDirective.ɵfac = function IonicSelectableHeaderTemplateDirective_Factory(t) { return new (t || IonicSelectableHeaderTemplateDirective)(); };
IonicSelectableHeaderTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableHeaderTemplateDirective, selectors: [["", "ionicSelectableHeaderTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableHeaderTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableHeaderTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1oZWFkZXItdGVtcGxhdGUuZGlyZWN0aXZlLmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL2NvbXBvbmVudHMvaW9uaWMtc2VsZWN0YWJsZS9pb25pYy1zZWxlY3RhYmxlLWhlYWRlci10ZW1wbGF0ZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLMUMsTUFBTSxPQUFPLHNDQUFzQztBQUFHO2tFQUhyRCxTQUFTLFNBQUMsa0JBQ1QsUUFBUSxFQUFFLGlDQUFpQyxlQUM1Qzs7Ozs7OzswQkFDSTtBQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tpb25pY1NlbGVjdGFibGVIZWFkZXJUZW1wbGF0ZV0nLFxufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVIZWFkZXJUZW1wbGF0ZURpcmVjdGl2ZSB7IH1cbiJdfQ==

/***/ }),

/***/ "GL5m":
/*!***************************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-search-fail-template.directive.js ***!
  \***************************************************************************************************************************************************/
/*! exports provided: IonicSelectableSearchFailTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableSearchFailTemplateDirective", function() { return IonicSelectableSearchFailTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableSearchFailTemplateDirective {
}
IonicSelectableSearchFailTemplateDirective.ɵfac = function IonicSelectableSearchFailTemplateDirective_Factory(t) { return new (t || IonicSelectableSearchFailTemplateDirective)(); };
IonicSelectableSearchFailTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableSearchFailTemplateDirective, selectors: [["", "ionicSelectableSearchFailTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableSearchFailTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableSearchFailTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1zZWFyY2gtZmFpbC10ZW1wbGF0ZS5kaXJlY3RpdmUuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUtc2VhcmNoLWZhaWwtdGVtcGxhdGUuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzFDLE1BQU0sT0FBTywwQ0FBMEM7QUFBRztzRUFIekQsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSxxQ0FBcUMsZUFDaEQ7Ozs7Ozs7MEJBQ0k7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaW9uaWNTZWxlY3RhYmxlU2VhcmNoRmFpbFRlbXBsYXRlXScsXG59KVxuZXhwb3J0IGNsYXNzIElvbmljU2VsZWN0YWJsZVNlYXJjaEZhaWxUZW1wbGF0ZURpcmVjdGl2ZSB7IH1cbiJdfQ==

/***/ }),

/***/ "J7sm":
/*!****************************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-close-button-template.directive.js ***!
  \****************************************************************************************************************************************************/
/*! exports provided: IonicSelectableCloseButtonTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableCloseButtonTemplateDirective", function() { return IonicSelectableCloseButtonTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableCloseButtonTemplateDirective {
}
IonicSelectableCloseButtonTemplateDirective.ɵfac = function IonicSelectableCloseButtonTemplateDirective_Factory(t) { return new (t || IonicSelectableCloseButtonTemplateDirective)(); };
IonicSelectableCloseButtonTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableCloseButtonTemplateDirective, selectors: [["", "ionicSelectableCloseButtonTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableCloseButtonTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableCloseButtonTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1jbG9zZS1idXR0b24tdGVtcGxhdGUuZGlyZWN0aXZlLmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL2NvbXBvbmVudHMvaW9uaWMtc2VsZWN0YWJsZS9pb25pYy1zZWxlY3RhYmxlLWNsb3NlLWJ1dHRvbi10ZW1wbGF0ZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLMUMsTUFBTSxPQUFPLDJDQUEyQztBQUFHO3VFQUgxRCxTQUFTLFNBQUMsa0JBQ1QsUUFBUSxFQUFFLHNDQUFzQyxlQUNqRDs7Ozs7OzswQkFDSTtBQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tpb25pY1NlbGVjdGFibGVDbG9zZUJ1dHRvblRlbXBsYXRlXScsXG59KVxuZXhwb3J0IGNsYXNzIElvbmljU2VsZWN0YWJsZUNsb3NlQnV0dG9uVGVtcGxhdGVEaXJlY3RpdmUgeyB9XG4iXX0=

/***/ }),

/***/ "JmBq":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable.component.js ***!
  \******************************************************************************************************************************/
/*! exports provided: IonicSelectableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableComponent", function() { return IonicSelectableComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ionic-selectable-add-item-template.directive */ "TnqW");
/* harmony import */ var _ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ionic-selectable-close-button-template.directive */ "J7sm");
/* harmony import */ var _ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ionic-selectable-footer-template.directive */ "Ys55");
/* harmony import */ var _ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ionic-selectable-group-end-template.directive */ "VqCF");
/* harmony import */ var _ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ionic-selectable-group-template.directive */ "AYeB");
/* harmony import */ var _ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ionic-selectable-header-template.directive */ "FdPp");
/* harmony import */ var _ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./ionic-selectable-item-end-template.directive */ "R7F3");
/* harmony import */ var _ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ionic-selectable-item-icon-template.directive */ "8Vd6");
/* harmony import */ var _ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ionic-selectable-item-template.directive */ "j+ev");
/* harmony import */ var _ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ionic-selectable-message-template.directive */ "t6yK");
/* harmony import */ var _ionic_selectable_modal_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ionic-selectable-modal.component */ "1aR6");
/* harmony import */ var _ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./ionic-selectable-placeholder-template.directive */ "kNd2");
/* harmony import */ var _ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./ionic-selectable-search-fail-template.directive */ "GL5m");
/* harmony import */ var _ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./ionic-selectable-title-template.directive */ "AKYK");
/* harmony import */ var _ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./ionic-selectable-value-template.directive */ "qPfB");
/* harmony import */ var _ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./ionic-selectable-icon-template.directive */ "UY7p");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ "ofXK");
// tslint:disable-next-line:max-line-length























const _c0 = function (a0) { return { value: a0 }; };
function IonicSelectableComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 8);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r0.valueTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c0, ctx_r0._valueItems));
} }
function IonicSelectableComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r1.valueTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c0, ctx_r1._valueItems[0]));
} }
function IonicSelectableComponent_span_4_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const valueItem_r9 = ctx.$implicit;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r8._formatValueItem(valueItem_r9), " ");
} }
function IonicSelectableComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, IonicSelectableComponent_span_4_div_1_Template, 2, 1, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r2._valueItems);
} }
function IonicSelectableComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r3.placeholderTemplate);
} }
function IonicSelectableComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r4.placeholder, " ");
} }
function IonicSelectableComponent_span_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "\u00A0");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function IonicSelectableComponent_div_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r6.iconTemplate);
} }
function IonicSelectableComponent_div_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class IonicSelectableComponent {
    constructor(_modalController, _platform, ionItem, _iterableDiffers, _element, _renderer) {
        this._modalController = _modalController;
        this._platform = _platform;
        this.ionItem = ionItem;
        this._iterableDiffers = _iterableDiffers;
        this._element = _element;
        this._renderer = _renderer;
        this._cssClass = true;
        this._isOnSearchEnabled = true;
        this._isEnabled = true;
        this._shouldBackdropClose = true;
        this._isOpened = false;
        this._value = null;
        this._canClear = false;
        this._hasConfirmButton = false;
        this._isMultiple = false;
        this._canAddItem = false;
        this.onItemsChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this._hasIonLabel = false;
        this._ionLabelPosition = null;
        this._label = null;
        this._valueItems = [];
        this._searchText = '';
        this._hasSearchText = false;
        this._groups = [];
        this._itemsToConfirm = [];
        this._selectedItems = [];
        this._filteredGroups = [];
        this._isAddItemTemplateVisible = false;
        this._isFooterVisible = true;
        this._itemToAdd = null;
        this._footerButtonsCount = 0;
        this._hasFilteredItems = false;
        /**
         * A list of items.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#items).
         *
         * @default []
         * @memberof IonicSelectableComponent
         */
        this.items = [];
        this.itemsChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Modal CSS class.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#modalcssclass).
         *
         * @default null
         * @memberof IonicSelectableComponent
         */
        this.modalCssClass = null;
        /**
         * Modal enter animation.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#modalenteranimation).
         *
         * @default null
         * @memberof IonicSelectableComponent
         */
        this.modalEnterAnimation = null;
        /**
         * Modal leave animation.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#modalleaveanimation).
         *
         * @default null
         * @memberof IonicSelectableComponent
         */
        this.modalLeaveAnimation = null;
        /**
         * Determines whether Confirm button is enabled.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#isconfirmbuttonenabled).
         *
         * @default true
         * @memberof IonicSelectableComponent
         */
        this.isConfirmButtonEnabled = true;
        /**
         * Item property to use as a unique identifier, e.g, `'id'`.
         * **Note**: `items` should be an object array.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#itemvaluefield).
         *
         * @default null
         * @memberof IonicSelectableComponent
         */
        this.itemValueField = null;
        /**
         * Item property to display, e.g, `'name'`.
         * **Note**: `items` should be an object array.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#itemtextfield).
         *
         * @default false
         * @memberof IonicSelectableComponent
         */
        this.itemTextField = null;
        /**
         *
         * Group property to use as a unique identifier to group items, e.g. `'country.id'`.
         * **Note**: `items` should be an object array.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#groupvaluefield).
         *
         * @default null
         * @memberof IonicSelectableComponent
         */
        this.groupValueField = null;
        /**
      * Group property to display, e.g. `'country.name'`.
      * **Note**: `items` should be an object array.
      * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#grouptextfield).
      *
      * @default null
      * @memberof IonicSelectableComponent
      */
        this.groupTextField = null;
        /**
         * Determines whether to show Searchbar.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#cansearch).
         *
         * @default false
         * @memberof IonicSelectableComponent
         */
        this.canSearch = false;
        /**
         * Determines whether Ionic [InfiniteScroll](https://ionicframework.com/docs/api/components/infinite-scroll/InfiniteScroll/) is enabled.
         * **Note**: Infinite scroll cannot be used together with virtual scroll.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#hasinfinitescroll).
         *
         * @default false
         * @memberof IonicSelectableComponent
         */
        this.hasInfiniteScroll = false;
        /**
         * Determines whether Ionic [VirtualScroll](https://ionicframework.com/docs/api/components/virtual-scroll/VirtualScroll/) is enabled.
         * **Note**: Virtual scroll cannot be used together with infinite scroll.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#hasvirtualscroll).
         *
         * @default false
         * @memberof IonicSelectableComponent
         */
        this.hasVirtualScroll = false;
        /**
         * See Ionic VirtualScroll [approxItemHeight](https://ionicframework.com/docs/api/components/virtual-scroll/VirtualScroll/).
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#virtualscrollapproxitemheight).
         *
         * @default '40px'
         * @memberof IonicSelectableComponent
         */
        this.virtualScrollApproxItemHeight = '40px';
        /**
         * A placeholder for Searchbar.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#searchplaceholder).
         *
         * @default 'Search'
         * @memberof IonicSelectableComponent
         */
        this.searchPlaceholder = 'Search';
        /**
         * A placeholder.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#placeholder).
         *
         * @default null
         * @memberof IonicSelectableComponent
         */
        this.placeholder = null;
        /**
         * Text to display when no items have been found during search.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#searchfailtext).
         *
         * @default 'No items found.'
         * @memberof IonicSelectableComponent
         */
        this.searchFailText = 'No items found.';
        /**
         * Clear button text.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#clearbuttontext).
         *
         * @default 'Clear'
         * @memberof IonicSelectableComponent
         */
        this.clearButtonText = 'Clear';
        /**
         * Add button text.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#addbuttontext).
         *
         * @default 'Add'
         * @memberof IonicSelectableComponent
         */
        this.addButtonText = 'Add';
        /**
         * Confirm button text.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#confirmbuttontext).
         *
         * @default 'OK'
         * @memberof IonicSelectableComponent
         */
        this.confirmButtonText = 'OK';
        /**
         * Close button text.
         * The field is only applicable to **iOS** platform, on **Android** only Cross icon is displayed.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#closebuttontext).
         *
         * @default 'Cancel'
         * @memberof IonicSelectableComponent
         */
        this.closeButtonText = 'Cancel';
        /**
         * Determines whether Searchbar should receive focus when Modal is opened.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#shouldfocussearchbar).
         *
         * @default false
         * @memberof IonicSelectableComponent
         */
        this.shouldFocusSearchbar = false;
        /**
         * Header color. [Ionic colors](https://ionicframework.com/docs/theming/advanced#colors) are supported.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#headercolor).
         *
         * @default null
         * @memberof IonicSelectableComponent
         */
        this.headerColor = null;
        /**
         * Group color. [Ionic colors](https://ionicframework.com/docs/theming/advanced#colors) are supported.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#groupcolor).
         *
         * @default null
         * @memberof IonicSelectableComponent
         */
        this.groupColor = null;
        /**
         * Close button slot. [Ionic slots](https://ionicframework.com/docs/api/buttons) are supported.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#closebuttonslot).
         *
         * @default 'start'
         * @memberof IonicSelectableComponent
         */
        this.closeButtonSlot = 'start';
        /**
         * Item icon slot. [Ionic slots](https://ionicframework.com/docs/api/item) are supported.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#itemiconslot).
         *
         * @default 'start'
         * @memberof IonicSelectableComponent
         */
        this.itemIconSlot = 'start';
        /**
         * Fires when item/s has been selected and Modal closed.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onchange).
         *
         * @memberof IonicSelectableComponent
         */
        this.onChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when the user is typing in Searchbar.
         * **Note**: `canSearch` and `isOnSearchEnabled` has to be enabled.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onsearch).
         *
         * @memberof IonicSelectableComponent
         */
        this.onSearch = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when no items have been found.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onsearchfail).
         *
         * @memberof IonicSelectableComponent
         */
        this.onSearchFail = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when some items have been found.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onsearchsuccess).
         *
         * @memberof IonicSelectableComponent
         */
        this.onSearchSuccess = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when the user has scrolled to the end of the list.
         * **Note**: `hasInfiniteScroll` has to be enabled.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#oninfinitescroll).
         *
         * @memberof IonicSelectableComponent
         */
        this.onInfiniteScroll = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when Modal has been opened.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onopen).
         *
         * @memberof IonicSelectableComponent
         */
        this.onOpen = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when Modal has been closed.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onclose).
         *
         * @memberof IonicSelectableComponent
         */
        this.onClose = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when an item has been selected or unselected.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onselect).
         *
         * @memberof IonicSelectableComponent
         */
        this.onSelect = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when Clear button has been clicked.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onclear).
         *
         * @memberof IonicSelectableComponent
         */
        this.onClear = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * How long, in milliseconds, to wait to filter items or to trigger `onSearch` event after each keystroke.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#searchdebounce).
         *
         * @default 250
         * @memberof IonicSelectableComponent
         */
        this.searchDebounce = 250;
        /**
         * A list of items to disable.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#disableditems).
         *
         * @default []
         * @memberof IonicSelectableComponent
         */
        this.disabledItems = [];
        /**
         * Determines whether item value only should be stored in `ngModel`, not the entire item.
         * **Note**: Item value is defined by `itemValueField`.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#shouldstoreitemvalue).
         *
         * @default false
         * @memberof IonicSelectableComponent
         */
        this.shouldStoreItemValue = false;
        /**
         * Determines whether to allow editing items.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#cansaveitem).
         *
         * @default false
         * @memberof IonicSelectableComponent
         */
        this.canSaveItem = false;
        /**
         * Determines whether to allow deleting items.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#candeleteitem).
         *
         * @default false
         * @memberof IonicSelectableComponent
         */
        this.canDeleteItem = false;
        /**
         * Fires when Edit item button has been clicked.
         * When the button has been clicked `ionicSelectableAddItemTemplate` will be shown. Use the template to create a form to edit item.
         * **Note**: `canSaveItem` has to be enabled.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onsaveitem).
         *
         * @memberof IonicSelectableComponent
         */
        this.onSaveItem = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when Delete item button has been clicked.
         * **Note**: `canDeleteItem` has to be enabled.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#ondeleteitem).
         *
         * @memberof IonicSelectableComponent
         */
        this.onDeleteItem = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * Fires when Add item button has been clicked.
         * When the button has been clicked `ionicSelectableAddItemTemplate` will be shown. Use the template to create a form to add item.
         * **Note**: `canAddItem` has to be enabled.
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#onadditem).
         *
         * @memberof IonicSelectableComponent
         */
        this.onAddItem = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        /**
         * See Ionic VirtualScroll [headerFn](https://ionicframework.com/docs/api/components/virtual-scroll/VirtualScroll/).
         * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#virtualscrollheaderfn).
         *
         * @memberof IonicSelectableComponent
         */
        this.virtualScrollHeaderFn = () => {
            return null;
        };
        this.propagateOnChange = (_) => { };
        this.propagateOnTouched = () => { };
        if (!this.items || !this.items.length) {
            this.items = [];
        }
        this._itemsDiffer = this._iterableDiffers.find(this.items).create();
    }
    get _isMultipleCssClass() {
        return this.isMultiple;
    }
    get _hasValueCssClass() {
        return this.hasValue();
    }
    get _hasPlaceholderCssClass() {
        return this._hasPlaceholder;
    }
    get _hasIonLabelCssClass() {
        return this._hasIonLabel;
    }
    get _hasDefaultIonLabelCssClass() {
        return this._ionLabelPosition === 'default';
    }
    get _hasFixedIonLabelCssClass() {
        return this._ionLabelPosition === 'fixed';
    }
    get _hasStackedIonLabelCssClass() {
        return this._ionLabelPosition === 'stacked';
    }
    get _hasFloatingIonLabelCssClass() {
        return this._ionLabelPosition === 'floating';
    }
    get _hasInfiniteScroll() {
        return this.isEnabled && this._modalComponent &&
            this._modalComponent._infiniteScroll ? true : false;
    }
    get _shouldStoreItemValue() {
        return this.shouldStoreItemValue && this._hasObjects;
    }
    /**
     * Text of [Ionic Label](https://ionicframework.com/docs/api/label).
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#label).
     *
     * @readonly
     * @default null
     * @memberof IonicSelectableComponent
     */
    get label() {
        return this._label;
    }
    /**
     * Text that the user has typed in Searchbar.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#searchtext).
     *
     * @readonly
     * @default ''
     * @memberof IonicSelectableComponent
     */
    get searchText() {
        return this._searchText;
    }
    set searchText(searchText) {
        this._searchText = searchText;
        this._setHasSearchText();
    }
    /**
     * Determines whether search is running.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#issearching).
     *
     * @default false
     * @readonly
     * @memberof IonicSelectableComponent
     */
    get isSearching() {
        return this._isSearching;
    }
    /**
     * Determines whether user has typed anything in Searchbar.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#hassearchtext).
     *
     * @default false
     * @readonly
     * @memberof IonicSelectableComponent
     */
    get hasSearchText() {
        return this._hasSearchText;
    }
    get value() {
        return this._value;
    }
    set value(value) {
        this._value = value;
        // Set value items.
        this._valueItems.splice(0, this._valueItems.length);
        if (this.isMultiple) {
            if (value && value.length) {
                Array.prototype.push.apply(this._valueItems, value);
            }
        }
        else {
            if (!this._isNullOrWhiteSpace(value)) {
                this._valueItems.push(value);
            }
        }
        this._setIonItemHasValue();
        this._setHasPlaceholder();
    }
    /**
     * Determines whether the component is enabled.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#isenabled).
     *
     * @default true
     * @memberof IonicSelectableComponent
     */
    get isEnabled() {
        return this._isEnabled;
    }
    set isEnabled(isEnabled) {
        this._isEnabled = !!isEnabled;
        this.enableIonItem(this._isEnabled);
    }
    /**
     * Determines whether Modal should be closed when backdrop is clicked.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#shouldbackdropclose).
     *
     * @default true
     * @memberof IonicSelectableComponent
     */
    get shouldBackdropClose() {
        return this._shouldBackdropClose;
    }
    set shouldBackdropClose(shouldBackdropClose) {
        this._shouldBackdropClose = !!shouldBackdropClose;
    }
    /**
     * Determines whether Modal is opened.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#isopened).
     *
     * @default false
     * @readonly
     * @memberof IonicSelectableComponent
     */
    get isOpened() {
        return this._isOpened;
    }
    /**
   * Determines whether Confirm button is visible for single selection.
   * By default Confirm button is visible only for multiple selection.
   * **Note**: It is always true for multiple selection and cannot be changed.
   * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#hasconfirmbutton).
   *
   * @default true
   * @memberof IonicSelectableComponent
   */
    get hasConfirmButton() {
        return this._hasConfirmButton;
    }
    set hasConfirmButton(hasConfirmButton) {
        this._hasConfirmButton = !!hasConfirmButton;
        this._countFooterButtons();
    }
    /**
     * Determines whether `onSearch` event is enabled.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#isonsearchenabled).
     *
     * @default true
     * @memberof IonicSelectableComponent
     */
    get isOnSearchEnabled() {
        return this._isOnSearchEnabled;
    }
    set isOnSearchEnabled(isOnSearchEnabled) {
        this._isOnSearchEnabled = !!isOnSearchEnabled;
    }
    /**
     * Determines whether to show Clear button.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#canclear).
     *
     * @default false
     * @memberof IonicSelectableComponent
     */
    get canClear() {
        return this._canClear;
    }
    set canClear(canClear) {
        this._canClear = !!canClear;
        this._countFooterButtons();
    }
    /**
     * Determines whether multiple items can be selected.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#ismultiple).
     *
     * @default false
     * @memberof IonicSelectableComponent
     */
    get isMultiple() {
        return this._isMultiple;
    }
    set isMultiple(isMultiple) {
        this._isMultiple = !!isMultiple;
        this._countFooterButtons();
    }
    /**
     * A list of items that are selected and awaiting confirmation by user, when he has clicked Confirm button.
     * After the user has clicked Confirm button items to confirm are cleared.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#itemstoconfirm).
     *
     * @default []
     * @readonly
     * @memberof IonicSelectableComponent
     */
    get itemsToConfirm() {
        return this._itemsToConfirm;
    }
    /**
     * Determines whether to allow adding items.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#canadditem).
     *
     * @default false
     * @memberof IonicSelectableComponent
     */
    get canAddItem() {
        return this._canAddItem;
    }
    set canAddItem(canAddItem) {
        this._canAddItem = !!canAddItem;
        this._countFooterButtons();
    }
    initFocus() { }
    enableIonItem(isEnabled) {
        if (!this.ionItem) {
            return;
        }
        this.ionItem.disabled = !isEnabled;
    }
    _isNullOrWhiteSpace(value) {
        if (value === null || value === undefined) {
            return true;
        }
        // Convert value to string in case if it's not.
        return value.toString().replace(/\s/g, '').length < 1;
    }
    _setHasSearchText() {
        this._hasSearchText = !this._isNullOrWhiteSpace(this._searchText);
    }
    _hasOnSearch() {
        return this.isOnSearchEnabled && this.onSearch.observers.length > 0;
    }
    _hasOnSaveItem() {
        return this.canSaveItem && this.onSaveItem.observers.length > 0;
    }
    _hasOnAddItem() {
        return this.canAddItem && this.onAddItem.observers.length > 0;
    }
    _hasOnDeleteItem() {
        return this.canDeleteItem && this.onDeleteItem.observers.length > 0;
    }
    _emitValueChange() {
        this.propagateOnChange(this.value);
        this.onChange.emit({
            component: this,
            value: this.value
        });
    }
    _emitSearch() {
        if (!this.canSearch) {
            return;
        }
        this.onSearch.emit({
            component: this,
            text: this._searchText
        });
    }
    _emitOnSelect(item, isSelected) {
        this.onSelect.emit({
            component: this,
            item: item,
            isSelected: isSelected
        });
    }
    _emitOnClear(items) {
        this.onClear.emit({
            component: this,
            items: items
        });
    }
    _emitOnSearchSuccessOrFail(isSuccess) {
        const eventData = {
            component: this,
            text: this._searchText
        };
        if (isSuccess) {
            this.onSearchSuccess.emit(eventData);
        }
        else {
            this.onSearchFail.emit(eventData);
        }
    }
    _formatItem(item) {
        if (this._isNullOrWhiteSpace(item)) {
            return null;
        }
        return this.itemTextField ? item[this.itemTextField] : item.toString();
    }
    _formatValueItem(item) {
        if (this._shouldStoreItemValue) {
            // Get item text from the list as we store it's value only.
            const selectedItem = this.items.find(_item => {
                return _item[this.itemValueField] === item;
            });
            return this._formatItem(selectedItem);
        }
        else {
            return this._formatItem(item);
        }
    }
    _getItemValue(item) {
        if (!this._hasObjects) {
            return item;
        }
        return item[this.itemValueField];
    }
    _getStoredItemValue(item) {
        if (!this._hasObjects) {
            return item;
        }
        return this._shouldStoreItemValue ? item : item[this.itemValueField];
    }
    _onSearchbarClear() {
        // Ionic Searchbar doesn't clear bind with ngModel value.
        // Do it ourselves.
        this._searchText = '';
    }
    _filterItems() {
        this._setHasSearchText();
        if (this._hasOnSearch()) {
            // Delegate filtering to the event.
            this._emitSearch();
        }
        else {
            // Default filtering.
            let groups = [];
            if (!this._searchText || !this._searchText.trim()) {
                groups = this._groups;
            }
            else {
                const filterText = this._searchText.trim().toLowerCase();
                this._groups.forEach(group => {
                    const items = group.items.filter(item => {
                        const itemText = (this.itemTextField ?
                            item[this.itemTextField] : item).toString().toLowerCase();
                        return itemText.indexOf(filterText) !== -1;
                    });
                    if (items.length) {
                        groups.push({
                            value: group.value,
                            text: group.text,
                            items: items
                        });
                    }
                });
                // No items found.
                if (!groups.length) {
                    groups.push({
                        items: []
                    });
                }
            }
            this._filteredGroups = groups;
            this._hasFilteredItems = !this._areGroupsEmpty(groups);
            this._emitOnSearchSuccessOrFail(this._hasFilteredItems);
        }
    }
    _isItemDisabled(item) {
        if (!this.disabledItems) {
            return;
        }
        return this.disabledItems.some(_item => {
            return this._getItemValue(_item) === this._getItemValue(item);
        });
    }
    _isItemSelected(item) {
        return this._selectedItems.find(selectedItem => {
            return this._getItemValue(item) === this._getStoredItemValue(selectedItem);
        }) !== undefined;
    }
    _addSelectedItem(item) {
        if (this._shouldStoreItemValue) {
            this._selectedItems.push(this._getItemValue(item));
        }
        else {
            this._selectedItems.push(item);
        }
    }
    _deleteSelectedItem(item) {
        let itemToDeleteIndex;
        this._selectedItems.forEach((selectedItem, itemIndex) => {
            if (this._getItemValue(item) ===
                this._getStoredItemValue(selectedItem)) {
                itemToDeleteIndex = itemIndex;
            }
        });
        this._selectedItems.splice(itemToDeleteIndex, 1);
    }
    _click() {
        if (!this.isEnabled) {
            return;
        }
        this._label = this._getLabelText();
        this.open().then(() => {
            this.onOpen.emit({
                component: this
            });
        });
    }
    _saveItem(event, item) {
        event.stopPropagation();
        this._itemToAdd = item;
        if (this._hasOnSaveItem()) {
            this.onSaveItem.emit({
                component: this,
                item: this._itemToAdd
            });
        }
        else {
            this.showAddItemTemplate();
        }
    }
    _deleteItemClick(event, item) {
        event.stopPropagation();
        this._itemToAdd = item;
        if (this._hasOnDeleteItem()) {
            // Delegate logic to event.
            this.onDeleteItem.emit({
                component: this,
                item: this._itemToAdd
            });
        }
        else {
            this.deleteItem(this._itemToAdd);
        }
    }
    _addItemClick() {
        if (this._hasOnAddItem()) {
            this.onAddItem.emit({
                component: this
            });
        }
        else {
            this.showAddItemTemplate();
        }
    }
    _positionAddItemTemplate() {
        // Wait for the template to render.
        setTimeout(() => {
            const footer = this._modalComponent._element.nativeElement
                .querySelector('.ionic-selectable-add-item-template ion-footer');
            this._addItemTemplateFooterHeight = footer ? `calc(100% - ${footer.offsetHeight}px)` : '100%';
        }, 100);
    }
    _close() {
        this.close().then(() => {
            this.onClose.emit({
                component: this
            });
        });
        if (!this._hasOnSearch()) {
            this._searchText = '';
            this._setHasSearchText();
        }
    }
    _clear() {
        const selectedItems = this._selectedItems;
        this.clear();
        this._emitValueChange();
        this._emitOnClear(selectedItems);
        this.close().then(() => {
            this.onClose.emit({
                component: this
            });
        });
    }
    _getMoreItems() {
        this.onInfiniteScroll.emit({
            component: this,
            text: this._searchText
        });
    }
    _setItemsToConfirm(items) {
        // Return a copy of original array, so it couldn't be changed from outside.
        this._itemsToConfirm = [].concat(items);
    }
    _doSelect(selectedItem) {
        this.value = selectedItem;
        this._emitValueChange();
    }
    _select(item) {
        const isItemSelected = this._isItemSelected(item);
        if (this.isMultiple) {
            if (isItemSelected) {
                this._deleteSelectedItem(item);
            }
            else {
                this._addSelectedItem(item);
            }
            this._setItemsToConfirm(this._selectedItems);
            // Emit onSelect event after setting items to confirm so they could be used
            // inside the event.
            this._emitOnSelect(item, !isItemSelected);
        }
        else {
            if (this.hasConfirmButton || this.footerTemplate) {
                // Don't close Modal and keep track on items to confirm.
                // When footer template is used it's up to developer to close Modal.
                this._selectedItems = [];
                if (isItemSelected) {
                    this._deleteSelectedItem(item);
                }
                else {
                    this._addSelectedItem(item);
                }
                this._setItemsToConfirm(this._selectedItems);
                // Emit onSelect event after setting items to confirm so they could be used
                // inside the event.
                this._emitOnSelect(item, !isItemSelected);
            }
            else {
                if (!isItemSelected) {
                    this._selectedItems = [];
                    this._addSelectedItem(item);
                    // Emit onSelect before onChange.
                    this._emitOnSelect(item, true);
                    if (this._shouldStoreItemValue) {
                        this._doSelect(this._getItemValue(item));
                    }
                    else {
                        this._doSelect(item);
                    }
                }
                this._close();
            }
        }
    }
    _confirm() {
        this.confirm();
        this._close();
    }
    _getLabelText() {
        return this._ionLabelElement ? this._ionLabelElement.textContent : null;
    }
    _areGroupsEmpty(groups) {
        return groups.length === 0 || groups.every(group => {
            return !group.items || group.items.length === 0;
        });
    }
    _countFooterButtons() {
        let footerButtonsCount = 0;
        if (this.canClear) {
            footerButtonsCount++;
        }
        if (this.isMultiple || this._hasConfirmButton) {
            footerButtonsCount++;
        }
        if (this.canAddItem) {
            footerButtonsCount++;
        }
        this._footerButtonsCount = footerButtonsCount;
    }
    _setItems(items) {
        // It's important to have an empty starting group with empty items (groups[0].items),
        // because we bind to it when using VirtualScroll.
        // See https://github.com/eakoriakin/ionic-selectable/issues/70.
        let groups = [{
                items: items || []
            }];
        if (items && items.length) {
            if (this._hasGroups) {
                groups = [];
                items.forEach(item => {
                    const groupValue = this._getPropertyValue(item, this.groupValueField), group = groups.find(_group => _group.value === groupValue);
                    if (group) {
                        group.items.push(item);
                    }
                    else {
                        groups.push({
                            value: groupValue,
                            text: this._getPropertyValue(item, this.groupTextField),
                            items: [item]
                        });
                    }
                });
            }
        }
        this._groups = groups;
        this._filteredGroups = this._groups;
        this._hasFilteredItems = !this._areGroupsEmpty(this._filteredGroups);
    }
    _getPropertyValue(object, property) {
        if (!property) {
            return null;
        }
        return property.split('.').reduce((_object, _property) => {
            return _object ? _object[_property] : null;
        }, object);
    }
    _setIonItemHasFocus(hasFocus) {
        if (!this.ionItem) {
            return;
        }
        // Apply focus CSS class for proper stylying of ion-item/ion-label.
        this._setIonItemCssClass('item-has-focus', hasFocus);
    }
    _setIonItemHasValue() {
        if (!this.ionItem) {
            return;
        }
        // Apply value CSS class for proper stylying of ion-item/ion-label.
        this._setIonItemCssClass('item-has-value', this.hasValue());
    }
    _setHasPlaceholder() {
        this._hasPlaceholder = !this.hasValue() &&
            (!this._isNullOrWhiteSpace(this.placeholder) || this.placeholderTemplate) ?
            true : false;
    }
    _setIonItemCssClass(cssClass, shouldAdd) {
        if (!this._ionItemElement) {
            return;
        }
        // Change to Renderer2
        if (shouldAdd) {
            this._renderer.addClass(this._ionItemElement, cssClass);
        }
        else {
            this._renderer.removeClass(this._ionItemElement, cssClass);
        }
    }
    _toggleAddItemTemplate(isVisible) {
        // It should be possible to show/hide the template regardless
        // canAddItem or canSaveItem parameters, so we could implement some
        // custom behavior. E.g. adding item when search fails using onSearchFail event.
        if (!this.addItemTemplate) {
            return;
        }
        // To make SaveItemTemplate visible we just position it over list using CSS.
        // We don't hide list with *ngIf or [hidden] to prevent its scroll position.
        this._isAddItemTemplateVisible = isVisible;
        this._isFooterVisible = !isVisible;
    }
    /* ControlValueAccessor */
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(method) {
        this.propagateOnChange = method;
    }
    registerOnTouched(method) {
        this.propagateOnTouched = method;
    }
    setDisabledState(isDisabled) {
        this.isEnabled = !isDisabled;
    }
    /* .ControlValueAccessor */
    ngOnInit() {
        this._isIos = this._platform.is('ios');
        this._isMD = !this._isIos;
        this._hasObjects = !this._isNullOrWhiteSpace(this.itemValueField);
        // Grouping is supported for objects only.
        // Ionic VirtualScroll has it's own implementation of grouping.
        this._hasGroups = Boolean(this._hasObjects && this.groupValueField && !this.hasVirtualScroll);
        if (this.ionItem) {
            this._ionItemElement = this._element.nativeElement.closest('ion-item');
            this._setIonItemCssClass('item-interactive', true);
            this._setIonItemCssClass('item-ionic-selectable', true);
            if (this._ionItemElement) {
                this._ionLabelElement = this._ionItemElement.querySelector('ion-label');
                if (this._ionLabelElement) {
                    this._hasIonLabel = true;
                    this._ionLabelPosition = this._ionLabelElement.getAttribute('position') || 'default';
                }
            }
        }
        this.enableIonItem(this.isEnabled);
    }
    ngDoCheck() {
        const itemsChanges = this._itemsDiffer.diff(this.items);
        if (itemsChanges) {
            this._setItems(this.items);
            this.value = this.value;
            this.onItemsChange.emit({
                component: this
            });
        }
    }
    /**
     * Adds item.
     * **Note**: If you want an item to be added to the original array as well use two-way data binding syntax on `[(items)]` field.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#additem).
     *
     * @param item Item to add.
     * @returns Promise that resolves when item has been added.
     * @memberof IonicSelectableComponent
     */
    addItem(item) {
        const self = this;
        // Adding item triggers onItemsChange.
        // Return a promise that resolves when onItemsChange finishes.
        // We need a promise or user could do something after item has been added,
        // e.g. use search() method to find the added item.
        this.items.unshift(item);
        // Close any running subscription.
        if (this._addItemObservable) {
            this._addItemObservable.unsubscribe();
        }
        return new Promise(function (resolve, reject) {
            // Complete callback isn't fired for some reason,
            // so unsubscribe in both success and fail cases.
            self._addItemObservable = self.onItemsChange.asObservable().subscribe(() => {
                self._addItemObservable.unsubscribe();
                resolve();
            }, () => {
                self._addItemObservable.unsubscribe();
                reject();
            });
        });
    }
    /**
   * Deletes item.
   * **Note**: If you want an item to be deleted from the original array as well use two-way data binding syntax on `[(items)]` field.
   * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#deleteitem).
   *
   * @param item Item to delete.
   * @returns Promise that resolves when item has been deleted.
   * @memberof IonicSelectableComponent
   */
    deleteItem(item) {
        const self = this;
        let hasValueChanged = false;
        // Remove deleted item from selected items.
        if (this._selectedItems) {
            this._selectedItems = this._selectedItems.filter(_item => {
                return this._getItemValue(item) !== this._getStoredItemValue(_item);
            });
        }
        // Remove deleted item from value.
        if (this.value) {
            if (this.isMultiple) {
                const values = this.value.filter(value => {
                    return value.id !== item.id;
                });
                if (values.length !== this.value.length) {
                    this.value = values;
                    hasValueChanged = true;
                }
            }
            else {
                if (item === this.value) {
                    this.value = null;
                    hasValueChanged = true;
                }
            }
        }
        if (hasValueChanged) {
            this._emitValueChange();
        }
        // Remove deleted item from list.
        const items = this.items.filter(_item => {
            return _item.id !== item.id;
        });
        // Refresh items on parent component.
        this.itemsChange.emit(items);
        // Refresh list.
        this._setItems(items);
        this.onItemsChange.emit({
            component: this
        });
        // Close any running subscription.
        if (this._deleteItemObservable) {
            this._deleteItemObservable.unsubscribe();
        }
        return new Promise(function (resolve, reject) {
            // Complete callback isn't fired for some reason,
            // so unsubscribe in both success and fail cases.
            self._deleteItemObservable = self.onItemsChange.asObservable().subscribe(() => {
                self._deleteItemObservable.unsubscribe();
                resolve();
            }, () => {
                self._deleteItemObservable.unsubscribe();
                reject();
            });
        });
    }
    /**
     * Determines whether any item has been selected.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#hasvalue).
     *
     * @returns A boolean determining whether any item has been selected.
     * @memberof IonicSelectableComponent
     */
    hasValue() {
        if (this.isMultiple) {
            return this._valueItems.length !== 0;
        }
        else {
            return this._valueItems.length !== 0 && !this._isNullOrWhiteSpace(this._valueItems[0]);
        }
    }
    /**
     * Opens Modal.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#open).
     *
     * @returns Promise that resolves when Modal has been opened.
     * @memberof IonicSelectableComponent
     */
    open() {
        const self = this;
        return new Promise(function (resolve, reject) {
            if (!self._isEnabled || self._isOpened) {
                reject('IonicSelectable is disabled or already opened.');
                return;
            }
            self._filterItems();
            self._isOpened = true;
            const modalOptions = {
                component: _ionic_selectable_modal_component__WEBPACK_IMPORTED_MODULE_13__["IonicSelectableModalComponent"],
                componentProps: { selectComponent: self },
                backdropDismiss: self._shouldBackdropClose
            };
            if (self.modalCssClass) {
                modalOptions.cssClass = self.modalCssClass;
            }
            if (self.modalEnterAnimation) {
                modalOptions.enterAnimation = self.modalEnterAnimation;
            }
            if (self.modalLeaveAnimation) {
                modalOptions.leaveAnimation = self.modalLeaveAnimation;
            }
            self._modalController.create(modalOptions).then(modal => {
                self._modal = modal;
                modal.present().then(() => {
                    // Set focus after Modal has opened to avoid flickering of focus highlighting
                    // before Modal opening.
                    self._setIonItemHasFocus(true);
                    resolve();
                });
                modal.onWillDismiss().then(() => {
                    self._setIonItemHasFocus(false);
                });
                modal.onDidDismiss().then(event => {
                    self._isOpened = false;
                    self._itemsToConfirm = [];
                    // Closed by clicking on backdrop outside modal.
                    if (event.role === 'backdrop') {
                        self.onClose.emit({
                            component: self
                        });
                    }
                });
            });
        });
    }
    /**
     * Closes Modal.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#close).
     *
     * @returns Promise that resolves when Modal has been closed.
     * @memberof IonicSelectableComponent
     */
    close() {
        const self = this;
        return new Promise(function (resolve, reject) {
            if (!self._isEnabled || !self._isOpened) {
                reject('IonicSelectable is disabled or already closed.');
                return;
            }
            self.propagateOnTouched();
            self._isOpened = false;
            self._itemToAdd = null;
            self._modal.dismiss().then(() => {
                self._setIonItemHasFocus(false);
                self.hideAddItemTemplate();
                resolve();
            });
        });
    }
    /**
     * Clears value.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#clear).
     *
     * @memberof IonicSelectableComponent
     */
    clear() {
        this.value = this.isMultiple ? [] : null;
        this._itemsToConfirm = [];
        this.propagateOnChange(this.value);
    }
    /**
     * Confirms selected items by updating value.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#confirm).
     *
     * @memberof IonicSelectableComponent
     */
    confirm() {
        if (this.isMultiple) {
            this._doSelect(this._selectedItems);
        }
        else if (this.hasConfirmButton || this.footerTemplate) {
            this._doSelect(this._selectedItems[0] || null);
        }
    }
    /**
     * Selects or deselects all or specific items.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#toggleitems).
     *
     * @param isSelect Determines whether to select or deselect items.
     * @param [items] Items to toggle. If items are not set all items will be toggled.
     * @memberof IonicSelectableComponent
     */
    toggleItems(isSelect, items) {
        if (isSelect) {
            const hasItems = items && items.length;
            let itemsToToggle = this._groups.reduce((allItems, group) => {
                return allItems.concat(group.items);
            }, []);
            // Don't allow to select all items in single mode.
            if (!this.isMultiple && !hasItems) {
                itemsToToggle = [];
            }
            // Toggle specific items.
            if (hasItems) {
                itemsToToggle = itemsToToggle.filter(itemToToggle => {
                    return items.find(item => {
                        return this._getItemValue(itemToToggle) === this._getItemValue(item);
                    }) !== undefined;
                });
                // Take the first item for single mode.
                if (!this.isMultiple) {
                    itemsToToggle.splice(0, 1);
                }
            }
            itemsToToggle.forEach(item => {
                this._addSelectedItem(item);
            });
        }
        else {
            this._selectedItems = [];
        }
        this._setItemsToConfirm(this._selectedItems);
    }
    /**
     * Scrolls to the top of Modal content.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#scrolltotop).
     *
     * @returns Promise that resolves when scroll has been completed.
     * @memberof IonicSelectableComponent
     */
    scrollToTop() {
        const self = this;
        return new Promise(function (resolve, reject) {
            if (!self._isOpened) {
                reject('IonicSelectable content cannot be scrolled.');
                return;
            }
            self._modalComponent._content.scrollToTop().then(() => {
                resolve();
            });
        });
    }
    /**
     * Scrolls to the bottom of Modal content.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#scrolltobottom).
     *
     * @returns Promise that resolves when scroll has been completed.
     * @memberof IonicSelectableComponent
     */
    scrollToBottom() {
        const self = this;
        return new Promise(function (resolve, reject) {
            if (!self._isOpened) {
                reject('IonicSelectable content cannot be scrolled.');
                return;
            }
            self._modalComponent._content.scrollToBottom().then(() => {
                resolve();
            });
        });
    }
    /**
     * Starts search process by showing Loading spinner.
     * Use it together with `onSearch` event to indicate search start.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#startsearch).
     *
     * @memberof IonicSelectableComponent
     */
    startSearch() {
        if (!this._isEnabled) {
            return;
        }
        this.showLoading();
    }
    /**
     * Ends search process by hiding Loading spinner and refreshing items.
     * Use it together with `onSearch` event to indicate search end.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#endsearch).
     *
     * @memberof IonicSelectableComponent
     */
    endSearch() {
        if (!this._isEnabled) {
            return;
        }
        this.hideLoading();
        // When inside Ionic Modal and onSearch event is used,
        // ngDoCheck() doesn't work as _itemsDiffer fails to detect changes.
        // See https://github.com/eakoriakin/ionic-selectable/issues/44.
        // Refresh items manually.
        this._setItems(this.items);
        this._emitOnSearchSuccessOrFail(this._hasFilteredItems);
    }
    /**
     * Enables infinite scroll.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#enableinfinitescroll).
     *
     * @memberof IonicSelectableComponent
     */
    enableInfiniteScroll() {
        if (!this._hasInfiniteScroll) {
            return;
        }
        this._modalComponent._infiniteScroll.disabled = false;
    }
    /**
     * Disables infinite scroll.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#disableinfinitescroll).
     *
     * @memberof IonicSelectableComponent
     */
    disableInfiniteScroll() {
        if (!this._hasInfiniteScroll) {
            return;
        }
        this._modalComponent._infiniteScroll.disabled = true;
    }
    /**
     * Ends infinite scroll.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#endinfinitescroll).
     *
     * @memberof IonicSelectableComponent
     */
    endInfiniteScroll() {
        if (!this._hasInfiniteScroll) {
            return;
        }
        this._modalComponent._infiniteScroll.complete();
        this._setItems(this.items);
    }
    /**
     * Triggers search of items.
     * **Note**: `canSearch` has to be enabled.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#search).
     *
     * @param text Text to search items by.
     * @memberof IonicSelectableComponent
     */
    search(text) {
        if (!this._isEnabled || !this._isOpened || !this.canSearch) {
            return;
        }
        this._searchText = text;
        this._setHasSearchText();
        this._filterItems();
    }
    /**
     * Shows Loading spinner.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#showloading).
     *
     * @memberof IonicSelectableComponent
     */
    showLoading() {
        if (!this._isEnabled) {
            return;
        }
        this._isSearching = true;
    }
    /**
     * Hides Loading spinner.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#hideloading).
     *
     * @memberof IonicSelectableComponent
     */
    hideLoading() {
        if (!this._isEnabled) {
            return;
        }
        this._isSearching = false;
    }
    /**
     * Shows `ionicSelectableAddItemTemplate`.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#showadditemtemplate).
     *
     * @memberof IonicSelectableComponent
     */
    showAddItemTemplate() {
        this._toggleAddItemTemplate(true);
        // Position the template only when it shous up.
        this._positionAddItemTemplate();
    }
    /**
     * Hides `ionicSelectableAddItemTemplate`.
     * See more on [GitHub](https://github.com/eakoriakin/ionic-selectable/wiki/Documentation#hideadditemtemplate).
     *
     * @memberof IonicSelectableComponent
     */
    hideAddItemTemplate() {
        // Clean item to add as it's no longer needed once Add Item Modal has been closed.
        this._itemToAdd = null;
        this._toggleAddItemTemplate(false);
    }
}
IonicSelectableComponent.ɵfac = function IonicSelectableComponent_Factory(t) { return new (t || IonicSelectableComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonItem"], 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["IterableDiffers"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"])); };
IonicSelectableComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: IonicSelectableComponent, selectors: [["ionic-selectable"]], contentQueries: function IonicSelectableComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_17__["IonicSelectableValueTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_11__["IonicSelectableItemTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_9__["IonicSelectableItemEndTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_16__["IonicSelectableTitleTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_14__["IonicSelectablePlaceholderTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_12__["IonicSelectableMessageTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_7__["IonicSelectableGroupTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_6__["IonicSelectableGroupEndTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_4__["IonicSelectableCloseButtonTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_15__["IonicSelectableSearchFailTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_3__["IonicSelectableAddItemTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_5__["IonicSelectableFooterTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableHeaderTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_10__["IonicSelectableItemIconTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_18__["IonicSelectableIconTemplateDirective"], 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.valueTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.itemTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.itemEndTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.titleTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.placeholderTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.messageTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.groupTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.groupEndTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.closeButtonTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.searchFailTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.addItemTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.footerTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.headerTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.itemIconTemplate = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.iconTemplate = _t.first);
    } }, hostVars: 26, hostBindings: function IonicSelectableComponent_HostBindings(rf, ctx) { if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("ionic-selectable", ctx._cssClass)("ionic-selectable-is-multiple", ctx._isMultipleCssClass)("ionic-selectable-has-value", ctx._hasValueCssClass)("ionic-selectable-has-placeholder", ctx._hasPlaceholderCssClass)("ionic-selectable-has-label", ctx._hasIonLabelCssClass)("ionic-selectable-label-default", ctx._hasDefaultIonLabelCssClass)("ionic-selectable-label-fixed", ctx._hasFixedIonLabelCssClass)("ionic-selectable-label-stacked", ctx._hasStackedIonLabelCssClass)("ionic-selectable-label-floating", ctx._hasFloatingIonLabelCssClass)("ionic-selectable-is-enabled", ctx.isEnabled)("ionic-selectable-can-clear", ctx.canClear)("ionic-selectable-ios", ctx._isIos)("ionic-selectable-md", ctx._isMD);
    } }, inputs: { items: "items", modalCssClass: "modalCssClass", modalEnterAnimation: "modalEnterAnimation", modalLeaveAnimation: "modalLeaveAnimation", isConfirmButtonEnabled: "isConfirmButtonEnabled", itemValueField: "itemValueField", itemTextField: "itemTextField", groupValueField: "groupValueField", groupTextField: "groupTextField", canSearch: "canSearch", hasInfiniteScroll: "hasInfiniteScroll", hasVirtualScroll: "hasVirtualScroll", virtualScrollApproxItemHeight: "virtualScrollApproxItemHeight", searchPlaceholder: "searchPlaceholder", placeholder: "placeholder", searchFailText: "searchFailText", clearButtonText: "clearButtonText", addButtonText: "addButtonText", confirmButtonText: "confirmButtonText", closeButtonText: "closeButtonText", shouldFocusSearchbar: "shouldFocusSearchbar", headerColor: "headerColor", groupColor: "groupColor", closeButtonSlot: "closeButtonSlot", itemIconSlot: "itemIconSlot", searchDebounce: "searchDebounce", disabledItems: "disabledItems", shouldStoreItemValue: "shouldStoreItemValue", canSaveItem: "canSaveItem", canDeleteItem: "canDeleteItem", virtualScrollHeaderFn: "virtualScrollHeaderFn", isEnabled: "isEnabled", shouldBackdropClose: "shouldBackdropClose", hasConfirmButton: "hasConfirmButton", isOnSearchEnabled: "isOnSearchEnabled", canClear: "canClear", isMultiple: "isMultiple", canAddItem: "canAddItem" }, outputs: { itemsChange: "itemsChange", onChange: "onChange", onSearch: "onSearch", onSearchFail: "onSearchFail", onSearchSuccess: "onSearchSuccess", onInfiniteScroll: "onInfiniteScroll", onOpen: "onOpen", onClose: "onClose", onSelect: "onSelect", onClear: "onClear", onSaveItem: "onSaveItem", onDeleteItem: "onDeleteItem", onAddItem: "onAddItem" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([{
                provide: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NG_VALUE_ACCESSOR"],
                useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => IonicSelectableComponent),
                multi: true
            }])], decls: 11, vars: 9, consts: [[1, "ionic-selectable-inner"], [1, "ionic-selectable-value"], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf"], ["class", "ionic-selectable-value-item", 4, "ngIf"], [4, "ngIf"], ["class", "ionic-selectable-icon-template", 4, "ngIf"], ["class", "ionic-selectable-icon", 4, "ngIf"], ["type", "button", 1, "ionic-selectable-cover", 3, "disabled", "click"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "ionic-selectable-value-item"], ["class", "ionic-selectable-value-item", 4, "ngFor", "ngForOf"], [3, "ngTemplateOutlet"], [1, "ionic-selectable-icon-template"], [1, "ionic-selectable-icon"], [1, "ionic-selectable-icon-inner"]], template: function IonicSelectableComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, IonicSelectableComponent_div_2_Template, 1, 4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, IonicSelectableComponent_div_3_Template, 2, 4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, IonicSelectableComponent_span_4_Template, 2, 1, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, IonicSelectableComponent_div_5_Template, 2, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, IonicSelectableComponent_div_6_Template, 2, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, IonicSelectableComponent_span_7_Template, 2, 0, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, IonicSelectableComponent_div_8_Template, 2, 1, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, IonicSelectableComponent_div_9_Template, 2, 0, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IonicSelectableComponent_Template_button_click_10_listener() { return ctx._click(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.valueTemplate && ctx._valueItems.length && ctx.isMultiple);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.valueTemplate && ctx._valueItems.length && !ctx.isMultiple);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.valueTemplate && ctx._valueItems.length);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx._hasPlaceholder && ctx.placeholderTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx._hasPlaceholder && !ctx.placeholderTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx._valueItems.length && !ctx._hasPlaceholder);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.iconTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.iconTemplate);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx.isEnabled);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_19__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_19__["NgTemplateOutlet"], _angular_common__WEBPACK_IMPORTED_MODULE_19__["NgForOf"]], styles: [".item-ionic-selectable .item-inner .input-wrapper{align-items:normal}.item-ionic-selectable ion-label{flex:1;max-width:none}.ionic-selectable{display:block;max-width:45%}.ionic-selectable-inner{display:flex;flex-wrap:wrap;flex-direction:row;justify-content:flex-end}.ionic-selectable-has-placeholder .ionic-selectable-value-item{color:var(--placeholder-color,#999)}.ionic-selectable-value{flex:1;padding-top:13px;padding-bottom:13px;overflow:hidden}.ionic-selectable-value-item{text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.ionic-selectable-value-item:not(:last-child){margin-bottom:5px}.ionic-selectable-icon{position:relative;width:20px}.ionic-selectable-icon-inner{position:absolute;top:20px;left:5px;border-top:5px solid;border-right:5px solid transparent;border-left:5px solid transparent;pointer-events:none;color:var(--icon-color,#999)}.ionic-selectable-icon-template{align-self:center;margin-left:5px}.ionic-selectable-ios .ionic-selectable-value{padding-top:11px;padding-bottom:11px}.ionic-selectable-ios .ionic-selectable-icon-inner{top:19px}.ionic-selectable-spinner{position:fixed;bottom:0;top:0;left:0;right:0;z-index:1}.ionic-selectable-spinner-background{top:0;bottom:0;left:0;right:0;position:absolute;background-color:#000;opacity:.05}.ionic-selectable-spinner ion-spinner{position:absolute;top:50%;left:50%;z-index:10;margin-top:-14px;margin-left:-14px}.ionic-selectable-cover{left:0;top:0;margin:0;position:absolute;width:100%;height:100%;border:0;background:0 0;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;outline:0}.ionic-selectable-add-item-template{position:fixed;bottom:0;left:0;right:0;background-color:#fff}.ionic-selectable-add-item-template-inner{overflow-y:auto}.ionic-selectable-add-item-template-inner>ion-footer{bottom:0;position:absolute}.ionic-selectable:not(.ionic-selectable-has-label){max-width:100%;width:100%}.ionic-selectable:not(.ionic-selectable-has-label)-value-item{text-align:right}.ionic-selectable-label-floating,.ionic-selectable-label-stacked{align-self:stretch;max-width:100%;padding-left:0;padding-top:8px;padding-bottom:8px}.ionic-selectable-label-floating .ionic-selectable-value,.ionic-selectable-label-stacked .ionic-selectable-value{padding-top:0;padding-bottom:0;min-height:19px}.ionic-selectable-label-floating .ionic-selectable-icon-inner,.ionic-selectable-label-stacked .ionic-selectable-icon-inner{top:7px}.ionic-selectable-label-floating.ionic-selectable-ios .ionic-selectable-value,.ionic-selectable-label-stacked.ionic-selectable-ios .ionic-selectable-value{padding-top:0;padding-bottom:0;min-height:20px}.ionic-selectable-label-floating.ionic-selectable-ios .ionic-selectable-icon-inner,.ionic-selectable-label-stacked.ionic-selectable-ios .ionic-selectable-icon-inner{top:8px}.ionic-selectable-label-default .ionic-selectable-value,.ionic-selectable-label-fixed .ionic-selectable-value{padding-left:var(--padding-start,16px)}.ionic-selectable-label-fixed:not(.ionic-selectable-has-value) .ionic-selectable-value{padding-left:calc(var(--padding-start, $padding) + 11px)}.ionic-selectable-modal .ionic-selectable-group ion-item-divider{padding-right:16px}.ionic-selectable-modal .ionic-selectable-item-button{margin-left:8px;margin-right:8px}.ionic-selectable-modal-ios .ionic-selectable-message{padding:8px}.ionic-selectable-modal-ios .ionic-selectable-group ion-item-divider{padding-right:8px}.ionic-selectable-modal-md .ionic-selectable-message{padding:8px 12px}.ionic-selectable-modal.ionic-selectable-modal-can-clear.ionic-selectable-modal-is-multiple .footer .col:first-child{padding-right:8px}.ionic-selectable-modal.ionic-selectable-modal-can-clear.ionic-selectable-modal-is-multiple .footer .col:last-child{padding-left:8px}.ionic-selectable-modal.ionic-selectable-modal-is-add-item-template-visible>.content>.scroll-content,.ionic-selectable-modal.ionic-selectable-modal-is-searching .scroll-content{overflow-y:hidden}.ionic-selectable-modal ion-header ion-toolbar:first-of-type{padding-top:var(--ion-safe-area-top,0)}"], encapsulation: 2 });
/** @nocollapse */
IonicSelectableComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonItem"], decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"] }] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["IterableDiffers"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] }
];
IonicSelectableComponent.propDecorators = {
    _cssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable',] }],
    _isIos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-ios',] }],
    _isMD: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-md',] }],
    _isMultipleCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-is-multiple',] }],
    _hasValueCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-has-value',] }],
    _hasPlaceholderCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-has-placeholder',] }],
    _hasIonLabelCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-has-label',] }],
    _hasDefaultIonLabelCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-label-default',] }],
    _hasFixedIonLabelCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-label-fixed',] }],
    _hasStackedIonLabelCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-label-stacked',] }],
    _hasFloatingIonLabelCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-label-floating',] }],
    items: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    itemsChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    isEnabled: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-is-enabled',] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['isEnabled',] }],
    shouldBackdropClose: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['shouldBackdropClose',] }],
    modalCssClass: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    modalEnterAnimation: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    modalLeaveAnimation: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    isConfirmButtonEnabled: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    hasConfirmButton: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['hasConfirmButton',] }],
    itemValueField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    itemTextField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    groupValueField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    groupTextField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    canSearch: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    isOnSearchEnabled: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['isOnSearchEnabled',] }],
    canClear: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"], args: ['class.ionic-selectable-can-clear',] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['canClear',] }],
    hasInfiniteScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    hasVirtualScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    virtualScrollApproxItemHeight: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    searchPlaceholder: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    placeholder: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    isMultiple: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['isMultiple',] }],
    searchFailText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    clearButtonText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    addButtonText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    confirmButtonText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    closeButtonText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    shouldFocusSearchbar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    headerColor: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    groupColor: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    closeButtonSlot: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    itemIconSlot: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    onChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onSearch: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onSearchFail: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onSearchSuccess: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onInfiniteScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onOpen: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onClose: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onSelect: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onClear: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    searchDebounce: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    disabledItems: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    shouldStoreItemValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    canSaveItem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    canDeleteItem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    canAddItem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['canAddItem',] }],
    onSaveItem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onDeleteItem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onAddItem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    valueTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_17__["IonicSelectableValueTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    itemTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_11__["IonicSelectableItemTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    itemEndTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_9__["IonicSelectableItemEndTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    titleTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_16__["IonicSelectableTitleTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    placeholderTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_14__["IonicSelectablePlaceholderTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    messageTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_12__["IonicSelectableMessageTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    groupTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_7__["IonicSelectableGroupTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    groupEndTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_6__["IonicSelectableGroupEndTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    closeButtonTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_4__["IonicSelectableCloseButtonTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    searchFailTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_15__["IonicSelectableSearchFailTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    addItemTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_3__["IonicSelectableAddItemTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    footerTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_5__["IonicSelectableFooterTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    headerTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableHeaderTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    itemIconTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_10__["IonicSelectableItemIconTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    iconTemplate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"], args: [_ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_18__["IonicSelectableIconTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] },] }],
    virtualScrollHeaderFn: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'ionic-selectable',
                template: "<div class=\"ionic-selectable-inner\">\n  <div class=\"ionic-selectable-value\">\n    <div *ngIf=\"valueTemplate && _valueItems.length && isMultiple\"\n      [ngTemplateOutlet]=\"valueTemplate\"\n      [ngTemplateOutletContext]=\"{ value: _valueItems }\">\n    </div>\n    <div class=\"ionic-selectable-value-item\"\n      *ngIf=\"valueTemplate && _valueItems.length && !isMultiple\">\n      <div [ngTemplateOutlet]=\"valueTemplate\"\n        [ngTemplateOutletContext]=\"{ value: _valueItems[0] }\">\n      </div>\n    </div>\n    <span *ngIf=\"!valueTemplate && _valueItems.length\">\n      <div class=\"ionic-selectable-value-item\"\n        *ngFor=\"let valueItem of _valueItems\">\n        {{_formatValueItem(valueItem)}}\n      </div>\n    </span>\n    <div *ngIf=\"_hasPlaceholder && placeholderTemplate\"\n      class=\"ionic-selectable-value-item\">\n      <div [ngTemplateOutlet]=\"placeholderTemplate\">\n      </div>\n    </div>\n    <div class=\"ionic-selectable-value-item\"\n      *ngIf=\"_hasPlaceholder && !placeholderTemplate\">\n      {{placeholder}}\n    </div>\n    <!-- Fix icon allignment when there's no value or placeholder. -->\n    <span *ngIf=\"!_valueItems.length && !_hasPlaceholder\">&nbsp;</span>\n  </div>\n  <div *ngIf=\"iconTemplate\" class=\"ionic-selectable-icon-template\">\n      <div [ngTemplateOutlet]=\"iconTemplate\"></div>\n  </div>\n  <div *ngIf=\"!iconTemplate\" class=\"ionic-selectable-icon\">\n    <div class=\"ionic-selectable-icon-inner\"></div>\n  </div>\n  <!-- Need to be type=\"button\" otherwise click event triggers form ngSubmit. -->\n  <button class=\"ionic-selectable-cover\" [disabled]=\"!isEnabled\"\n    (click)=\"_click()\" type=\"button\">\n  </button>\n</div>\n",
                encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None,
                providers: [{
                        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NG_VALUE_ACCESSOR"],
                        useExisting: Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(() => IonicSelectableComponent),
                        multi: true
                    }],
                styles: [".item-ionic-selectable .item-inner .input-wrapper{align-items:normal}.item-ionic-selectable ion-label{flex:1;max-width:none}.ionic-selectable{display:block;max-width:45%}.ionic-selectable-inner{display:flex;flex-wrap:wrap;flex-direction:row;justify-content:flex-end}.ionic-selectable-has-placeholder .ionic-selectable-value-item{color:var(--placeholder-color,#999)}.ionic-selectable-value{flex:1;padding-top:13px;padding-bottom:13px;overflow:hidden}.ionic-selectable-value-item{text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.ionic-selectable-value-item:not(:last-child){margin-bottom:5px}.ionic-selectable-icon{position:relative;width:20px}.ionic-selectable-icon-inner{position:absolute;top:20px;left:5px;border-top:5px solid;border-right:5px solid transparent;border-left:5px solid transparent;pointer-events:none;color:var(--icon-color,#999)}.ionic-selectable-icon-template{align-self:center;margin-left:5px}.ionic-selectable-ios .ionic-selectable-value{padding-top:11px;padding-bottom:11px}.ionic-selectable-ios .ionic-selectable-icon-inner{top:19px}.ionic-selectable-spinner{position:fixed;bottom:0;top:0;left:0;right:0;z-index:1}.ionic-selectable-spinner-background{top:0;bottom:0;left:0;right:0;position:absolute;background-color:#000;opacity:.05}.ionic-selectable-spinner ion-spinner{position:absolute;top:50%;left:50%;z-index:10;margin-top:-14px;margin-left:-14px}.ionic-selectable-cover{left:0;top:0;margin:0;position:absolute;width:100%;height:100%;border:0;background:0 0;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;outline:0}.ionic-selectable-add-item-template{position:fixed;bottom:0;left:0;right:0;background-color:#fff}.ionic-selectable-add-item-template-inner{overflow-y:auto}.ionic-selectable-add-item-template-inner>ion-footer{bottom:0;position:absolute}.ionic-selectable:not(.ionic-selectable-has-label){max-width:100%;width:100%}.ionic-selectable:not(.ionic-selectable-has-label)-value-item{text-align:right}.ionic-selectable-label-floating,.ionic-selectable-label-stacked{align-self:stretch;max-width:100%;padding-left:0;padding-top:8px;padding-bottom:8px}.ionic-selectable-label-floating .ionic-selectable-value,.ionic-selectable-label-stacked .ionic-selectable-value{padding-top:0;padding-bottom:0;min-height:19px}.ionic-selectable-label-floating .ionic-selectable-icon-inner,.ionic-selectable-label-stacked .ionic-selectable-icon-inner{top:7px}.ionic-selectable-label-floating.ionic-selectable-ios .ionic-selectable-value,.ionic-selectable-label-stacked.ionic-selectable-ios .ionic-selectable-value{padding-top:0;padding-bottom:0;min-height:20px}.ionic-selectable-label-floating.ionic-selectable-ios .ionic-selectable-icon-inner,.ionic-selectable-label-stacked.ionic-selectable-ios .ionic-selectable-icon-inner{top:8px}.ionic-selectable-label-default .ionic-selectable-value,.ionic-selectable-label-fixed .ionic-selectable-value{padding-left:var(--padding-start,16px)}.ionic-selectable-label-fixed:not(.ionic-selectable-has-value) .ionic-selectable-value{padding-left:calc(var(--padding-start, $padding) + 11px)}.ionic-selectable-modal .ionic-selectable-group ion-item-divider{padding-right:16px}.ionic-selectable-modal .ionic-selectable-item-button{margin-left:8px;margin-right:8px}.ionic-selectable-modal-ios .ionic-selectable-message{padding:8px}.ionic-selectable-modal-ios .ionic-selectable-group ion-item-divider{padding-right:8px}.ionic-selectable-modal-md .ionic-selectable-message{padding:8px 12px}.ionic-selectable-modal.ionic-selectable-modal-can-clear.ionic-selectable-modal-is-multiple .footer .col:first-child{padding-right:8px}.ionic-selectable-modal.ionic-selectable-modal-can-clear.ionic-selectable-modal-is-multiple .footer .col:last-child{padding-left:8px}.ionic-selectable-modal.ionic-selectable-modal-is-add-item-template-visible>.content>.scroll-content,.ionic-selectable-modal.ionic-selectable-modal-is-searching .scroll-content{overflow-y:hidden}.ionic-selectable-modal ion-header ion-toolbar:first-of-type{padding-top:var(--ion-safe-area-top,0)}"]
            }]
    }], function () { return [{ type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }, { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] }, { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonItem"], decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["IterableDiffers"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] }]; }, { _cssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable']
        }], items: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], itemsChange: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], modalCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], modalEnterAnimation: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], modalLeaveAnimation: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], isConfirmButtonEnabled: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], itemValueField: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], itemTextField: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], groupValueField: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], groupTextField: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], canSearch: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], hasInfiniteScroll: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], hasVirtualScroll: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], virtualScrollApproxItemHeight: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], searchPlaceholder: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], placeholder: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], searchFailText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], clearButtonText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], addButtonText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], confirmButtonText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], closeButtonText: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], shouldFocusSearchbar: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], headerColor: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], groupColor: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], closeButtonSlot: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], itemIconSlot: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], onChange: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onSearch: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onSearchFail: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onSearchSuccess: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onInfiniteScroll: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onOpen: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onClose: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onSelect: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onClear: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], searchDebounce: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], disabledItems: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], shouldStoreItemValue: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], canSaveItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], canDeleteItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], onSaveItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onDeleteItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], onAddItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], virtualScrollHeaderFn: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], _isMultipleCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-is-multiple']
        }], _hasValueCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-has-value']
        }], _hasPlaceholderCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-has-placeholder']
        }], _hasIonLabelCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-has-label']
        }], _hasDefaultIonLabelCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-label-default']
        }], _hasFixedIonLabelCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-label-fixed']
        }], _hasStackedIonLabelCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-label-stacked']
        }], _hasFloatingIonLabelCssClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-label-floating']
        }], isEnabled: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-is-enabled']
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['isEnabled']
        }], shouldBackdropClose: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['shouldBackdropClose']
        }], hasConfirmButton: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['hasConfirmButton']
        }], isOnSearchEnabled: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['isOnSearchEnabled']
        }], canClear: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-can-clear']
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['canClear']
        }], isMultiple: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['isMultiple']
        }], canAddItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"],
            args: ['canAddItem']
        }], _isIos: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-ios']
        }], _isMD: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostBinding"],
            args: ['class.ionic-selectable-md']
        }], valueTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_value_template_directive__WEBPACK_IMPORTED_MODULE_17__["IonicSelectableValueTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], itemTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_item_template_directive__WEBPACK_IMPORTED_MODULE_11__["IonicSelectableItemTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], itemEndTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_item_end_template_directive__WEBPACK_IMPORTED_MODULE_9__["IonicSelectableItemEndTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], titleTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_title_template_directive__WEBPACK_IMPORTED_MODULE_16__["IonicSelectableTitleTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], placeholderTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_placeholder_template_directive__WEBPACK_IMPORTED_MODULE_14__["IonicSelectablePlaceholderTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], messageTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_message_template_directive__WEBPACK_IMPORTED_MODULE_12__["IonicSelectableMessageTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], groupTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_group_template_directive__WEBPACK_IMPORTED_MODULE_7__["IonicSelectableGroupTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], groupEndTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_group_end_template_directive__WEBPACK_IMPORTED_MODULE_6__["IonicSelectableGroupEndTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], closeButtonTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_close_button_template_directive__WEBPACK_IMPORTED_MODULE_4__["IonicSelectableCloseButtonTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], searchFailTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_search_fail_template_directive__WEBPACK_IMPORTED_MODULE_15__["IonicSelectableSearchFailTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], addItemTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_add_item_template_directive__WEBPACK_IMPORTED_MODULE_3__["IonicSelectableAddItemTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], footerTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_footer_template_directive__WEBPACK_IMPORTED_MODULE_5__["IonicSelectableFooterTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], headerTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_header_template_directive__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableHeaderTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], itemIconTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_item_icon_template_directive__WEBPACK_IMPORTED_MODULE_10__["IonicSelectableItemIconTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }], iconTemplate: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChild"],
            args: [_ionic_selectable_icon_template_directive__WEBPACK_IMPORTED_MODULE_18__["IonicSelectableIconTemplateDirective"], { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"] }]
        }] }); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS5jb21wb25lbnQuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLDJDQUEyQztBQUMzQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBVyxVQUFVLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFrQixlQUFlLEVBQVUsUUFBUSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ2pPLE9BQU8sRUFBd0IsaUJBQWlCLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUN6RSxPQUFPLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxRQUFRLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUdwRSxPQUFPLEVBQUUsdUNBQXVDLEVBQUUsTUFBTSxnREFBZ0QsQ0FBQztBQUN6RyxPQUFPLEVBQUUsMkNBQTJDLEVBQUUsTUFBTSxvREFBb0QsQ0FBQztBQUNqSCxPQUFPLEVBQUUsc0NBQXNDLEVBQUUsTUFBTSw4Q0FBOEMsQ0FBQztBQUN0RyxPQUFPLEVBQUUsd0NBQXdDLEVBQUUsTUFBTSxpREFBaUQsQ0FBQztBQUMzRyxPQUFPLEVBQUUscUNBQXFDLEVBQUUsTUFBTSw2Q0FBNkMsQ0FBQztBQUNwRyxPQUFPLEVBQUUsc0NBQXNDLEVBQUUsTUFBTSw4Q0FBOEMsQ0FBQztBQUN0RyxPQUFPLEVBQUUsdUNBQXVDLEVBQUUsTUFBTSxnREFBZ0QsQ0FBQztBQUN6RyxPQUFPLEVBQUUsd0NBQXdDLEVBQUUsTUFBTSxpREFBaUQsQ0FBQztBQUMzRyxPQUFPLEVBQUUsb0NBQW9DLEVBQUUsTUFBTSw0Q0FBNEMsQ0FBQztBQUNsRyxPQUFPLEVBQUUsdUNBQXVDLEVBQUUsTUFBTSwrQ0FBK0MsQ0FBQztBQUN4RyxPQUFPLEVBQUUsNkJBQTZCLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUNuRixPQUFPLEVBQUUsMkNBQTJDLEVBQUUsTUFBTSxtREFBbUQsQ0FBQztBQUNoSCxPQUFPLEVBQUUsMENBQTBDLEVBQUUsTUFBTSxtREFBbUQsQ0FBQztBQUMvRyxPQUFPLEVBQUUscUNBQXFDLEVBQUUsTUFBTSw2Q0FBNkMsQ0FBQztBQUNwRyxPQUFPLEVBQUUscUNBQXFDLEVBQUUsTUFBTSw2Q0FBNkMsQ0FBQztBQUNwRyxPQUFPLEVBQUUsb0NBQW9DLEVBQUUsTUFBTSw0Q0FBNEMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFhbEcsTUFBTSxPQUFPLHdCQUF3QjtBQUFHLElBOHZCdEMsWUFDVSxnQkFBaUMsRUFDakMsU0FBbUIsRUFDUCxPQUFnQixFQUM1QixnQkFBaUMsRUFDakMsUUFBb0IsRUFDcEIsU0FBb0I7QUFDN0IsUUFOUyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO0FBQUMsUUFDbEMsY0FBUyxHQUFULFNBQVMsQ0FBVTtBQUFDLFFBQ1IsWUFBTyxHQUFQLE9BQU8sQ0FBUztBQUFDLFFBQzdCLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7QUFBQyxRQUNsQyxhQUFRLEdBQVIsUUFBUSxDQUFZO0FBQUMsUUFDckIsY0FBUyxHQUFULFNBQVMsQ0FBVztBQUNoQyxRQW53QkUsY0FBUyxHQUFHLElBQUksQ0FBQztBQUNuQixRQW9DVSx1QkFBa0IsR0FBRyxJQUFJLENBQUM7QUFDcEMsUUFBVSxlQUFVLEdBQUcsSUFBSSxDQUFDO0FBQzVCLFFBQVUseUJBQW9CLEdBQUcsSUFBSSxDQUFDO0FBQ3RDLFFBQVUsY0FBUyxHQUFHLEtBQUssQ0FBQztBQUM1QixRQUFVLFdBQU0sR0FBUSxJQUFJLENBQUM7QUFDN0IsUUFHVSxjQUFTLEdBQUcsS0FBSyxDQUFDO0FBQzVCLFFBQVUsc0JBQWlCLEdBQUcsS0FBSyxDQUFDO0FBQ3BDLFFBQVUsZ0JBQVcsR0FBRyxLQUFLLENBQUM7QUFDOUIsUUFBVSxnQkFBVyxHQUFHLEtBQUssQ0FBQztBQUM5QixRQUVVLGtCQUFhLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7QUFDaEUsUUFFVSxpQkFBWSxHQUFHLEtBQUssQ0FBQztBQUMvQixRQUFVLHNCQUFpQixHQUF3RCxJQUFJLENBQUM7QUFDeEYsUUFBVSxXQUFNLEdBQVcsSUFBSSxDQUFDO0FBQ2hDLFFBT0UsZ0JBQVcsR0FBVSxFQUFFLENBQUM7QUFDMUIsUUFBRSxnQkFBVyxHQUFHLEVBQUUsQ0FBQztBQUNuQixRQUFFLG1CQUFjLEdBQUcsS0FBSyxDQUFDO0FBQ3pCLFFBQUUsWUFBTyxHQUFVLEVBQUUsQ0FBQztBQUN0QixRQUFFLG9CQUFlLEdBQVUsRUFBRSxDQUFDO0FBQzlCLFFBQUUsbUJBQWMsR0FBVSxFQUFFLENBQUM7QUFDN0IsUUFDRSxvQkFBZSxHQUFVLEVBQUUsQ0FBQztBQUM5QixRQUdFLDhCQUF5QixHQUFHLEtBQUssQ0FBQztBQUNwQyxRQUFFLHFCQUFnQixHQUFHLElBQUksQ0FBQztBQUMxQixRQUFFLGVBQVUsR0FBUSxJQUFJLENBQUM7QUFDekIsUUFBRSx3QkFBbUIsR0FBRyxDQUFDLENBQUM7QUFDMUIsUUFBRSxzQkFBaUIsR0FBRyxLQUFLLENBQUM7QUFDNUIsUUE0RUU7QUFDRjtBQUNNO0FBRUM7QUFDTjtBQUF1QjtBQUdYLFdBRlI7QUFDTCxRQUNFLFVBQUssR0FBVSxFQUFFLENBQUM7QUFDcEIsUUFDRSxnQkFBVyxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO0FBQ3RELFFBaUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFDTTtBQUdYLFdBRlI7QUFDTCxRQUNFLGtCQUFhLEdBQVcsSUFBSSxDQUFDO0FBQy9CLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0Usd0JBQW1CLEdBQXFCLElBQUksQ0FBQztBQUMvQyxRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFDTTtBQUdYLFdBRlI7QUFDTCxRQUNFLHdCQUFtQixHQUFxQixJQUFJLENBQUM7QUFDL0MsUUFhRTtBQUNGO0FBQ007QUFFQztBQUFXO0FBQ007QUFHWCxXQUZSO0FBQ0wsUUFDRSwyQkFBc0IsR0FBRyxJQUFJLENBQUM7QUFDaEMsUUFtQkU7QUFDRjtBQUNNO0FBQ007QUFFQztBQUNSO0FBQXlCO0FBR1gsV0FGZDtBQUNMLFFBQ0UsbUJBQWMsR0FBVyxJQUFJLENBQUM7QUFDaEMsUUFDRTtBQUNGO0FBQ007QUFDTTtBQUVDO0FBQ1Q7QUFBMEI7QUFHWCxXQUZkO0FBQ0wsUUFDRSxrQkFBYSxHQUFXLElBQUksQ0FBQztBQUMvQixRQUNFO0FBQ0Y7QUFDTTtBQUNNO0FBQ007QUFHbEI7QUFBVztBQUF5QjtBQUdYLFdBRnBCO0FBQ0wsUUFDRSxvQkFBZSxHQUFXLElBQUksQ0FBQztBQUNqQyxRQUNFO0FBQ0Y7QUFDTTtBQUNNO0FBR1o7QUFBUTtBQUFzQjtBQUdSLFFBRnBCO0FBQ0YsUUFDRSxtQkFBYyxHQUFXLElBQUksQ0FBQztBQUNoQyxRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFDTTtBQUdYLFdBRlI7QUFDTCxRQUNFLGNBQVMsR0FBRyxLQUFLLENBQUM7QUFDcEIsUUFpQ0U7QUFDRjtBQUNNO0FBQ007QUFFQztBQUNUO0FBQTBCO0FBR1gsV0FGZDtBQUNMLFFBQ0Usc0JBQWlCLEdBQUcsS0FBSyxDQUFDO0FBQzVCLFFBQ0U7QUFDRjtBQUNNO0FBQ007QUFFQztBQUNUO0FBQTBCO0FBR1gsV0FGZDtBQUNMLFFBQ0UscUJBQWdCLEdBQUcsS0FBSyxDQUFDO0FBQzNCLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0Usa0NBQTZCLEdBQUcsTUFBTSxDQUFDO0FBQ3pDLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0Usc0JBQWlCLEdBQUcsUUFBUSxDQUFDO0FBQy9CLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0UsZ0JBQVcsR0FBVyxJQUFJLENBQUM7QUFDN0IsUUFpQkU7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0UsbUJBQWMsR0FBRyxpQkFBaUIsQ0FBQztBQUNyQyxRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFDTTtBQUdYLFdBRlI7QUFDTCxRQUNFLG9CQUFlLEdBQUcsT0FBTyxDQUFDO0FBQzVCLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0Usa0JBQWEsR0FBRyxLQUFLLENBQUM7QUFDeEIsUUFDRTtBQUNGO0FBQ007QUFFQztBQUFXO0FBQ007QUFHWCxXQUZSO0FBQ0wsUUFDRSxzQkFBaUIsR0FBRyxJQUFJLENBQUM7QUFDM0IsUUFDRTtBQUNGO0FBQ007QUFDTTtBQUVDO0FBQ1o7QUFBNkI7QUFHWCxXQUZkO0FBQ0wsUUFDRSxvQkFBZSxHQUFHLFFBQVEsQ0FBQztBQUM3QixRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFDTTtBQUdYLFdBRlI7QUFDTCxRQUNFLHlCQUFvQixHQUFHLEtBQUssQ0FBQztBQUMvQixRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFDTTtBQUdYLFdBRlI7QUFDTCxRQUNFLGdCQUFXLEdBQVcsSUFBSSxDQUFDO0FBQzdCLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0UsZUFBVSxHQUFXLElBQUksQ0FBQztBQUM1QixRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFDTTtBQUdYLFdBRlI7QUFDTCxRQUNFLG9CQUFlLEdBQUcsT0FBTyxDQUFDO0FBQzVCLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0UsaUJBQVksR0FBRyxPQUFPLENBQUM7QUFDekIsUUFDRTtBQUNGO0FBQ007QUFFQztBQUFXO0FBR1osV0FGRDtBQUNMLFFBQ0UsYUFBUSxHQUFzRSxJQUFJLFlBQVksRUFBRSxDQUFDO0FBQ25HLFFBQ0U7QUFDRjtBQUNNO0FBQ007QUFFQztBQUFXO0FBR1osV0FGUDtBQUNMLFFBQ0UsYUFBUSxHQUF3RSxJQUFJLFlBQVksRUFBRSxDQUFDO0FBQ3JHLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUdaLFdBRkQ7QUFDTCxRQUNFLGlCQUFZLEdBQXdFLElBQUksWUFBWSxFQUFFLENBQUM7QUFDekcsUUFDRTtBQUNGO0FBQ007QUFFQztBQUFXO0FBR1osV0FGRDtBQUNMLFFBQ0Usb0JBQWUsR0FBd0UsSUFBSSxZQUFZLEVBQUUsQ0FBQztBQUM1RyxRQUNFO0FBQ0Y7QUFDTTtBQUNNO0FBRUM7QUFBVztBQUdaLFdBRlA7QUFDTCxRQUNFLHFCQUFnQixHQUF3RSxJQUFJLFlBQVksRUFBRSxDQUFDO0FBQzdHLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUdaLFdBRkQ7QUFDTCxRQUNFLFdBQU0sR0FBMEQsSUFBSSxZQUFZLEVBQUUsQ0FBQztBQUNyRixRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFHWixXQUZEO0FBQ0wsUUFDRSxZQUFPLEdBQTBELElBQUksWUFBWSxFQUFFLENBQUM7QUFDdEYsUUFDRTtBQUNGO0FBQ007QUFFQztBQUFXO0FBR1osV0FGRDtBQUNMLFFBQ0UsYUFBUSxHQUEwRixJQUFJLFlBQVksRUFBRSxDQUFDO0FBQ3ZILFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUdaLFdBRkQ7QUFDTCxRQUNFLFlBQU8sR0FBd0UsSUFBSSxZQUFZLEVBQUUsQ0FBQztBQUNwRyxRQWNFO0FBQ0Y7QUFDTTtBQUVDO0FBQ1A7QUFBd0I7QUFHWCxXQUZSO0FBQ0wsUUFDRSxtQkFBYyxHQUFXLEdBQUcsQ0FBQztBQUMvQixRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQ047QUFBdUI7QUFHWCxXQUZSO0FBQ0wsUUFDRSxrQkFBYSxHQUFVLEVBQUUsQ0FBQztBQUM1QixRQUNFO0FBQ0Y7QUFDTTtBQUNNO0FBRUM7QUFDVDtBQUEwQjtBQUdYLFdBRmQ7QUFDTCxRQUNFLHlCQUFvQixHQUFHLEtBQUssQ0FBQztBQUMvQixRQUNFO0FBQ0Y7QUFDTTtBQUVDO0FBQVc7QUFDTTtBQUdYLFdBRlI7QUFDTCxRQUNFLGdCQUFXLEdBQUcsS0FBSyxDQUFDO0FBQ3RCLFFBQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUNNO0FBR1gsV0FGUjtBQUNMLFFBQ0Usa0JBQWEsR0FBRyxLQUFLLENBQUM7QUFDeEIsUUFpQkU7QUFDRjtBQUNNO0FBQ007QUFDTTtBQUVDO0FBQVc7QUFHWixXQUZiO0FBQ0wsUUFDRSxlQUFVLEdBQXFFLElBQUksWUFBWSxFQUFFLENBQUM7QUFDcEcsUUFDRTtBQUNGO0FBQ007QUFDTTtBQUVDO0FBQVc7QUFHWixXQUZQO0FBQ0wsUUFDRSxpQkFBWSxHQUFxRSxJQUFJLFlBQVksRUFBRSxDQUFDO0FBQ3RHLFFBQ0U7QUFDRjtBQUNNO0FBQ007QUFDTTtBQUVDO0FBQVc7QUFHWixXQUZiO0FBQ0wsUUFDRSxjQUFTLEdBQTBELElBQUksWUFBWSxFQUFFLENBQUM7QUFDeEYsUUFpQ0U7QUFDRjtBQUNNO0FBRUM7QUFBVztBQUdYLFdBRkY7QUFDTCxRQUNFLDBCQUFxQixHQUFHLEdBQUcsRUFBRTtBQUMvQixZQUFJLE9BQU8sSUFBSSxDQUFDO0FBQ2hCLFFBQUUsQ0FBQyxDQUFBO0FBQ0gsUUF3ZVUsc0JBQWlCLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztBQUM5QyxRQUFVLHVCQUFrQixHQUFHLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztBQUN6QyxRQWplSSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFO0FBQzNDLFlBQU0sSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7QUFDdEIsU0FBSztBQUNMLFFBQ0ksSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUN4RSxJQUFFLENBQUM7QUFDSCxJQXJ3QkUsSUFDSSxtQkFBbUI7QUFBSyxRQUMxQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUM7QUFDM0IsSUFBRSxDQUFDO0FBQ0gsSUFBRSxJQUNJLGlCQUFpQjtBQUFLLFFBQ3hCLE9BQU8sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzNCLElBQUUsQ0FBQztBQUNILElBQUUsSUFDSSx1QkFBdUI7QUFBSyxRQUM5QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7QUFDaEMsSUFBRSxDQUFDO0FBQ0gsSUFBRSxJQUNJLG9CQUFvQjtBQUFLLFFBQzNCLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztBQUM3QixJQUFFLENBQUM7QUFDSCxJQUFFLElBQ0ksMkJBQTJCO0FBQUssUUFDbEMsT0FBTyxJQUFJLENBQUMsaUJBQWlCLEtBQUssU0FBUyxDQUFDO0FBQ2hELElBQUUsQ0FBQztBQUNILElBQUUsSUFDSSx5QkFBeUI7QUFBSyxRQUNoQyxPQUFPLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxPQUFPLENBQUM7QUFDOUMsSUFBRSxDQUFDO0FBQ0gsSUFBRSxJQUNJLDJCQUEyQjtBQUFLLFFBQ2xDLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixLQUFLLFNBQVMsQ0FBQztBQUNoRCxJQUFFLENBQUM7QUFDSCxJQUFFLElBQ0ksNEJBQTRCO0FBQUssUUFDbkMsT0FBTyxJQUFJLENBQUMsaUJBQWlCLEtBQUssVUFBVSxDQUFDO0FBQ2pELElBQUUsQ0FBQztBQUNILElBb0JFLElBQVksa0JBQWtCO0FBQUssUUFDakMsT0FBTyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxlQUFlO0FBQ2pELFlBQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzFELElBQUUsQ0FBQztBQUNILElBQUUsSUFBSSxxQkFBcUI7QUFBSyxRQUM1QixPQUFPLElBQUksQ0FBQyxvQkFBb0IsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDO0FBQ3pELElBQUUsQ0FBQztBQUNILElBaUJFO0FBQ0Y7QUFDRTtBQUNFO0FBQ0U7QUFDRTtBQUNFO0FBRUosT0FERDtBQUNMLElBQUUsSUFBSSxLQUFLO0FBQUssUUFDWixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDdkIsSUFBRSxDQUFDO0FBQ0gsSUFDRTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREQ7QUFDTCxJQUFFLElBQUksVUFBVTtBQUFLLFFBQ2pCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUM1QixJQUFFLENBQUM7QUFDSCxJQUFFLElBQUksVUFBVSxDQUFDLFVBQWtCO0FBQ25DLFFBQUksSUFBSSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUM7QUFDbEMsUUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztBQUM3QixJQUFFLENBQUM7QUFDSCxJQUNFO0FBQ0Y7QUFDRTtBQUNFO0FBQ0U7QUFDRTtBQUNFO0FBRUosT0FERDtBQUNMLElBQUUsSUFBSSxXQUFXO0FBQUssUUFDbEIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0FBQzdCLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUNFO0FBQ0U7QUFFSixPQUREO0FBQ0wsSUFBRSxJQUFJLGFBQWE7QUFBSyxRQUNwQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7QUFDL0IsSUFBRSxDQUFDO0FBQ0gsSUFDRSxJQUFJLEtBQUs7QUFBSyxRQUNaLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUN2QixJQUFFLENBQUM7QUFDSCxJQUFFLElBQUksS0FBSyxDQUFDLEtBQVU7QUFDdEIsUUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztBQUN4QixRQUNJLG1CQUFtQjtBQUN2QixRQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3hELFFBQ0ksSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQ3pCLFlBQU0sSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRTtBQUNqQyxnQkFBUSxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUM1RCxhQUFPO0FBQ1AsU0FBSztBQUFDLGFBQUs7QUFDWCxZQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDNUMsZ0JBQVEsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckMsYUFBTztBQUNQLFNBQUs7QUFDTCxRQUNJLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0FBQy9CLFFBQUksSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7QUFDOUIsSUFBRSxDQUFDO0FBQ0gsSUFhRTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBQ0U7QUFFSixPQURDO0FBQ0wsSUFBRSxJQUVJLFNBQVM7QUFBSyxRQUNoQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUM7QUFDM0IsSUFBRSxDQUFDO0FBQ0gsSUFBRSxJQUFJLFNBQVMsQ0FBQyxTQUFrQjtBQUNsQyxRQUFJLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNsQyxRQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3hDLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUNFO0FBRUosT0FEQztBQUNMLElBQUUsSUFDSSxtQkFBbUI7QUFBSyxRQUMxQixPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztBQUNyQyxJQUFFLENBQUM7QUFDSCxJQUFFLElBQUksbUJBQW1CLENBQUMsbUJBQTRCO0FBQ3RELFFBQUksSUFBSSxDQUFDLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztBQUN0RCxJQUFFLENBQUM7QUFDSCxJQStCRTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREQ7QUFDTCxJQUFFLElBQUksUUFBUTtBQUFLLFFBQ2YsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0FBQzFCLElBQUUsQ0FBQztBQUNILElBV0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUVEO0FBQUs7QUFDRTtBQUVGLEtBRFA7QUFDSCxJQUFFLElBQ0ksZ0JBQWdCO0FBQUssUUFDdkIsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUM7QUFDbEMsSUFBRSxDQUFDO0FBQ0gsSUFBRSxJQUFJLGdCQUFnQixDQUFDLGdCQUF5QjtBQUNoRCxRQUFJLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDaEQsUUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztBQUMvQixJQUFFLENBQUM7QUFDSCxJQXdERTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBQ0U7QUFFSixPQURDO0FBQ0wsSUFBRSxJQUNJLGlCQUFpQjtBQUFLLFFBQ3hCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDO0FBQ25DLElBQUUsQ0FBQztBQUNILElBQUUsSUFBSSxpQkFBaUIsQ0FBQyxpQkFBMEI7QUFDbEQsUUFBSSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO0FBQ2xELElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUNFO0FBRUosT0FEQztBQUNMLElBQUUsSUFFSSxRQUFRO0FBQUssUUFDZixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUM7QUFDMUIsSUFBRSxDQUFDO0FBQ0gsSUFBRSxJQUFJLFFBQVEsQ0FBQyxRQUFpQjtBQUNoQyxRQUFJLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNoQyxRQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0FBQy9CLElBQUUsQ0FBQztBQUNILElBcURFO0FBQ0Y7QUFDRTtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREM7QUFDTCxJQUFFLElBQ0ksVUFBVTtBQUFLLFFBQ2pCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUM1QixJQUFFLENBQUM7QUFDSCxJQUFFLElBQUksVUFBVSxDQUFDLFVBQW1CO0FBQ3BDLFFBQUksSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3BDLFFBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7QUFDL0IsSUFBRSxDQUFDO0FBQ0gsSUF5TEU7QUFDRjtBQUNFO0FBQ0U7QUFFSDtBQUFPO0FBQ0U7QUFDRTtBQUVKLE9BREg7QUFDTCxJQUFFLElBQUksY0FBYztBQUFLLFFBQ3JCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztBQUNoQyxJQUFFLENBQUM7QUFDSCxJQW9ERTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBQ0U7QUFFSixPQURDO0FBQ0wsSUFBRSxJQUNJLFVBQVU7QUFBSyxRQUNqQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7QUFDNUIsSUFBRSxDQUFDO0FBQ0gsSUFBRSxJQUFJLFVBQVUsQ0FBQyxVQUFtQjtBQUNwQyxRQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNwQyxRQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0FBQy9CLElBQUUsQ0FBQztBQUNILElBMkZFLFNBQVMsS0FBSyxDQUFDO0FBQ2pCLElBQ0UsYUFBYSxDQUFDLFNBQWtCO0FBQ2xDLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDdkIsWUFBTSxPQUFPO0FBQ2IsU0FBSztBQUNMLFFBQ0ksSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxTQUFTLENBQUM7QUFDdkMsSUFBRSxDQUFDO0FBQ0gsSUFDRSxtQkFBbUIsQ0FBQyxLQUFVO0FBQUksUUFDaEMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUU7QUFDL0MsWUFBTSxPQUFPLElBQUksQ0FBQztBQUNsQixTQUFLO0FBQ0wsUUFDSSwrQ0FBK0M7QUFDbkQsUUFBSSxPQUFPLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDMUQsSUFBRSxDQUFDO0FBQ0gsSUFDRSxpQkFBaUI7QUFDbkIsUUFBSSxJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUN0RSxJQUFFLENBQUM7QUFDSCxJQUNFLFlBQVk7QUFBSyxRQUNmLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDeEUsSUFBRSxDQUFDO0FBQ0gsSUFDRSxjQUFjO0FBQUssUUFDakIsT0FBTyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDcEUsSUFBRSxDQUFDO0FBQ0gsSUFDRSxhQUFhO0FBQUssUUFDaEIsT0FBTyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDbEUsSUFBRSxDQUFDO0FBQ0gsSUFDRSxnQkFBZ0I7QUFBSyxRQUNuQixPQUFPLElBQUksQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUN4RSxJQUFFLENBQUM7QUFDSCxJQUNFLGdCQUFnQjtBQUNsQixRQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkMsUUFDSSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUN2QixZQUFNLFNBQVMsRUFBRSxJQUFJO0FBQ3JCLFlBQU0sS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO0FBQ3ZCLFNBQUssQ0FBQyxDQUFDO0FBQ1AsSUFBRSxDQUFDO0FBQ0gsSUFDRSxXQUFXO0FBQ2IsUUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtBQUN6QixZQUFNLE9BQU87QUFDYixTQUFLO0FBQ0wsUUFDSSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUN2QixZQUFNLFNBQVMsRUFBRSxJQUFJO0FBQ3JCLFlBQU0sSUFBSSxFQUFFLElBQUksQ0FBQyxXQUFXO0FBQzVCLFNBQUssQ0FBQyxDQUFDO0FBQ1AsSUFBRSxDQUFDO0FBQ0gsSUFDRSxhQUFhLENBQUMsSUFBUyxFQUFFLFVBQW1CO0FBQzlDLFFBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7QUFDdkIsWUFBTSxTQUFTLEVBQUUsSUFBSTtBQUNyQixZQUFNLElBQUksRUFBRSxJQUFJO0FBQ2hCLFlBQU0sVUFBVSxFQUFFLFVBQVU7QUFDNUIsU0FBSyxDQUFDLENBQUM7QUFDUCxJQUFFLENBQUM7QUFDSCxJQUNFLFlBQVksQ0FBQyxLQUFZO0FBQzNCLFFBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDdEIsWUFBTSxTQUFTLEVBQUUsSUFBSTtBQUNyQixZQUFNLEtBQUssRUFBRSxLQUFLO0FBQ2xCLFNBQUssQ0FBQyxDQUFDO0FBQ1AsSUFBRSxDQUFDO0FBQ0gsSUFDRSwwQkFBMEIsQ0FBQyxTQUFrQjtBQUMvQyxRQUFJLE1BQU0sU0FBUyxHQUFHO0FBQ3RCLFlBQU0sU0FBUyxFQUFFLElBQUk7QUFDckIsWUFBTSxJQUFJLEVBQUUsSUFBSSxDQUFDLFdBQVc7QUFDNUIsU0FBSyxDQUFDO0FBQ04sUUFDSSxJQUFJLFNBQVMsRUFBRTtBQUNuQixZQUFNLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQzNDLFNBQUs7QUFBQyxhQUFLO0FBQ1gsWUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN4QyxTQUFLO0FBQ0wsSUFBRSxDQUFDO0FBQ0gsSUFDRSxXQUFXLENBQUMsSUFBUztBQUFJLFFBQ3ZCLElBQUksSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3hDLFlBQU0sT0FBTyxJQUFJLENBQUM7QUFDbEIsU0FBSztBQUNMLFFBQ0ksT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDM0UsSUFBRSxDQUFDO0FBQ0gsSUFDRSxnQkFBZ0IsQ0FBQyxJQUFTO0FBQUksUUFDNUIsSUFBSSxJQUFJLENBQUMscUJBQXFCLEVBQUU7QUFDcEMsWUFBTSwyREFBMkQ7QUFDakUsWUFBTSxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUNuRCxnQkFBUSxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssSUFBSSxDQUFDO0FBQ25ELFlBQU0sQ0FBQyxDQUFDLENBQUM7QUFDVCxZQUNNLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUM1QyxTQUFLO0FBQUMsYUFBSztBQUNYLFlBQU0sT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BDLFNBQUs7QUFDTCxJQUFFLENBQUM7QUFDSCxJQUNFLGFBQWEsQ0FBQyxJQUFTO0FBQUksUUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7QUFDM0IsWUFBTSxPQUFPLElBQUksQ0FBQztBQUNsQixTQUFLO0FBQ0wsUUFDSSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDckMsSUFBRSxDQUFDO0FBQ0gsSUFDRSxtQkFBbUIsQ0FBQyxJQUFTO0FBQUksUUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7QUFDM0IsWUFBTSxPQUFPLElBQUksQ0FBQztBQUNsQixTQUFLO0FBQ0wsUUFDSSxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ3pFLElBQUUsQ0FBQztBQUNILElBQ0UsaUJBQWlCO0FBQ25CLFFBQUkseURBQXlEO0FBQzdELFFBQUksbUJBQW1CO0FBQ3ZCLFFBQUksSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDMUIsSUFBRSxDQUFDO0FBQ0gsSUFDRSxZQUFZO0FBQ2QsUUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztBQUM3QixRQUNJLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO0FBQzdCLFlBQU0sbUNBQW1DO0FBQ3pDLFlBQU0sSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0FBQ3pCLFNBQUs7QUFBQyxhQUFLO0FBQ1gsWUFBTSxxQkFBcUI7QUFDM0IsWUFBTSxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDdEIsWUFDTSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLEVBQUU7QUFDekQsZ0JBQVEsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDOUIsYUFBTztBQUFDLGlCQUFLO0FBQ2IsZ0JBQVEsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztBQUNqRSxnQkFDUSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUNyQyxvQkFBVSxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNsRCx3QkFBWSxNQUFNLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNsRCw0QkFBYyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztBQUN4RSx3QkFBWSxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDdkQsb0JBQVUsQ0FBQyxDQUFDLENBQUM7QUFDYixvQkFDVSxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUU7QUFDNUIsd0JBQVksTUFBTSxDQUFDLElBQUksQ0FBQztBQUN4Qiw0QkFBYyxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7QUFDaEMsNEJBQWMsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO0FBQzlCLDRCQUFjLEtBQUssRUFBRSxLQUFLO0FBQzFCLHlCQUFhLENBQUMsQ0FBQztBQUNmLHFCQUFXO0FBQ1gsZ0JBQVEsQ0FBQyxDQUFDLENBQUM7QUFDWCxnQkFDUSxrQkFBa0I7QUFDMUIsZ0JBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7QUFDNUIsb0JBQVUsTUFBTSxDQUFDLElBQUksQ0FBQztBQUN0Qix3QkFBWSxLQUFLLEVBQUUsRUFBRTtBQUNyQixxQkFBVyxDQUFDLENBQUM7QUFDYixpQkFBUztBQUNULGFBQU87QUFDUCxZQUNNLElBQUksQ0FBQyxlQUFlLEdBQUcsTUFBTSxDQUFDO0FBQ3BDLFlBQU0sSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3RCxZQUFNLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUM5RCxTQUFLO0FBQ0wsSUFBRSxDQUFDO0FBQ0gsSUFDRSxlQUFlLENBQUMsSUFBUztBQUFJLFFBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO0FBQzdCLFlBQU0sT0FBTztBQUNiLFNBQUs7QUFDTCxRQUNJLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDM0MsWUFBTSxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNwRSxRQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1AsSUFBRSxDQUFDO0FBQ0gsSUFDRSxlQUFlLENBQUMsSUFBUztBQUMzQixRQUFJLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7QUFDbkQsWUFBTSxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLG1CQUFtQixDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2pGLFFBQUksQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDO0FBQ3JCLElBQUUsQ0FBQztBQUNILElBQ0UsZ0JBQWdCLENBQUMsSUFBUztBQUM1QixRQUFJLElBQUksSUFBSSxDQUFDLHFCQUFxQixFQUFFO0FBQ3BDLFlBQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3pELFNBQUs7QUFBQyxhQUFLO0FBQ1gsWUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNyQyxTQUFLO0FBQ0wsSUFBRSxDQUFDO0FBQ0gsSUFDRSxtQkFBbUIsQ0FBQyxJQUFTO0FBQy9CLFFBQUksSUFBSSxpQkFBaUIsQ0FBQztBQUMxQixRQUNJLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxFQUFFLFNBQVMsRUFBRSxFQUFFO0FBQzVELFlBQU0sSUFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztBQUNoQyxnQkFBUSxJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxDQUFDLEVBQ3RDO0FBQ1IsZ0JBQVEsaUJBQWlCLEdBQUcsU0FBUyxDQUFDO0FBQ3RDLGFBQU87QUFDUCxRQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1AsUUFDSSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNyRCxJQUFFLENBQUM7QUFDSCxJQUNFLE1BQU07QUFDUixRQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO0FBQ3pCLFlBQU0sT0FBTztBQUNiLFNBQUs7QUFDTCxRQUNJLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0FBQ3ZDLFFBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFDMUIsWUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztBQUN2QixnQkFBUSxTQUFTLEVBQUUsSUFBSTtBQUN2QixhQUFPLENBQUMsQ0FBQztBQUNULFFBQUksQ0FBQyxDQUFDLENBQUM7QUFDUCxJQUFFLENBQUM7QUFDSCxJQUNFLFNBQVMsQ0FBQyxLQUFZLEVBQUUsSUFBUztBQUNuQyxRQUFJLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztBQUM1QixRQUFJLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO0FBQzNCLFFBQ0ksSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFLEVBQUU7QUFDL0IsWUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztBQUMzQixnQkFBUSxTQUFTLEVBQUUsSUFBSTtBQUN2QixnQkFBUSxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVU7QUFDN0IsYUFBTyxDQUFDLENBQUM7QUFDVCxTQUFLO0FBQUMsYUFBSztBQUNYLFlBQU0sSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7QUFDakMsU0FBSztBQUNMLElBQUUsQ0FBQztBQUNILElBQ0UsZ0JBQWdCLENBQUMsS0FBWSxFQUFFLElBQVM7QUFDMUMsUUFBSSxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7QUFDNUIsUUFBSSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztBQUMzQixRQUNJLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFLEVBQUU7QUFDakMsWUFBTSwyQkFBMkI7QUFDakMsWUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztBQUM3QixnQkFBUSxTQUFTLEVBQUUsSUFBSTtBQUN2QixnQkFBUSxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVU7QUFDN0IsYUFBTyxDQUFDLENBQUM7QUFDVCxTQUFLO0FBQUMsYUFBSztBQUNYLFlBQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdkMsU0FBSztBQUNMLElBQUUsQ0FBQztBQUNILElBQ0UsYUFBYTtBQUNmLFFBQUksSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFLEVBQUU7QUFDOUIsWUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztBQUMxQixnQkFBUSxTQUFTLEVBQUUsSUFBSTtBQUN2QixhQUFPLENBQUMsQ0FBQztBQUNULFNBQUs7QUFBQyxhQUFLO0FBQ1gsWUFBTSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztBQUNqQyxTQUFLO0FBQ0wsSUFBRSxDQUFDO0FBQ0gsSUFDRSx3QkFBd0I7QUFDMUIsUUFBSSxtQ0FBbUM7QUFDdkMsUUFBSSxVQUFVLENBQUMsR0FBRyxFQUFFO0FBQ3BCLFlBQU0sTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsYUFBYTtBQUNoRSxpQkFBUyxhQUFhLENBQUMsZ0RBQWdELENBQUMsQ0FBQztBQUN6RSxZQUNNLElBQUksQ0FBQyw0QkFBNEIsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLGVBQWUsTUFBTSxDQUFDLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDcEcsUUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7QUFDWixJQUFFLENBQUM7QUFDSCxJQUNFLE1BQU07QUFDUixRQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO0FBQzNCLFlBQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDeEIsZ0JBQVEsU0FBUyxFQUFFLElBQUk7QUFDdkIsYUFBTyxDQUFDLENBQUM7QUFDVCxRQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1AsUUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO0FBQzlCLFlBQU0sSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDNUIsWUFBTSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztBQUMvQixTQUFLO0FBQ0wsSUFBRSxDQUFDO0FBQ0gsSUFDRSxNQUFNO0FBQ1IsUUFBSSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO0FBQzlDLFFBQ0ksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQ2pCLFFBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7QUFDNUIsUUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ3JDLFFBQUksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFDM0IsWUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUN4QixnQkFBUSxTQUFTLEVBQUUsSUFBSTtBQUN2QixhQUFPLENBQUMsQ0FBQztBQUNULFFBQUksQ0FBQyxDQUFDLENBQUM7QUFDUCxJQUFFLENBQUM7QUFDSCxJQUNFLGFBQWE7QUFDZixRQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7QUFDL0IsWUFBTSxTQUFTLEVBQUUsSUFBSTtBQUNyQixZQUFNLElBQUksRUFBRSxJQUFJLENBQUMsV0FBVztBQUM1QixTQUFLLENBQUMsQ0FBQztBQUNQLElBQUUsQ0FBQztBQUNILElBQ0Usa0JBQWtCLENBQUMsS0FBWTtBQUNqQyxRQUFJLDJFQUEyRTtBQUMvRSxRQUFJLElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM1QyxJQUFFLENBQUM7QUFDSCxJQUNFLFNBQVMsQ0FBQyxZQUFpQjtBQUM3QixRQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDO0FBQzlCLFFBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7QUFDNUIsSUFBRSxDQUFDO0FBQ0gsSUFDRSxPQUFPLENBQUMsSUFBUztBQUNuQixRQUFJLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEQsUUFDSSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7QUFDekIsWUFBTSxJQUFJLGNBQWMsRUFBRTtBQUMxQixnQkFBUSxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkMsYUFBTztBQUFDLGlCQUFLO0FBQ2IsZ0JBQVEsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BDLGFBQU87QUFDUCxZQUNNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDbkQsWUFDTSwyRUFBMkU7QUFDakYsWUFBTSxvQkFBb0I7QUFDMUIsWUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ2hELFNBQUs7QUFBQyxhQUFLO0FBQ1gsWUFBTSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO0FBQ3hELGdCQUFRLHdEQUF3RDtBQUNoRSxnQkFBUSxvRUFBb0U7QUFDNUUsZ0JBQVEsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDakMsZ0JBQ1EsSUFBSSxjQUFjLEVBQUU7QUFDNUIsb0JBQVUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pDLGlCQUFTO0FBQUMscUJBQUs7QUFDZixvQkFBVSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEMsaUJBQVM7QUFDVCxnQkFDUSxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ3JELGdCQUNRLDJFQUEyRTtBQUNuRixnQkFBUSxvQkFBb0I7QUFDNUIsZ0JBQVEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUNsRCxhQUFPO0FBQUMsaUJBQUs7QUFDYixnQkFBUSxJQUFJLENBQUMsY0FBYyxFQUFFO0FBQzdCLG9CQUFVLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQ25DLG9CQUFVLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN0QyxvQkFDVSxpQ0FBaUM7QUFDM0Msb0JBQVUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDekMsb0JBQ1UsSUFBSSxJQUFJLENBQUMscUJBQXFCLEVBQUU7QUFDMUMsd0JBQVksSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDckQscUJBQVc7QUFBQyx5QkFBSztBQUNqQix3QkFBWSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pDLHFCQUFXO0FBQ1gsaUJBQVM7QUFDVCxnQkFDUSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7QUFDdEIsYUFBTztBQUNQLFNBQUs7QUFDTCxJQUFFLENBQUM7QUFDSCxJQUNFLFFBQVE7QUFDVixRQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUNuQixRQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUNsQixJQUFFLENBQUM7QUFDSCxJQUNVLGFBQWE7QUFBSyxRQUN4QixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzVFLElBQUUsQ0FBQztBQUNILElBQ1UsZUFBZSxDQUFDLE1BQU07QUFDaEMsUUFBSSxPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDdkQsWUFBTSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUM7QUFDdEQsUUFBSSxDQUFDLENBQUMsQ0FBQztBQUNQLElBQUUsQ0FBQztBQUNILElBQ1UsbUJBQW1CO0FBQzdCLFFBQUksSUFBSSxrQkFBa0IsR0FBRyxDQUFDLENBQUM7QUFDL0IsUUFDSSxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7QUFDdkIsWUFBTSxrQkFBa0IsRUFBRSxDQUFDO0FBQzNCLFNBQUs7QUFDTCxRQUNJLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7QUFDbkQsWUFBTSxrQkFBa0IsRUFBRSxDQUFDO0FBQzNCLFNBQUs7QUFDTCxRQUNJLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtBQUN6QixZQUFNLGtCQUFrQixFQUFFLENBQUM7QUFDM0IsU0FBSztBQUNMLFFBQ0ksSUFBSSxDQUFDLG1CQUFtQixHQUFHLGtCQUFrQixDQUFDO0FBQ2xELElBQUUsQ0FBQztBQUNILElBQ1UsU0FBUyxDQUFDLEtBQVk7QUFDaEMsUUFBSSxxRkFBcUY7QUFDekYsUUFBSSxrREFBa0Q7QUFDdEQsUUFBSSxnRUFBZ0U7QUFDcEUsUUFBSSxJQUFJLE1BQU0sR0FBVSxDQUFDO0FBQ3pCLGdCQUFNLEtBQUssRUFBRSxLQUFLLElBQUksRUFBRTtBQUN4QixhQUFLLENBQUMsQ0FBQztBQUNQLFFBQ0ksSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRTtBQUMvQixZQUFNLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtBQUMzQixnQkFBUSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3BCLGdCQUNRLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDN0Isb0JBQVUsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQ25FLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxVQUFVLENBQUMsQ0FBQztBQUN2RSxvQkFDVSxJQUFJLEtBQUssRUFBRTtBQUNyQix3QkFBWSxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxxQkFBVztBQUFDLHlCQUFLO0FBQ2pCLHdCQUFZLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDeEIsNEJBQWMsS0FBSyxFQUFFLFVBQVU7QUFDL0IsNEJBQWMsSUFBSSxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQztBQUNyRSw0QkFBYyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUM7QUFDM0IseUJBQWEsQ0FBQyxDQUFDO0FBQ2YscUJBQVc7QUFDWCxnQkFBUSxDQUFDLENBQUMsQ0FBQztBQUNYLGFBQU87QUFDUCxTQUFLO0FBQ0wsUUFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztBQUMxQixRQUFJLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUN4QyxRQUFJLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQ3pFLElBQUUsQ0FBQztBQUNILElBQ1UsaUJBQWlCLENBQUMsTUFBVyxFQUFFLFFBQWdCO0FBQUksUUFDekQsSUFBSSxDQUFDLFFBQVEsRUFBRTtBQUNuQixZQUFNLE9BQU8sSUFBSSxDQUFDO0FBQ2xCLFNBQUs7QUFDTCxRQUNJLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUU7QUFDN0QsWUFBTSxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakQsUUFBSSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDZixJQUFFLENBQUM7QUFDSCxJQUNVLG1CQUFtQixDQUFDLFFBQWlCO0FBQy9DLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDdkIsWUFBTSxPQUFPO0FBQ2IsU0FBSztBQUNMLFFBQ0ksbUVBQW1FO0FBQ3ZFLFFBQUksSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQ3pELElBQUUsQ0FBQztBQUNILElBQ1UsbUJBQW1CO0FBQzdCLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDdkIsWUFBTSxPQUFPO0FBQ2IsU0FBSztBQUNMLFFBQ0ksbUVBQW1FO0FBQ3ZFLFFBQUksSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0FBQ2hFLElBQUUsQ0FBQztBQUNILElBQ1Usa0JBQWtCO0FBQzVCLFFBQUksSUFBSSxDQUFDLGVBQWUsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7QUFDM0MsWUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0FBQ2pGLFlBQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbkIsSUFBRSxDQUFDO0FBQ0gsSUFJVSxtQkFBbUIsQ0FBQyxRQUFnQixFQUFFLFNBQWtCO0FBQ2xFLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7QUFDL0IsWUFBTSxPQUFPO0FBQ2IsU0FBSztBQUNMLFFBQ0ksc0JBQXNCO0FBQzFCLFFBQUksSUFBSSxTQUFTLEVBQUU7QUFDbkIsWUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQzlELFNBQUs7QUFBQyxhQUFLO0FBQ1gsWUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQ2pFLFNBQUs7QUFDTCxJQUFFLENBQUM7QUFDSCxJQUNVLHNCQUFzQixDQUFDLFNBQWtCO0FBQ25ELFFBQUksNkRBQTZEO0FBQ2pFLFFBQUksbUVBQW1FO0FBQ3ZFLFFBQUksZ0ZBQWdGO0FBQ3BGLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7QUFDL0IsWUFBTSxPQUFPO0FBQ2IsU0FBSztBQUNMLFFBQ0ksNEVBQTRFO0FBQ2hGLFFBQUksNEVBQTRFO0FBQ2hGLFFBQUksSUFBSSxDQUFDLHlCQUF5QixHQUFHLFNBQVMsQ0FBQztBQUMvQyxRQUFJLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLFNBQVMsQ0FBQztBQUN2QyxJQUFFLENBQUM7QUFDSCxJQUNFLDBCQUEwQjtBQUM1QixJQUFFLFVBQVUsQ0FBQyxLQUFVO0FBQ3ZCLFFBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDdkIsSUFBRSxDQUFDO0FBQ0gsSUFDRSxnQkFBZ0IsQ0FBQyxNQUFXO0FBQUksUUFDOUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE1BQU0sQ0FBQztBQUNwQyxJQUFFLENBQUM7QUFDSCxJQUNFLGlCQUFpQixDQUFDLE1BQWtCO0FBQ3RDLFFBQUksSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQztBQUNyQyxJQUFFLENBQUM7QUFDSCxJQUNFLGdCQUFnQixDQUFDLFVBQW1CO0FBQ3RDLFFBQUksSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLFVBQVUsQ0FBQztBQUNqQyxJQUFFLENBQUM7QUFDSCxJQUFFLDJCQUEyQjtBQUM3QixJQUNFLFFBQVE7QUFDVixRQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDM0MsUUFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUM5QixRQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ3RFLFFBQUksMENBQTBDO0FBQzlDLFFBQUksK0RBQStEO0FBQ25FLFFBQUksSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsZUFBZSxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDbEcsUUFDSSxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDdEIsWUFBTSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUM3RSxZQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUN6RCxZQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyx1QkFBdUIsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUM5RCxZQUNNLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtBQUNoQyxnQkFBUSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDaEYsZ0JBQ1EsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7QUFDbkMsb0JBQVUsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7QUFDbkMsb0JBQVUsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxDQUFDO0FBQy9GLGlCQUFTO0FBQ1QsYUFBTztBQUNQLFNBQUs7QUFDTCxRQUNJLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLElBQUUsQ0FBQztBQUNILElBQ0UsU0FBUztBQUNYLFFBQUksTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzVELFFBQ0ksSUFBSSxZQUFZLEVBQUU7QUFDdEIsWUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQyxZQUFNLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUM5QixZQUNNLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO0FBQzlCLGdCQUFRLFNBQVMsRUFBRSxJQUFJO0FBQ3ZCLGFBQU8sQ0FBQyxDQUFDO0FBQ1QsU0FBSztBQUNMLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFFSDtBQUFPO0FBQ0U7QUFDRTtBQUVKLE9BREg7QUFDTCxJQUFFLE9BQU8sQ0FBQyxJQUFTO0FBQUksUUFDbkIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQ3RCLFFBQ0ksc0NBQXNDO0FBQzFDLFFBQUksOERBQThEO0FBQ2xFLFFBQUksMEVBQTBFO0FBQzlFLFFBQUksbURBQW1EO0FBQ3ZELFFBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDN0IsUUFDSSxrQ0FBa0M7QUFDdEMsUUFBSSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRTtBQUNqQyxZQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztBQUM1QyxTQUFLO0FBQ0wsUUFDSSxPQUFPLElBQUksT0FBTyxDQUFDLFVBQVUsT0FBTyxFQUFFLE1BQU07QUFDaEQsWUFBTSxpREFBaUQ7QUFDdkQsWUFBTSxpREFBaUQ7QUFDdkQsWUFBTSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO0FBQ2pGLGdCQUFRLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztBQUM5QyxnQkFBUSxPQUFPLEVBQUUsQ0FBQztBQUNsQixZQUFNLENBQUMsRUFBRSxHQUFHLEVBQUU7QUFDZCxnQkFBUSxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDOUMsZ0JBQVEsTUFBTSxFQUFFLENBQUM7QUFDakIsWUFBTSxDQUFDLENBQUMsQ0FBQztBQUNULFFBQUksQ0FBQyxDQUFDLENBQUM7QUFDUCxJQUFFLENBQUM7QUFDSCxJQUNFO0FBQ0Y7QUFDRTtBQUNFO0FBRUQ7QUFBSztBQUNFO0FBQ0U7QUFFRixLQURQO0FBQ0gsSUFBRSxVQUFVLENBQUMsSUFBUztBQUFJLFFBQ3RCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztBQUN0QixRQUFJLElBQUksZUFBZSxHQUFHLEtBQUssQ0FBQztBQUNoQyxRQUNJLDJDQUEyQztBQUMvQyxRQUFJLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtBQUM3QixZQUFNLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDL0QsZ0JBQVEsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM1RSxZQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ1QsU0FBSztBQUNMLFFBQ0ksa0NBQWtDO0FBQ3RDLFFBQUksSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO0FBQ3BCLFlBQU0sSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQzNCLGdCQUFRLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFO0FBQ2pELG9CQUFVLE9BQU8sS0FBSyxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ3RDLGdCQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ1gsZ0JBQ1EsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFO0FBQ2pELG9CQUFVLElBQUksQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO0FBQzlCLG9CQUFVLGVBQWUsR0FBRyxJQUFJLENBQUM7QUFDakMsaUJBQVM7QUFDVCxhQUFPO0FBQUMsaUJBQUs7QUFDYixnQkFBUSxJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsS0FBSyxFQUFFO0FBQ2pDLG9CQUFVLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO0FBQzVCLG9CQUFVLGVBQWUsR0FBRyxJQUFJLENBQUM7QUFDakMsaUJBQVM7QUFDVCxhQUFPO0FBQ1AsU0FBSztBQUNMLFFBQ0ksSUFBSSxlQUFlLEVBQUU7QUFDekIsWUFBTSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztBQUM5QixTQUFLO0FBQ0wsUUFDSSxpQ0FBaUM7QUFDckMsUUFBSSxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUM1QyxZQUFNLE9BQU8sS0FBSyxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ2xDLFFBQUksQ0FBQyxDQUFDLENBQUM7QUFDUCxRQUNJLHFDQUFxQztBQUN6QyxRQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2pDLFFBQ0ksZ0JBQWdCO0FBQ3BCLFFBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMxQixRQUNJLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO0FBQzVCLFlBQU0sU0FBUyxFQUFFLElBQUk7QUFDckIsU0FBSyxDQUFDLENBQUM7QUFDUCxRQUNJLGtDQUFrQztBQUN0QyxRQUFJLElBQUksSUFBSSxDQUFDLHFCQUFxQixFQUFFO0FBQ3BDLFlBQU0sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxDQUFDO0FBQy9DLFNBQUs7QUFDTCxRQUNJLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBVSxPQUFPLEVBQUUsTUFBTTtBQUNoRCxZQUFNLGlEQUFpRDtBQUN2RCxZQUFNLGlEQUFpRDtBQUN2RCxZQUFNLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7QUFDcEYsZ0JBQVEsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxDQUFDO0FBQ2pELGdCQUFRLE9BQU8sRUFBRSxDQUFDO0FBQ2xCLFlBQU0sQ0FBQyxFQUFFLEdBQUcsRUFBRTtBQUNkLGdCQUFRLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQztBQUNqRCxnQkFBUSxNQUFNLEVBQUUsQ0FBQztBQUNqQixZQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ1QsUUFBSSxDQUFDLENBQUMsQ0FBQztBQUNQLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUNFO0FBRUosT0FEQztBQUNMLElBQUUsUUFBUTtBQUFLLFFBQ1gsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQ3pCLFlBQU0sT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUM7QUFDM0MsU0FBSztBQUFDLGFBQUs7QUFDWCxZQUFNLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RixTQUFLO0FBQ0wsSUFBRSxDQUFDO0FBQ0gsSUFDRTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBQ0U7QUFFSixPQURDO0FBQ0wsSUFBRSxJQUFJO0FBQUssUUFDUCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7QUFDdEIsUUFDSSxPQUFPLElBQUksT0FBTyxDQUFDLFVBQVUsT0FBTyxFQUFFLE1BQU07QUFDaEQsWUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO0FBQzlDLGdCQUFRLE1BQU0sQ0FBQyxnREFBZ0QsQ0FBQyxDQUFDO0FBQ2pFLGdCQUFRLE9BQU87QUFDZixhQUFPO0FBQ1AsWUFDTSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7QUFDMUIsWUFBTSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztBQUM1QixZQUNNLE1BQU0sWUFBWSxHQUFpQjtBQUN6QyxnQkFBUSxTQUFTLEVBQUUsNkJBQTZCO0FBQ2hELGdCQUFRLGNBQWMsRUFBRSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUU7QUFDakQsZ0JBQVEsZUFBZSxFQUFFLElBQUksQ0FBQyxvQkFBb0I7QUFDbEQsYUFBTyxDQUFDO0FBQ1IsWUFDTSxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUU7QUFDOUIsZ0JBQVEsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO0FBQ25ELGFBQU87QUFDUCxZQUNNLElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFO0FBQ3BDLGdCQUFRLFlBQVksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO0FBQy9ELGFBQU87QUFDUCxZQUNNLElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFO0FBQ3BDLGdCQUFRLFlBQVksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO0FBQy9ELGFBQU87QUFDUCxZQUNNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO0FBQzlELGdCQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0FBQzVCLGdCQUFRLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO0FBQ2xDLG9CQUFVLDZFQUE2RTtBQUN2RixvQkFBVSx3QkFBd0I7QUFDbEMsb0JBQVUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pDLG9CQUFVLE9BQU8sRUFBRSxDQUFDO0FBQ3BCLGdCQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ1gsZ0JBQ1EsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFDeEMsb0JBQVUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFDLGdCQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ1gsZ0JBQ1EsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUMxQyxvQkFBVSxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztBQUNqQyxvQkFBVSxJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztBQUNwQyxvQkFDVSxnREFBZ0Q7QUFDMUQsb0JBQVUsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLFVBQVUsRUFBRTtBQUN6Qyx3QkFBWSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUM5Qiw0QkFBYyxTQUFTLEVBQUUsSUFBSTtBQUM3Qix5QkFBYSxDQUFDLENBQUM7QUFDZixxQkFBVztBQUNYLGdCQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ1gsWUFBTSxDQUFDLENBQUMsQ0FBQztBQUNULFFBQUksQ0FBQyxDQUFDLENBQUM7QUFDUCxJQUFFLENBQUM7QUFDSCxJQUNFO0FBQ0Y7QUFDRTtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREM7QUFDTCxJQUFFLEtBQUs7QUFBSyxRQUNSLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztBQUN0QixRQUNJLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBVSxPQUFPLEVBQUUsTUFBTTtBQUNoRCxZQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtBQUMvQyxnQkFBUSxNQUFNLENBQUMsZ0RBQWdELENBQUMsQ0FBQztBQUNqRSxnQkFBUSxPQUFPO0FBQ2YsYUFBTztBQUNQLFlBQ00sSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7QUFDaEMsWUFBTSxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztBQUM3QixZQUFNLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO0FBQzdCLFlBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO0FBQ3RDLGdCQUFRLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN4QyxnQkFBUSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztBQUNuQyxnQkFBUSxPQUFPLEVBQUUsQ0FBQztBQUNsQixZQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ1QsUUFBSSxDQUFDLENBQUMsQ0FBQztBQUNQLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREc7QUFDTCxJQUFFLEtBQUs7QUFDUCxRQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0MsUUFBSSxJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztBQUM5QixRQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkMsSUFBRSxDQUFDO0FBQ0gsSUFDRTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBRUosT0FERztBQUNMLElBQUUsT0FBTztBQUNULFFBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQ3pCLFlBQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDMUMsU0FBSztBQUFDLGFBQUssSUFBSSxJQUFJLENBQUMsZ0JBQWdCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtBQUM3RCxZQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUNyRCxTQUFLO0FBQ0wsSUFBRSxDQUFDO0FBQ0gsSUFDRTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREQ7QUFDTCxJQUFFLFdBQVcsQ0FBQyxRQUFpQixFQUFFLEtBQWE7QUFDOUMsUUFBSSxJQUFJLFFBQVEsRUFBRTtBQUNsQixZQUFNLE1BQU0sUUFBUSxHQUFHLEtBQUssSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQzdDLFlBQU0sSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEVBQUU7QUFDbEUsZ0JBQVEsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM1QyxZQUFNLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUNiLFlBQ00sa0RBQWtEO0FBQ3hELFlBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxRQUFRLEVBQUU7QUFDekMsZ0JBQVEsYUFBYSxHQUFHLEVBQUUsQ0FBQztBQUMzQixhQUFPO0FBQ1AsWUFDTSx5QkFBeUI7QUFDL0IsWUFBTSxJQUFJLFFBQVEsRUFBRTtBQUNwQixnQkFBUSxhQUFhLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRTtBQUM1RCxvQkFBVSxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDbkMsd0JBQVksT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakYsb0JBQVUsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDO0FBQzNCLGdCQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ1gsZ0JBQ1EsdUNBQXVDO0FBQy9DLGdCQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQzlCLG9CQUFVLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLGlCQUFTO0FBQ1QsYUFBTztBQUNQLFlBQ00sYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNuQyxnQkFBUSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEMsWUFBTSxDQUFDLENBQUMsQ0FBQztBQUNULFNBQUs7QUFBQyxhQUFLO0FBQ1gsWUFBTSxJQUFJLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUMvQixTQUFLO0FBQ0wsUUFDSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ2pELElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUNFO0FBRUosT0FEQztBQUNMLElBQUUsV0FBVztBQUFLLFFBQ2QsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQ3RCLFFBQ0ksT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFVLE9BQU8sRUFBRSxNQUFNO0FBQ2hELFlBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7QUFDM0IsZ0JBQVEsTUFBTSxDQUFDLDZDQUE2QyxDQUFDLENBQUM7QUFDOUQsZ0JBQVEsT0FBTztBQUNmLGFBQU87QUFDUCxZQUNNLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFDNUQsZ0JBQVEsT0FBTyxFQUFFLENBQUM7QUFDbEIsWUFBTSxDQUFDLENBQUMsQ0FBQztBQUNULFFBQUksQ0FBQyxDQUFDLENBQUM7QUFDUCxJQUFFLENBQUM7QUFDSCxJQUNFO0FBQ0Y7QUFDRTtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREM7QUFDTCxJQUFFLGNBQWM7QUFBSyxRQUNqQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7QUFDdEIsUUFDSSxPQUFPLElBQUksT0FBTyxDQUFDLFVBQVUsT0FBTyxFQUFFLE1BQU07QUFDaEQsWUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtBQUMzQixnQkFBUSxNQUFNLENBQUMsNkNBQTZDLENBQUMsQ0FBQztBQUM5RCxnQkFBUSxPQUFPO0FBQ2YsYUFBTztBQUNQLFlBQ00sSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtBQUMvRCxnQkFBUSxPQUFPLEVBQUUsQ0FBQztBQUNsQixZQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ1QsUUFBSSxDQUFDLENBQUMsQ0FBQztBQUNQLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFFSDtBQUFPO0FBRUosT0FEQztBQUNMLElBQUUsV0FBVztBQUNiLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7QUFDMUIsWUFBTSxPQUFPO0FBQ2IsU0FBSztBQUNMLFFBQ0ksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0FBQ3ZCLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFFSDtBQUFPO0FBRUosT0FEQztBQUNMLElBQUUsU0FBUztBQUNYLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7QUFDMUIsWUFBTSxPQUFPO0FBQ2IsU0FBSztBQUNMLFFBQ0ksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0FBQ3ZCLFFBQ0ksc0RBQXNEO0FBQzFELFFBQUksb0VBQW9FO0FBQ3hFLFFBQUksZ0VBQWdFO0FBQ3BFLFFBQUksMEJBQTBCO0FBQzlCLFFBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0IsUUFBSSxJQUFJLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDNUQsSUFBRSxDQUFDO0FBQ0gsSUFDRTtBQUNGO0FBQ0U7QUFDRTtBQUNFO0FBRUosT0FERztBQUNMLElBQUUsb0JBQW9CO0FBQ3RCLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRTtBQUNsQyxZQUFNLE9BQU87QUFDYixTQUFLO0FBQ0wsUUFDSSxJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO0FBQzFELElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREc7QUFDTCxJQUFFLHFCQUFxQjtBQUN2QixRQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUU7QUFDbEMsWUFBTSxPQUFPO0FBQ2IsU0FBSztBQUNMLFFBQ0ksSUFBSSxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztBQUN6RCxJQUFFLENBQUM7QUFDSCxJQUNFO0FBQ0Y7QUFDRTtBQUNFO0FBQ0U7QUFFSixPQURHO0FBQ0wsSUFBRSxpQkFBaUI7QUFDbkIsUUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFO0FBQ2xDLFlBQU0sT0FBTztBQUNiLFNBQUs7QUFDTCxRQUNJLElBQUksQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQ3BELFFBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0IsSUFBRSxDQUFDO0FBQ0gsSUFDRTtBQUNGO0FBQ0U7QUFDRTtBQUVIO0FBQU87QUFDRTtBQUVKLE9BREQ7QUFDTCxJQUFFLE1BQU0sQ0FBQyxJQUFZO0FBQ3JCLFFBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtBQUNoRSxZQUFNLE9BQU87QUFDYixTQUFLO0FBQ0wsUUFDSSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztBQUM1QixRQUFJLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0FBQzdCLFFBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3hCLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREc7QUFDTCxJQUFFLFdBQVc7QUFDYixRQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQzFCLFlBQU0sT0FBTztBQUNiLFNBQUs7QUFDTCxRQUNJLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO0FBQzdCLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREc7QUFDTCxJQUFFLFdBQVc7QUFDYixRQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQzFCLFlBQU0sT0FBTztBQUNiLFNBQUs7QUFDTCxRQUNJLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO0FBQzlCLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREc7QUFDTCxJQUFFLG1CQUFtQjtBQUNyQixRQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN0QyxRQUNJLCtDQUErQztBQUNuRCxRQUFJLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO0FBQ3BDLElBQUUsQ0FBQztBQUNILElBQ0U7QUFDRjtBQUNFO0FBQ0U7QUFDRTtBQUVKLE9BREc7QUFDTCxJQUFFLG1CQUFtQjtBQUNyQixRQUFJLGtGQUFrRjtBQUN0RixRQUFJLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO0FBQzNCLFFBQUksSUFBSSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3ZDLElBQUUsQ0FBQztBQUNIO29EQTF5REMsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSxrQkFBa0Isa0JBQzVCOzs7Ozs7Ozs7Ozs7OztpRUFBZ0Qsa0JBRWhELGFBQWE7Q0FBRSxpQkFBaUIsQ0FBQyxJQUFJLGtCQUNyQyxTQUFTLEVBQUUsQ0FBQywwQkFDVixPQUFPLEVBQUU7TUFBaUIsMEJBQzFCLFdBQVcsRUFBRSxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsd0JBQXdCLENBQUM7a0JBQ3ZEO0dBQUssRUFBRSxJQUFJO2VBQ1osQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpRUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztvaklBQ0k7QUFBQztBQUFtQjtBQUFrRCxZQS9CekQsZUFBZTtBQUFJLFlBQUYsUUFBUTtBQUFJLFlBQXRDLE9BQU8sdUJBZ3lCWCxRQUFRO0FBQU8sWUFseUJpRyxlQUFlO0FBQUksWUFBN0YsVUFBVTtBQUFJLFlBQXVHLFNBQVM7QUFBRztBQUFHO0FBQTRDLHdCQWtDeE4sV0FBVyxTQUFDLHdCQUF3QjtBQUNsQyxxQkFDRixXQUFXLFNBQUMsNEJBQTRCO0FBQ3RDLG9CQUNGLFdBQVcsU0FBQywyQkFBMkI7QUFDckMsa0NBQ0YsV0FBVyxTQUFDLG9DQUFvQztBQUM5QyxnQ0FHRixXQUFXLFNBQUMsa0NBQWtDO0FBQzVDLHNDQUdGLFdBQVcsU0FBQyx3Q0FBd0M7QUFDbEQsbUNBR0YsV0FBVyxTQUFDLGtDQUFrQztBQUM1QywwQ0FHRixXQUFXLFNBQUMsc0NBQXNDO0FBQ2hELHdDQUdGLFdBQVcsU0FBQyxvQ0FBb0M7QUFDOUMsMENBR0YsV0FBVyxTQUFDLHNDQUFzQztBQUNoRCwyQ0FHRixXQUFXLFNBQUMsdUNBQXVDO0FBQ2pELG9CQWlJRixLQUFLO0FBQ04sMEJBQ0MsTUFBTTtBQUNQLHdCQVNDLFdBQVcsU0FBQyxtQ0FBbUMsY0FDL0MsS0FBSyxTQUFDLFdBQVc7QUFDZixrQ0FlRixLQUFLLFNBQUMscUJBQXFCO0FBQ3pCLDRCQWNGLEtBQUs7QUFDTixrQ0FTQyxLQUFLO0FBQ04sa0NBU0MsS0FBSztBQUNOLHFDQXFCQyxLQUFLO0FBQ04sK0JBV0MsS0FBSyxTQUFDLGtCQUFrQjtBQUN0Qiw2QkFnQkYsS0FBSztBQUNOLDRCQVVDLEtBQUs7QUFDTiw4QkFXQyxLQUFLO0FBQ04sNkJBVUMsS0FBSztBQUNOLHdCQVNDLEtBQUs7QUFDTixnQ0FTQyxLQUFLLFNBQUMsbUJBQW1CO0FBQ3ZCLHVCQWNGLFdBQVcsU0FBQyxrQ0FBa0MsY0FDOUMsS0FBSyxTQUFDLFVBQVU7QUFDZCxnQ0FnQkYsS0FBSztBQUNOLCtCQVVDLEtBQUs7QUFDTiw0Q0FTQyxLQUFLO0FBQ04sZ0NBU0MsS0FBSztBQUNOLDBCQVNDLEtBQUs7QUFDTix5QkFTQyxLQUFLLFNBQUMsWUFBWTtBQUNoQiw2QkFlRixLQUFLO0FBQ04sOEJBU0MsS0FBSztBQUNOLDRCQVNDLEtBQUs7QUFDTixnQ0FTQyxLQUFLO0FBQ04sOEJBVUMsS0FBSztBQUNOLG1DQVNDLEtBQUs7QUFDTiwwQkFTQyxLQUFLO0FBQ04seUJBU0MsS0FBSztBQUNOLDhCQVNDLEtBQUs7QUFDTiwyQkFTQyxLQUFLO0FBQ04sdUJBUUMsTUFBTTtBQUNQLHVCQVNDLE1BQU07QUFDUCwyQkFRQyxNQUFNO0FBQ1AsOEJBUUMsTUFBTTtBQUNQLCtCQVNDLE1BQU07QUFDUCxxQkFRQyxNQUFNO0FBQ1Asc0JBUUMsTUFBTTtBQUNQLHVCQVFDLE1BQU07QUFDUCxzQkFRQyxNQUFNO0FBQ1AsNkJBc0JDLEtBQUs7QUFDTiw0QkFTQyxLQUFLO0FBQ04sbUNBVUMsS0FBSztBQUNOLDBCQVNDLEtBQUs7QUFDTiw0QkFTQyxLQUFLO0FBQ04seUJBU0MsS0FBSyxTQUFDLFlBQVk7QUFDaEIseUJBZ0JGLE1BQU07QUFDUCwyQkFTQyxNQUFNO0FBQ1Asd0JBVUMsTUFBTTtBQUNQLDRCQUVDLFlBQVksU0FBQyxxQ0FBcUMsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7QUFDdkUsMkJBQ0YsWUFBWSxTQUFDLG9DQUFvQyxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtBQUN0RSw4QkFDRixZQUFZLFNBQUMsdUNBQXVDLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO0FBQ3pFLDRCQUNGLFlBQVksU0FBQyxxQ0FBcUMsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7QUFDdkUsa0NBQ0YsWUFBWSxTQUFDLDJDQUEyQyxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtBQUM3RSw4QkFDRixZQUFZLFNBQUMsdUNBQXVDLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO0FBQ3pFLDRCQUNGLFlBQVksU0FBQyxxQ0FBcUMsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7QUFDdkUsK0JBQ0YsWUFBWSxTQUFDLHdDQUF3QyxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtBQUMxRSxrQ0FDRixZQUFZLFNBQUMsMkNBQTJDLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO0FBQzdFLGlDQUNGLFlBQVksU0FBQywwQ0FBMEMsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7QUFDNUUsOEJBQ0YsWUFBWSxTQUFDLHVDQUF1QyxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtBQUN6RSw2QkFDRixZQUFZLFNBQUMsc0NBQXNDLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO0FBQ3hFLDZCQUVGLFlBQVksU0FBQyxzQ0FBc0MsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7QUFDeEUsK0JBQ0YsWUFBWSxTQUFDLHdDQUF3QyxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtBQUMxRSwyQkFDRixZQUFZLFNBQUMsb0NBQW9DLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO0FBQ3RFLG9DQVFGLEtBQUs7QUFDUDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBQUU7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbIi8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTptYXgtbGluZS1sZW5ndGhcbmltcG9ydCB7IENvbXBvbmVudCwgQ29udGVudENoaWxkLCBEb0NoZWNrLCBFbGVtZW50UmVmLCBFdmVudEVtaXR0ZXIsIGZvcndhcmRSZWYsIEhvc3RCaW5kaW5nLCBJbnB1dCwgSXRlcmFibGVEaWZmZXIsIEl0ZXJhYmxlRGlmZmVycywgT25Jbml0LCBPcHRpb25hbCwgT3V0cHV0LCBSZW5kZXJlcjIsIFRlbXBsYXRlUmVmLCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5HX1ZBTFVFX0FDQ0VTU09SIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgSW9uSXRlbSwgTW9kYWxDb250cm9sbGVyLCBQbGF0Zm9ybSB9IGZyb20gJ0Bpb25pYy9hbmd1bGFyJztcbmltcG9ydCB7IEFuaW1hdGlvbkJ1aWxkZXIsIE1vZGFsT3B0aW9ucyB9IGZyb20gJ0Bpb25pYy9jb3JlJztcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlQWRkSXRlbVRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWFkZC1pdGVtLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVDbG9zZUJ1dHRvblRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWNsb3NlLWJ1dHRvbi10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlRm9vdGVyVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtZm9vdGVyLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVHcm91cEVuZFRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLWdyb3VwLWVuZC10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlR3JvdXBUZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1ncm91cC10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlSGVhZGVyVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaGVhZGVyLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVJdGVtRW5kVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaXRlbS1lbmQtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZUl0ZW1JY29uVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaXRlbS1pY29uLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVJdGVtVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtaXRlbS10ZW1wbGF0ZS5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW9uaWNTZWxlY3RhYmxlTWVzc2FnZVRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLW1lc3NhZ2UtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZU1vZGFsQ29tcG9uZW50IH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLW1vZGFsLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVQbGFjZWhvbGRlclRlbXBsYXRlRGlyZWN0aXZlIH0gZnJvbSAnLi9pb25pYy1zZWxlY3RhYmxlLXBsYWNlaG9sZGVyLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBJb25pY1NlbGVjdGFibGVTZWFyY2hGYWlsVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtc2VhcmNoLWZhaWwtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZVRpdGxlVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtdGl0bGUtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZVZhbHVlVGVtcGxhdGVEaXJlY3RpdmUgfSBmcm9tICcuL2lvbmljLXNlbGVjdGFibGUtdmFsdWUtdGVtcGxhdGUuZGlyZWN0aXZlJztcbmltcG9ydCB7IElvbmljU2VsZWN0YWJsZUljb25UZW1wbGF0ZURpcmVjdGl2ZSB9IGZyb20gJy4vaW9uaWMtc2VsZWN0YWJsZS1pY29uLXRlbXBsYXRlLmRpcmVjdGl2ZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2lvbmljLXNlbGVjdGFibGUnLFxuICB0ZW1wbGF0ZVVybDogJy4vaW9uaWMtc2VsZWN0YWJsZS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL2lvbmljLXNlbGVjdGFibGUuY29tcG9uZW50LnNjc3MnXSxcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcbiAgcHJvdmlkZXJzOiBbe1xuICAgIHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuICAgIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IElvbmljU2VsZWN0YWJsZUNvbXBvbmVudCksXG4gICAgbXVsdGk6IHRydWVcbiAgfV1cbn0pXG5leHBvcnQgY2xhc3MgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50IGltcGxlbWVudHMgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE9uSW5pdCwgRG9DaGVjayB7XG4gIEBIb3N0QmluZGluZygnY2xhc3MuaW9uaWMtc2VsZWN0YWJsZScpXG4gIF9jc3NDbGFzcyA9IHRydWU7XG4gIEBIb3N0QmluZGluZygnY2xhc3MuaW9uaWMtc2VsZWN0YWJsZS1pb3MnKVxuICBfaXNJb3M6IGJvb2xlYW47XG4gIEBIb3N0QmluZGluZygnY2xhc3MuaW9uaWMtc2VsZWN0YWJsZS1tZCcpXG4gIF9pc01EOiBib29sZWFuO1xuICBASG9zdEJpbmRpbmcoJ2NsYXNzLmlvbmljLXNlbGVjdGFibGUtaXMtbXVsdGlwbGUnKVxuICBnZXQgX2lzTXVsdGlwbGVDc3NDbGFzcygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5pc011bHRpcGxlO1xuICB9XG4gIEBIb3N0QmluZGluZygnY2xhc3MuaW9uaWMtc2VsZWN0YWJsZS1oYXMtdmFsdWUnKVxuICBnZXQgX2hhc1ZhbHVlQ3NzQ2xhc3MoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuaGFzVmFsdWUoKTtcbiAgfVxuICBASG9zdEJpbmRpbmcoJ2NsYXNzLmlvbmljLXNlbGVjdGFibGUtaGFzLXBsYWNlaG9sZGVyJylcbiAgZ2V0IF9oYXNQbGFjZWhvbGRlckNzc0NsYXNzKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLl9oYXNQbGFjZWhvbGRlcjtcbiAgfVxuICBASG9zdEJpbmRpbmcoJ2NsYXNzLmlvbmljLXNlbGVjdGFibGUtaGFzLWxhYmVsJylcbiAgZ2V0IF9oYXNJb25MYWJlbENzc0NsYXNzKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLl9oYXNJb25MYWJlbDtcbiAgfVxuICBASG9zdEJpbmRpbmcoJ2NsYXNzLmlvbmljLXNlbGVjdGFibGUtbGFiZWwtZGVmYXVsdCcpXG4gIGdldCBfaGFzRGVmYXVsdElvbkxhYmVsQ3NzQ2xhc3MoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuX2lvbkxhYmVsUG9zaXRpb24gPT09ICdkZWZhdWx0JztcbiAgfVxuICBASG9zdEJpbmRpbmcoJ2NsYXNzLmlvbmljLXNlbGVjdGFibGUtbGFiZWwtZml4ZWQnKVxuICBnZXQgX2hhc0ZpeGVkSW9uTGFiZWxDc3NDbGFzcygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5faW9uTGFiZWxQb3NpdGlvbiA9PT0gJ2ZpeGVkJztcbiAgfVxuICBASG9zdEJpbmRpbmcoJ2NsYXNzLmlvbmljLXNlbGVjdGFibGUtbGFiZWwtc3RhY2tlZCcpXG4gIGdldCBfaGFzU3RhY2tlZElvbkxhYmVsQ3NzQ2xhc3MoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuX2lvbkxhYmVsUG9zaXRpb24gPT09ICdzdGFja2VkJztcbiAgfVxuICBASG9zdEJpbmRpbmcoJ2NsYXNzLmlvbmljLXNlbGVjdGFibGUtbGFiZWwtZmxvYXRpbmcnKVxuICBnZXQgX2hhc0Zsb2F0aW5nSW9uTGFiZWxDc3NDbGFzcygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5faW9uTGFiZWxQb3NpdGlvbiA9PT0gJ2Zsb2F0aW5nJztcbiAgfVxuICBwcml2YXRlIF9pc09uU2VhcmNoRW5hYmxlZCA9IHRydWU7XG4gIHByaXZhdGUgX2lzRW5hYmxlZCA9IHRydWU7XG4gIHByaXZhdGUgX3Nob3VsZEJhY2tkcm9wQ2xvc2UgPSB0cnVlO1xuICBwcml2YXRlIF9pc09wZW5lZCA9IGZhbHNlO1xuICBwcml2YXRlIF92YWx1ZTogYW55ID0gbnVsbDtcbiAgcHJpdmF0ZSBfbW9kYWw6IEhUTUxJb25Nb2RhbEVsZW1lbnQ7XG4gIHByaXZhdGUgX2l0ZW1zRGlmZmVyOiBJdGVyYWJsZURpZmZlcjxhbnk+O1xuICBwcml2YXRlIF9oYXNPYmplY3RzOiBib29sZWFuO1xuICBwcml2YXRlIF9jYW5DbGVhciA9IGZhbHNlO1xuICBwcml2YXRlIF9oYXNDb25maXJtQnV0dG9uID0gZmFsc2U7XG4gIHByaXZhdGUgX2lzTXVsdGlwbGUgPSBmYWxzZTtcbiAgcHJpdmF0ZSBfY2FuQWRkSXRlbSA9IGZhbHNlO1xuICBwcml2YXRlIF9hZGRJdGVtT2JzZXJ2YWJsZTogU3Vic2NyaXB0aW9uO1xuICBwcml2YXRlIF9kZWxldGVJdGVtT2JzZXJ2YWJsZTogU3Vic2NyaXB0aW9uO1xuICBwcml2YXRlIG9uSXRlbXNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICBwcml2YXRlIF9pb25JdGVtRWxlbWVudDogYW55O1xuICBwcml2YXRlIF9pb25MYWJlbEVsZW1lbnQ6IGFueTtcbiAgcHJpdmF0ZSBfaGFzSW9uTGFiZWwgPSBmYWxzZTtcbiAgcHJpdmF0ZSBfaW9uTGFiZWxQb3NpdGlvbjogJ2ZpeGVkJyB8ICdzdGFja2VkJyB8ICdmbG9hdGluZycgfCAnZGVmYXVsdCcgfCBudWxsID0gbnVsbDtcbiAgcHJpdmF0ZSBfbGFiZWw6IHN0cmluZyA9IG51bGw7XG4gIHByaXZhdGUgZ2V0IF9oYXNJbmZpbml0ZVNjcm9sbCgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5pc0VuYWJsZWQgJiYgdGhpcy5fbW9kYWxDb21wb25lbnQgJiZcbiAgICAgIHRoaXMuX21vZGFsQ29tcG9uZW50Ll9pbmZpbml0ZVNjcm9sbCA/IHRydWUgOiBmYWxzZTtcbiAgfVxuICBnZXQgX3Nob3VsZFN0b3JlSXRlbVZhbHVlKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnNob3VsZFN0b3JlSXRlbVZhbHVlICYmIHRoaXMuX2hhc09iamVjdHM7XG4gIH1cbiAgX3ZhbHVlSXRlbXM6IGFueVtdID0gW107XG4gIF9zZWFyY2hUZXh0ID0gJyc7XG4gIF9oYXNTZWFyY2hUZXh0ID0gZmFsc2U7XG4gIF9ncm91cHM6IGFueVtdID0gW107XG4gIF9pdGVtc1RvQ29uZmlybTogYW55W10gPSBbXTtcbiAgX3NlbGVjdGVkSXRlbXM6IGFueVtdID0gW107XG4gIF9tb2RhbENvbXBvbmVudDogSW9uaWNTZWxlY3RhYmxlTW9kYWxDb21wb25lbnQ7XG4gIF9maWx0ZXJlZEdyb3VwczogYW55W10gPSBbXTtcbiAgX2hhc0dyb3VwczogYm9vbGVhbjtcbiAgX2lzU2VhcmNoaW5nOiBib29sZWFuO1xuICBfaGFzUGxhY2Vob2xkZXI6IGJvb2xlYW47XG4gIF9pc0FkZEl0ZW1UZW1wbGF0ZVZpc2libGUgPSBmYWxzZTtcbiAgX2lzRm9vdGVyVmlzaWJsZSA9IHRydWU7XG4gIF9pdGVtVG9BZGQ6IGFueSA9IG51bGw7XG4gIF9mb290ZXJCdXR0b25zQ291bnQgPSAwO1xuICBfaGFzRmlsdGVyZWRJdGVtcyA9IGZhbHNlO1xuXG4gIC8qKlxuICAgKiBUZXh0IG9mIFtJb25pYyBMYWJlbF0oaHR0cHM6Ly9pb25pY2ZyYW1ld29yay5jb20vZG9jcy9hcGkvbGFiZWwpLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNsYWJlbCkuXG4gICAqXG4gICAqIEByZWFkb25seVxuICAgKiBAZGVmYXVsdCBudWxsXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIGdldCBsYWJlbCgpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLl9sYWJlbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBUZXh0IHRoYXQgdGhlIHVzZXIgaGFzIHR5cGVkIGluIFNlYXJjaGJhci5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jc2VhcmNodGV4dCkuXG4gICAqXG4gICAqIEByZWFkb25seVxuICAgKiBAZGVmYXVsdCAnJ1xuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBnZXQgc2VhcmNoVGV4dCgpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLl9zZWFyY2hUZXh0O1xuICB9XG4gIHNldCBzZWFyY2hUZXh0KHNlYXJjaFRleHQ6IHN0cmluZykge1xuICAgIHRoaXMuX3NlYXJjaFRleHQgPSBzZWFyY2hUZXh0O1xuICAgIHRoaXMuX3NldEhhc1NlYXJjaFRleHQoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgc2VhcmNoIGlzIHJ1bm5pbmcuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2lzc2VhcmNoaW5nKS5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICogQHJlYWRvbmx5XG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIGdldCBpc1NlYXJjaGluZygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5faXNTZWFyY2hpbmc7XG4gIH1cblxuICAvKipcbiAgICogRGV0ZXJtaW5lcyB3aGV0aGVyIHVzZXIgaGFzIHR5cGVkIGFueXRoaW5nIGluIFNlYXJjaGJhci5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jaGFzc2VhcmNodGV4dCkuXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqIEByZWFkb25seVxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBnZXQgaGFzU2VhcmNoVGV4dCgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5faGFzU2VhcmNoVGV4dDtcbiAgfVxuXG4gIGdldCB2YWx1ZSgpOiBhbnkge1xuICAgIHJldHVybiB0aGlzLl92YWx1ZTtcbiAgfVxuICBzZXQgdmFsdWUodmFsdWU6IGFueSkge1xuICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG5cbiAgICAvLyBTZXQgdmFsdWUgaXRlbXMuXG4gICAgdGhpcy5fdmFsdWVJdGVtcy5zcGxpY2UoMCwgdGhpcy5fdmFsdWVJdGVtcy5sZW5ndGgpO1xuXG4gICAgaWYgKHRoaXMuaXNNdWx0aXBsZSkge1xuICAgICAgaWYgKHZhbHVlICYmIHZhbHVlLmxlbmd0aCkge1xuICAgICAgICBBcnJheS5wcm90b3R5cGUucHVzaC5hcHBseSh0aGlzLl92YWx1ZUl0ZW1zLCB2YWx1ZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICghdGhpcy5faXNOdWxsT3JXaGl0ZVNwYWNlKHZhbHVlKSkge1xuICAgICAgICB0aGlzLl92YWx1ZUl0ZW1zLnB1c2godmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuX3NldElvbkl0ZW1IYXNWYWx1ZSgpO1xuICAgIHRoaXMuX3NldEhhc1BsYWNlaG9sZGVyKCk7XG4gIH1cblxuICAvKipcbiAgICogQSBsaXN0IG9mIGl0ZW1zLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNpdGVtcykuXG4gICAqXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIGl0ZW1zOiBhbnlbXSA9IFtdO1xuICBAT3V0cHV0KClcbiAgaXRlbXNDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgdGhlIGNvbXBvbmVudCBpcyBlbmFibGVkLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNpc2VuYWJsZWQpLlxuICAgKlxuICAgKiBAZGVmYXVsdCB0cnVlXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBIb3N0QmluZGluZygnY2xhc3MuaW9uaWMtc2VsZWN0YWJsZS1pcy1lbmFibGVkJylcbiAgQElucHV0KCdpc0VuYWJsZWQnKVxuICBnZXQgaXNFbmFibGVkKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLl9pc0VuYWJsZWQ7XG4gIH1cbiAgc2V0IGlzRW5hYmxlZChpc0VuYWJsZWQ6IGJvb2xlYW4pIHtcbiAgICB0aGlzLl9pc0VuYWJsZWQgPSAhIWlzRW5hYmxlZDtcbiAgICB0aGlzLmVuYWJsZUlvbkl0ZW0odGhpcy5faXNFbmFibGVkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgTW9kYWwgc2hvdWxkIGJlIGNsb3NlZCB3aGVuIGJhY2tkcm9wIGlzIGNsaWNrZWQuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI3Nob3VsZGJhY2tkcm9wY2xvc2UpLlxuICAgKlxuICAgKiBAZGVmYXVsdCB0cnVlXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgnc2hvdWxkQmFja2Ryb3BDbG9zZScpXG4gIGdldCBzaG91bGRCYWNrZHJvcENsb3NlKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLl9zaG91bGRCYWNrZHJvcENsb3NlO1xuICB9XG4gIHNldCBzaG91bGRCYWNrZHJvcENsb3NlKHNob3VsZEJhY2tkcm9wQ2xvc2U6IGJvb2xlYW4pIHtcbiAgICB0aGlzLl9zaG91bGRCYWNrZHJvcENsb3NlID0gISFzaG91bGRCYWNrZHJvcENsb3NlO1xuICB9XG5cbiAgLyoqXG4gICAqIE1vZGFsIENTUyBjbGFzcy5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jbW9kYWxjc3NjbGFzcykuXG4gICAqXG4gICAqIEBkZWZhdWx0IG51bGxcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQElucHV0KClcbiAgbW9kYWxDc3NDbGFzczogc3RyaW5nID0gbnVsbDtcblxuICAvKipcbiAgICogTW9kYWwgZW50ZXIgYW5pbWF0aW9uLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNtb2RhbGVudGVyYW5pbWF0aW9uKS5cbiAgICpcbiAgICogQGRlZmF1bHQgbnVsbFxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBtb2RhbEVudGVyQW5pbWF0aW9uOiBBbmltYXRpb25CdWlsZGVyID0gbnVsbDtcblxuICAvKipcbiAgICogTW9kYWwgbGVhdmUgYW5pbWF0aW9uLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNtb2RhbGxlYXZlYW5pbWF0aW9uKS5cbiAgICpcbiAgICogQGRlZmF1bHQgbnVsbFxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBtb2RhbExlYXZlQW5pbWF0aW9uOiBBbmltYXRpb25CdWlsZGVyID0gbnVsbDtcblxuICAvKipcbiAgICogRGV0ZXJtaW5lcyB3aGV0aGVyIE1vZGFsIGlzIG9wZW5lZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jaXNvcGVuZWQpLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKiBAcmVhZG9ubHlcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgZ2V0IGlzT3BlbmVkKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLl9pc09wZW5lZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgQ29uZmlybSBidXR0b24gaXMgZW5hYmxlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jaXNjb25maXJtYnV0dG9uZW5hYmxlZCkuXG4gICAqXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQElucHV0KClcbiAgaXNDb25maXJtQnV0dG9uRW5hYmxlZCA9IHRydWU7XG5cbiAgLyoqXG4gKiBEZXRlcm1pbmVzIHdoZXRoZXIgQ29uZmlybSBidXR0b24gaXMgdmlzaWJsZSBmb3Igc2luZ2xlIHNlbGVjdGlvbi5cbiAqIEJ5IGRlZmF1bHQgQ29uZmlybSBidXR0b24gaXMgdmlzaWJsZSBvbmx5IGZvciBtdWx0aXBsZSBzZWxlY3Rpb24uXG4gKiAqKk5vdGUqKjogSXQgaXMgYWx3YXlzIHRydWUgZm9yIG11bHRpcGxlIHNlbGVjdGlvbiBhbmQgY2Fubm90IGJlIGNoYW5nZWQuXG4gKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNoYXNjb25maXJtYnV0dG9uKS5cbiAqXG4gKiBAZGVmYXVsdCB0cnVlXG4gKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gKi9cbiAgQElucHV0KCdoYXNDb25maXJtQnV0dG9uJylcbiAgZ2V0IGhhc0NvbmZpcm1CdXR0b24oKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuX2hhc0NvbmZpcm1CdXR0b247XG4gIH1cbiAgc2V0IGhhc0NvbmZpcm1CdXR0b24oaGFzQ29uZmlybUJ1dHRvbjogYm9vbGVhbikge1xuICAgIHRoaXMuX2hhc0NvbmZpcm1CdXR0b24gPSAhIWhhc0NvbmZpcm1CdXR0b247XG4gICAgdGhpcy5fY291bnRGb290ZXJCdXR0b25zKCk7XG4gIH1cblxuICAvKipcbiAgICogSXRlbSBwcm9wZXJ0eSB0byB1c2UgYXMgYSB1bmlxdWUgaWRlbnRpZmllciwgZS5nLCBgJ2lkJ2AuXG4gICAqICoqTm90ZSoqOiBgaXRlbXNgIHNob3VsZCBiZSBhbiBvYmplY3QgYXJyYXkuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2l0ZW12YWx1ZWZpZWxkKS5cbiAgICpcbiAgICogQGRlZmF1bHQgbnVsbFxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBpdGVtVmFsdWVGaWVsZDogc3RyaW5nID0gbnVsbDtcblxuICAvKipcbiAgICogSXRlbSBwcm9wZXJ0eSB0byBkaXNwbGF5LCBlLmcsIGAnbmFtZSdgLlxuICAgKiAqKk5vdGUqKjogYGl0ZW1zYCBzaG91bGQgYmUgYW4gb2JqZWN0IGFycmF5LlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNpdGVtdGV4dGZpZWxkKS5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQElucHV0KClcbiAgaXRlbVRleHRGaWVsZDogc3RyaW5nID0gbnVsbDtcblxuICAvKipcbiAgICpcbiAgICogR3JvdXAgcHJvcGVydHkgdG8gdXNlIGFzIGEgdW5pcXVlIGlkZW50aWZpZXIgdG8gZ3JvdXAgaXRlbXMsIGUuZy4gYCdjb3VudHJ5LmlkJ2AuXG4gICAqICoqTm90ZSoqOiBgaXRlbXNgIHNob3VsZCBiZSBhbiBvYmplY3QgYXJyYXkuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2dyb3VwdmFsdWVmaWVsZCkuXG4gICAqXG4gICAqIEBkZWZhdWx0IG51bGxcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQElucHV0KClcbiAgZ3JvdXBWYWx1ZUZpZWxkOiBzdHJpbmcgPSBudWxsO1xuXG4gIC8qKlxuKiBHcm91cCBwcm9wZXJ0eSB0byBkaXNwbGF5LCBlLmcuIGAnY291bnRyeS5uYW1lJ2AuXG4qICoqTm90ZSoqOiBgaXRlbXNgIHNob3VsZCBiZSBhbiBvYmplY3QgYXJyYXkuXG4qIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2dyb3VwdGV4dGZpZWxkKS5cbipcbiogQGRlZmF1bHQgbnVsbFxuKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4qL1xuICBASW5wdXQoKVxuICBncm91cFRleHRGaWVsZDogc3RyaW5nID0gbnVsbDtcblxuICAvKipcbiAgICogRGV0ZXJtaW5lcyB3aGV0aGVyIHRvIHNob3cgU2VhcmNoYmFyLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNjYW5zZWFyY2gpLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBjYW5TZWFyY2ggPSBmYWxzZTtcblxuICAvKipcbiAgICogRGV0ZXJtaW5lcyB3aGV0aGVyIGBvblNlYXJjaGAgZXZlbnQgaXMgZW5hYmxlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jaXNvbnNlYXJjaGVuYWJsZWQpLlxuICAgKlxuICAgKiBAZGVmYXVsdCB0cnVlXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgnaXNPblNlYXJjaEVuYWJsZWQnKVxuICBnZXQgaXNPblNlYXJjaEVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuX2lzT25TZWFyY2hFbmFibGVkO1xuICB9XG4gIHNldCBpc09uU2VhcmNoRW5hYmxlZChpc09uU2VhcmNoRW5hYmxlZDogYm9vbGVhbikge1xuICAgIHRoaXMuX2lzT25TZWFyY2hFbmFibGVkID0gISFpc09uU2VhcmNoRW5hYmxlZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgdG8gc2hvdyBDbGVhciBidXR0b24uXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2NhbmNsZWFyKS5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5pb25pYy1zZWxlY3RhYmxlLWNhbi1jbGVhcicpXG4gIEBJbnB1dCgnY2FuQ2xlYXInKVxuICBnZXQgY2FuQ2xlYXIoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuX2NhbkNsZWFyO1xuICB9XG4gIHNldCBjYW5DbGVhcihjYW5DbGVhcjogYm9vbGVhbikge1xuICAgIHRoaXMuX2NhbkNsZWFyID0gISFjYW5DbGVhcjtcbiAgICB0aGlzLl9jb3VudEZvb3RlckJ1dHRvbnMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgSW9uaWMgW0luZmluaXRlU2Nyb2xsXShodHRwczovL2lvbmljZnJhbWV3b3JrLmNvbS9kb2NzL2FwaS9jb21wb25lbnRzL2luZmluaXRlLXNjcm9sbC9JbmZpbml0ZVNjcm9sbC8pIGlzIGVuYWJsZWQuXG4gICAqICoqTm90ZSoqOiBJbmZpbml0ZSBzY3JvbGwgY2Fubm90IGJlIHVzZWQgdG9nZXRoZXIgd2l0aCB2aXJ0dWFsIHNjcm9sbC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jaGFzaW5maW5pdGVzY3JvbGwpLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBoYXNJbmZpbml0ZVNjcm9sbCA9IGZhbHNlO1xuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgSW9uaWMgW1ZpcnR1YWxTY3JvbGxdKGh0dHBzOi8vaW9uaWNmcmFtZXdvcmsuY29tL2RvY3MvYXBpL2NvbXBvbmVudHMvdmlydHVhbC1zY3JvbGwvVmlydHVhbFNjcm9sbC8pIGlzIGVuYWJsZWQuXG4gICAqICoqTm90ZSoqOiBWaXJ0dWFsIHNjcm9sbCBjYW5ub3QgYmUgdXNlZCB0b2dldGhlciB3aXRoIGluZmluaXRlIHNjcm9sbC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jaGFzdmlydHVhbHNjcm9sbCkuXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIGhhc1ZpcnR1YWxTY3JvbGwgPSBmYWxzZTtcblxuICAvKipcbiAgICogU2VlIElvbmljIFZpcnR1YWxTY3JvbGwgW2FwcHJveEl0ZW1IZWlnaHRdKGh0dHBzOi8vaW9uaWNmcmFtZXdvcmsuY29tL2RvY3MvYXBpL2NvbXBvbmVudHMvdmlydHVhbC1zY3JvbGwvVmlydHVhbFNjcm9sbC8pLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiN2aXJ0dWFsc2Nyb2xsYXBwcm94aXRlbWhlaWdodCkuXG4gICAqXG4gICAqIEBkZWZhdWx0ICc0MHB4J1xuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICB2aXJ0dWFsU2Nyb2xsQXBwcm94SXRlbUhlaWdodCA9ICc0MHB4JztcblxuICAvKipcbiAgICogQSBwbGFjZWhvbGRlciBmb3IgU2VhcmNoYmFyLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNzZWFyY2hwbGFjZWhvbGRlcikuXG4gICAqXG4gICAqIEBkZWZhdWx0ICdTZWFyY2gnXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIHNlYXJjaFBsYWNlaG9sZGVyID0gJ1NlYXJjaCc7XG5cbiAgLyoqXG4gICAqIEEgcGxhY2Vob2xkZXIuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI3BsYWNlaG9sZGVyKS5cbiAgICpcbiAgICogQGRlZmF1bHQgbnVsbFxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBwbGFjZWhvbGRlcjogc3RyaW5nID0gbnVsbDtcblxuICAvKipcbiAgICogRGV0ZXJtaW5lcyB3aGV0aGVyIG11bHRpcGxlIGl0ZW1zIGNhbiBiZSBzZWxlY3RlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jaXNtdWx0aXBsZSkuXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgnaXNNdWx0aXBsZScpXG4gIGdldCBpc011bHRpcGxlKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLl9pc011bHRpcGxlO1xuICB9XG4gIHNldCBpc011bHRpcGxlKGlzTXVsdGlwbGU6IGJvb2xlYW4pIHtcbiAgICB0aGlzLl9pc011bHRpcGxlID0gISFpc011bHRpcGxlO1xuICAgIHRoaXMuX2NvdW50Rm9vdGVyQnV0dG9ucygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRleHQgdG8gZGlzcGxheSB3aGVuIG5vIGl0ZW1zIGhhdmUgYmVlbiBmb3VuZCBkdXJpbmcgc2VhcmNoLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNzZWFyY2hmYWlsdGV4dCkuXG4gICAqXG4gICAqIEBkZWZhdWx0ICdObyBpdGVtcyBmb3VuZC4nXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIHNlYXJjaEZhaWxUZXh0ID0gJ05vIGl0ZW1zIGZvdW5kLic7XG5cbiAgLyoqXG4gICAqIENsZWFyIGJ1dHRvbiB0ZXh0LlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNjbGVhcmJ1dHRvbnRleHQpLlxuICAgKlxuICAgKiBAZGVmYXVsdCAnQ2xlYXInXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIGNsZWFyQnV0dG9uVGV4dCA9ICdDbGVhcic7XG5cbiAgLyoqXG4gICAqIEFkZCBidXR0b24gdGV4dC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jYWRkYnV0dG9udGV4dCkuXG4gICAqXG4gICAqIEBkZWZhdWx0ICdBZGQnXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIGFkZEJ1dHRvblRleHQgPSAnQWRkJztcblxuICAvKipcbiAgICogQ29uZmlybSBidXR0b24gdGV4dC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jY29uZmlybWJ1dHRvbnRleHQpLlxuICAgKlxuICAgKiBAZGVmYXVsdCAnT0snXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIGNvbmZpcm1CdXR0b25UZXh0ID0gJ09LJztcblxuICAvKipcbiAgICogQ2xvc2UgYnV0dG9uIHRleHQuXG4gICAqIFRoZSBmaWVsZCBpcyBvbmx5IGFwcGxpY2FibGUgdG8gKippT1MqKiBwbGF0Zm9ybSwgb24gKipBbmRyb2lkKiogb25seSBDcm9zcyBpY29uIGlzIGRpc3BsYXllZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jY2xvc2VidXR0b250ZXh0KS5cbiAgICpcbiAgICogQGRlZmF1bHQgJ0NhbmNlbCdcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQElucHV0KClcbiAgY2xvc2VCdXR0b25UZXh0ID0gJ0NhbmNlbCc7XG5cbiAgLyoqXG4gICAqIERldGVybWluZXMgd2hldGhlciBTZWFyY2hiYXIgc2hvdWxkIHJlY2VpdmUgZm9jdXMgd2hlbiBNb2RhbCBpcyBvcGVuZWQuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI3Nob3VsZGZvY3Vzc2VhcmNoYmFyKS5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQElucHV0KClcbiAgc2hvdWxkRm9jdXNTZWFyY2hiYXIgPSBmYWxzZTtcblxuICAvKipcbiAgICogSGVhZGVyIGNvbG9yLiBbSW9uaWMgY29sb3JzXShodHRwczovL2lvbmljZnJhbWV3b3JrLmNvbS9kb2NzL3RoZW1pbmcvYWR2YW5jZWQjY29sb3JzKSBhcmUgc3VwcG9ydGVkLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNoZWFkZXJjb2xvcikuXG4gICAqXG4gICAqIEBkZWZhdWx0IG51bGxcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQElucHV0KClcbiAgaGVhZGVyQ29sb3I6IHN0cmluZyA9IG51bGw7XG5cbiAgLyoqXG4gICAqIEdyb3VwIGNvbG9yLiBbSW9uaWMgY29sb3JzXShodHRwczovL2lvbmljZnJhbWV3b3JrLmNvbS9kb2NzL3RoZW1pbmcvYWR2YW5jZWQjY29sb3JzKSBhcmUgc3VwcG9ydGVkLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNncm91cGNvbG9yKS5cbiAgICpcbiAgICogQGRlZmF1bHQgbnVsbFxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBncm91cENvbG9yOiBzdHJpbmcgPSBudWxsO1xuXG4gIC8qKlxuICAgKiBDbG9zZSBidXR0b24gc2xvdC4gW0lvbmljIHNsb3RzXShodHRwczovL2lvbmljZnJhbWV3b3JrLmNvbS9kb2NzL2FwaS9idXR0b25zKSBhcmUgc3VwcG9ydGVkLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNjbG9zZWJ1dHRvbnNsb3QpLlxuICAgKlxuICAgKiBAZGVmYXVsdCAnc3RhcnQnXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIGNsb3NlQnV0dG9uU2xvdCA9ICdzdGFydCc7XG5cbiAgLyoqXG4gICAqIEl0ZW0gaWNvbiBzbG90LiBbSW9uaWMgc2xvdHNdKGh0dHBzOi8vaW9uaWNmcmFtZXdvcmsuY29tL2RvY3MvYXBpL2l0ZW0pIGFyZSBzdXBwb3J0ZWQuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2l0ZW1pY29uc2xvdCkuXG4gICAqXG4gICAqIEBkZWZhdWx0ICdzdGFydCdcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQElucHV0KClcbiAgaXRlbUljb25TbG90ID0gJ3N0YXJ0JztcblxuICAvKipcbiAgICogRmlyZXMgd2hlbiBpdGVtL3MgaGFzIGJlZW4gc2VsZWN0ZWQgYW5kIE1vZGFsIGNsb3NlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jb25jaGFuZ2UpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBAT3V0cHV0KClcbiAgb25DaGFuZ2U6IEV2ZW50RW1pdHRlcjx7IGNvbXBvbmVudDogSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50LCB2YWx1ZTogYW55IH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gIC8qKlxuICAgKiBGaXJlcyB3aGVuIHRoZSB1c2VyIGlzIHR5cGluZyBpbiBTZWFyY2hiYXIuXG4gICAqICoqTm90ZSoqOiBgY2FuU2VhcmNoYCBhbmQgYGlzT25TZWFyY2hFbmFibGVkYCBoYXMgdG8gYmUgZW5hYmxlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jb25zZWFyY2gpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBAT3V0cHV0KClcbiAgb25TZWFyY2g6IEV2ZW50RW1pdHRlcjx7IGNvbXBvbmVudDogSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50LCB0ZXh0OiBzdHJpbmcgfT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgLyoqXG4gICAqIEZpcmVzIHdoZW4gbm8gaXRlbXMgaGF2ZSBiZWVuIGZvdW5kLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNvbnNlYXJjaGZhaWwpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBAT3V0cHV0KClcbiAgb25TZWFyY2hGYWlsOiBFdmVudEVtaXR0ZXI8eyBjb21wb25lbnQ6IElvbmljU2VsZWN0YWJsZUNvbXBvbmVudCwgdGV4dDogc3RyaW5nIH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gIC8qKlxuICAgKiBGaXJlcyB3aGVuIHNvbWUgaXRlbXMgaGF2ZSBiZWVuIGZvdW5kLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNvbnNlYXJjaHN1Y2Nlc3MpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBAT3V0cHV0KClcbiAgb25TZWFyY2hTdWNjZXNzOiBFdmVudEVtaXR0ZXI8eyBjb21wb25lbnQ6IElvbmljU2VsZWN0YWJsZUNvbXBvbmVudCwgdGV4dDogc3RyaW5nIH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gIC8qKlxuICAgKiBGaXJlcyB3aGVuIHRoZSB1c2VyIGhhcyBzY3JvbGxlZCB0byB0aGUgZW5kIG9mIHRoZSBsaXN0LlxuICAgKiAqKk5vdGUqKjogYGhhc0luZmluaXRlU2Nyb2xsYCBoYXMgdG8gYmUgZW5hYmxlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jb25pbmZpbml0ZXNjcm9sbCkuXG4gICAqXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBPdXRwdXQoKVxuICBvbkluZmluaXRlU2Nyb2xsOiBFdmVudEVtaXR0ZXI8eyBjb21wb25lbnQ6IElvbmljU2VsZWN0YWJsZUNvbXBvbmVudCwgdGV4dDogc3RyaW5nIH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gIC8qKlxuICAgKiBGaXJlcyB3aGVuIE1vZGFsIGhhcyBiZWVuIG9wZW5lZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jb25vcGVuKS5cbiAgICpcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQE91dHB1dCgpXG4gIG9uT3BlbjogRXZlbnRFbWl0dGVyPHsgY29tcG9uZW50OiBJb25pY1NlbGVjdGFibGVDb21wb25lbnQgfT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgLyoqXG4gICAqIEZpcmVzIHdoZW4gTW9kYWwgaGFzIGJlZW4gY2xvc2VkLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNvbmNsb3NlKS5cbiAgICpcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQE91dHB1dCgpXG4gIG9uQ2xvc2U6IEV2ZW50RW1pdHRlcjx7IGNvbXBvbmVudDogSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50IH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gIC8qKlxuICAgKiBGaXJlcyB3aGVuIGFuIGl0ZW0gaGFzIGJlZW4gc2VsZWN0ZWQgb3IgdW5zZWxlY3RlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jb25zZWxlY3QpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBAT3V0cHV0KClcbiAgb25TZWxlY3Q6IEV2ZW50RW1pdHRlcjx7IGNvbXBvbmVudDogSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50LCBpdGVtOiBhbnksIGlzU2VsZWN0ZWQ6IGJvb2xlYW4gfT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgLyoqXG4gICAqIEZpcmVzIHdoZW4gQ2xlYXIgYnV0dG9uIGhhcyBiZWVuIGNsaWNrZWQuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI29uY2xlYXIpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBAT3V0cHV0KClcbiAgb25DbGVhcjogRXZlbnRFbWl0dGVyPHsgY29tcG9uZW50OiBJb25pY1NlbGVjdGFibGVDb21wb25lbnQsIGl0ZW1zOiBhbnlbXSB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAvKipcbiAgICogQSBsaXN0IG9mIGl0ZW1zIHRoYXQgYXJlIHNlbGVjdGVkIGFuZCBhd2FpdGluZyBjb25maXJtYXRpb24gYnkgdXNlciwgd2hlbiBoZSBoYXMgY2xpY2tlZCBDb25maXJtIGJ1dHRvbi5cbiAgICogQWZ0ZXIgdGhlIHVzZXIgaGFzIGNsaWNrZWQgQ29uZmlybSBidXR0b24gaXRlbXMgdG8gY29uZmlybSBhcmUgY2xlYXJlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jaXRlbXN0b2NvbmZpcm0pLlxuICAgKlxuICAgKiBAZGVmYXVsdCBbXVxuICAgKiBAcmVhZG9ubHlcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgZ2V0IGl0ZW1zVG9Db25maXJtKCk6IGFueVtdIHtcbiAgICByZXR1cm4gdGhpcy5faXRlbXNUb0NvbmZpcm07XG4gIH1cblxuICAvKipcbiAgICogSG93IGxvbmcsIGluIG1pbGxpc2Vjb25kcywgdG8gd2FpdCB0byBmaWx0ZXIgaXRlbXMgb3IgdG8gdHJpZ2dlciBgb25TZWFyY2hgIGV2ZW50IGFmdGVyIGVhY2gga2V5c3Ryb2tlLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNzZWFyY2hkZWJvdW5jZSkuXG4gICAqXG4gICAqIEBkZWZhdWx0IDI1MFxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBzZWFyY2hEZWJvdW5jZTogTnVtYmVyID0gMjUwO1xuXG4gIC8qKlxuICAgKiBBIGxpc3Qgb2YgaXRlbXMgdG8gZGlzYWJsZS5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jZGlzYWJsZWRpdGVtcykuXG4gICAqXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIEBJbnB1dCgpXG4gIGRpc2FibGVkSXRlbXM6IGFueVtdID0gW107XG5cbiAgLyoqXG4gICAqIERldGVybWluZXMgd2hldGhlciBpdGVtIHZhbHVlIG9ubHkgc2hvdWxkIGJlIHN0b3JlZCBpbiBgbmdNb2RlbGAsIG5vdCB0aGUgZW50aXJlIGl0ZW0uXG4gICAqICoqTm90ZSoqOiBJdGVtIHZhbHVlIGlzIGRlZmluZWQgYnkgYGl0ZW1WYWx1ZUZpZWxkYC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jc2hvdWxkc3RvcmVpdGVtdmFsdWUpLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBzaG91bGRTdG9yZUl0ZW1WYWx1ZSA9IGZhbHNlO1xuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgdG8gYWxsb3cgZWRpdGluZyBpdGVtcy5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jY2Fuc2F2ZWl0ZW0pLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBjYW5TYXZlSXRlbSA9IGZhbHNlO1xuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgdG8gYWxsb3cgZGVsZXRpbmcgaXRlbXMuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2NhbmRlbGV0ZWl0ZW0pLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICBjYW5EZWxldGVJdGVtID0gZmFsc2U7XG5cbiAgLyoqXG4gICAqIERldGVybWluZXMgd2hldGhlciB0byBhbGxvdyBhZGRpbmcgaXRlbXMuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2NhbmFkZGl0ZW0pLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoJ2NhbkFkZEl0ZW0nKVxuICBnZXQgY2FuQWRkSXRlbSgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5fY2FuQWRkSXRlbTtcbiAgfVxuICBzZXQgY2FuQWRkSXRlbShjYW5BZGRJdGVtOiBib29sZWFuKSB7XG4gICAgdGhpcy5fY2FuQWRkSXRlbSA9ICEhY2FuQWRkSXRlbTtcbiAgICB0aGlzLl9jb3VudEZvb3RlckJ1dHRvbnMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBGaXJlcyB3aGVuIEVkaXQgaXRlbSBidXR0b24gaGFzIGJlZW4gY2xpY2tlZC5cbiAgICogV2hlbiB0aGUgYnV0dG9uIGhhcyBiZWVuIGNsaWNrZWQgYGlvbmljU2VsZWN0YWJsZUFkZEl0ZW1UZW1wbGF0ZWAgd2lsbCBiZSBzaG93bi4gVXNlIHRoZSB0ZW1wbGF0ZSB0byBjcmVhdGUgYSBmb3JtIHRvIGVkaXQgaXRlbS5cbiAgICogKipOb3RlKio6IGBjYW5TYXZlSXRlbWAgaGFzIHRvIGJlIGVuYWJsZWQuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI29uc2F2ZWl0ZW0pLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBAT3V0cHV0KClcbiAgb25TYXZlSXRlbTogRXZlbnRFbWl0dGVyPHsgY29tcG9uZW50OiBJb25pY1NlbGVjdGFibGVDb21wb25lbnQsIGl0ZW06IGFueSB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAvKipcbiAgICogRmlyZXMgd2hlbiBEZWxldGUgaXRlbSBidXR0b24gaGFzIGJlZW4gY2xpY2tlZC5cbiAgICogKipOb3RlKio6IGBjYW5EZWxldGVJdGVtYCBoYXMgdG8gYmUgZW5hYmxlZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jb25kZWxldGVpdGVtKS5cbiAgICpcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgQE91dHB1dCgpXG4gIG9uRGVsZXRlSXRlbTogRXZlbnRFbWl0dGVyPHsgY29tcG9uZW50OiBJb25pY1NlbGVjdGFibGVDb21wb25lbnQsIGl0ZW06IGFueSB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICAvKipcbiAgICogRmlyZXMgd2hlbiBBZGQgaXRlbSBidXR0b24gaGFzIGJlZW4gY2xpY2tlZC5cbiAgICogV2hlbiB0aGUgYnV0dG9uIGhhcyBiZWVuIGNsaWNrZWQgYGlvbmljU2VsZWN0YWJsZUFkZEl0ZW1UZW1wbGF0ZWAgd2lsbCBiZSBzaG93bi4gVXNlIHRoZSB0ZW1wbGF0ZSB0byBjcmVhdGUgYSBmb3JtIHRvIGFkZCBpdGVtLlxuICAgKiAqKk5vdGUqKjogYGNhbkFkZEl0ZW1gIGhhcyB0byBiZSBlbmFibGVkLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNvbmFkZGl0ZW0pLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBAT3V0cHV0KClcbiAgb25BZGRJdGVtOiBFdmVudEVtaXR0ZXI8eyBjb21wb25lbnQ6IElvbmljU2VsZWN0YWJsZUNvbXBvbmVudCB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBAQ29udGVudENoaWxkKElvbmljU2VsZWN0YWJsZVZhbHVlVGVtcGxhdGVEaXJlY3RpdmUsIHsgcmVhZDogVGVtcGxhdGVSZWYgfSlcbiAgdmFsdWVUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgQENvbnRlbnRDaGlsZChJb25pY1NlbGVjdGFibGVJdGVtVGVtcGxhdGVEaXJlY3RpdmUsIHsgcmVhZDogVGVtcGxhdGVSZWYgfSlcbiAgaXRlbVRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBAQ29udGVudENoaWxkKElvbmljU2VsZWN0YWJsZUl0ZW1FbmRUZW1wbGF0ZURpcmVjdGl2ZSwgeyByZWFkOiBUZW1wbGF0ZVJlZiB9KVxuICBpdGVtRW5kVGVtcGxhdGU6IFRlbXBsYXRlUmVmPGFueT47XG4gIEBDb250ZW50Q2hpbGQoSW9uaWNTZWxlY3RhYmxlVGl0bGVUZW1wbGF0ZURpcmVjdGl2ZSwgeyByZWFkOiBUZW1wbGF0ZVJlZiB9KVxuICB0aXRsZVRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBAQ29udGVudENoaWxkKElvbmljU2VsZWN0YWJsZVBsYWNlaG9sZGVyVGVtcGxhdGVEaXJlY3RpdmUsIHsgcmVhZDogVGVtcGxhdGVSZWYgfSlcbiAgcGxhY2Vob2xkZXJUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgQENvbnRlbnRDaGlsZChJb25pY1NlbGVjdGFibGVNZXNzYWdlVGVtcGxhdGVEaXJlY3RpdmUsIHsgcmVhZDogVGVtcGxhdGVSZWYgfSlcbiAgbWVzc2FnZVRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBAQ29udGVudENoaWxkKElvbmljU2VsZWN0YWJsZUdyb3VwVGVtcGxhdGVEaXJlY3RpdmUsIHsgcmVhZDogVGVtcGxhdGVSZWYgfSlcbiAgZ3JvdXBUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgQENvbnRlbnRDaGlsZChJb25pY1NlbGVjdGFibGVHcm91cEVuZFRlbXBsYXRlRGlyZWN0aXZlLCB7IHJlYWQ6IFRlbXBsYXRlUmVmIH0pXG4gIGdyb3VwRW5kVGVtcGxhdGU6IFRlbXBsYXRlUmVmPGFueT47XG4gIEBDb250ZW50Q2hpbGQoSW9uaWNTZWxlY3RhYmxlQ2xvc2VCdXR0b25UZW1wbGF0ZURpcmVjdGl2ZSwgeyByZWFkOiBUZW1wbGF0ZVJlZiB9KVxuICBjbG9zZUJ1dHRvblRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBAQ29udGVudENoaWxkKElvbmljU2VsZWN0YWJsZVNlYXJjaEZhaWxUZW1wbGF0ZURpcmVjdGl2ZSwgeyByZWFkOiBUZW1wbGF0ZVJlZiB9KVxuICBzZWFyY2hGYWlsVGVtcGxhdGU6IFRlbXBsYXRlUmVmPGFueT47XG4gIEBDb250ZW50Q2hpbGQoSW9uaWNTZWxlY3RhYmxlQWRkSXRlbVRlbXBsYXRlRGlyZWN0aXZlLCB7IHJlYWQ6IFRlbXBsYXRlUmVmIH0pXG4gIGFkZEl0ZW1UZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgQENvbnRlbnRDaGlsZChJb25pY1NlbGVjdGFibGVGb290ZXJUZW1wbGF0ZURpcmVjdGl2ZSwgeyByZWFkOiBUZW1wbGF0ZVJlZiB9KVxuICBmb290ZXJUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgX2FkZEl0ZW1UZW1wbGF0ZUZvb3RlckhlaWdodDogc3RyaW5nO1xuICBAQ29udGVudENoaWxkKElvbmljU2VsZWN0YWJsZUhlYWRlclRlbXBsYXRlRGlyZWN0aXZlLCB7IHJlYWQ6IFRlbXBsYXRlUmVmIH0pXG4gIGhlYWRlclRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBAQ29udGVudENoaWxkKElvbmljU2VsZWN0YWJsZUl0ZW1JY29uVGVtcGxhdGVEaXJlY3RpdmUsIHsgcmVhZDogVGVtcGxhdGVSZWYgfSlcbiAgaXRlbUljb25UZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgQENvbnRlbnRDaGlsZChJb25pY1NlbGVjdGFibGVJY29uVGVtcGxhdGVEaXJlY3RpdmUsIHsgcmVhZDogVGVtcGxhdGVSZWYgfSlcbiAgaWNvblRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuXG4gIC8qKlxuICAgKiBTZWUgSW9uaWMgVmlydHVhbFNjcm9sbCBbaGVhZGVyRm5dKGh0dHBzOi8vaW9uaWNmcmFtZXdvcmsuY29tL2RvY3MvYXBpL2NvbXBvbmVudHMvdmlydHVhbC1zY3JvbGwvVmlydHVhbFNjcm9sbC8pLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiN2aXJ0dWFsc2Nyb2xsaGVhZGVyZm4pLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBASW5wdXQoKVxuICB2aXJ0dWFsU2Nyb2xsSGVhZGVyRm4gPSAoKSA9PiB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIF9tb2RhbENvbnRyb2xsZXI6IE1vZGFsQ29udHJvbGxlcixcbiAgICBwcml2YXRlIF9wbGF0Zm9ybTogUGxhdGZvcm0sXG4gICAgQE9wdGlvbmFsKCkgcHJpdmF0ZSBpb25JdGVtOiBJb25JdGVtLFxuICAgIHByaXZhdGUgX2l0ZXJhYmxlRGlmZmVyczogSXRlcmFibGVEaWZmZXJzLFxuICAgIHByaXZhdGUgX2VsZW1lbnQ6IEVsZW1lbnRSZWYsXG4gICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMlxuICApIHtcbiAgICBpZiAoIXRoaXMuaXRlbXMgfHwgIXRoaXMuaXRlbXMubGVuZ3RoKSB7XG4gICAgICB0aGlzLml0ZW1zID0gW107XG4gICAgfVxuXG4gICAgdGhpcy5faXRlbXNEaWZmZXIgPSB0aGlzLl9pdGVyYWJsZURpZmZlcnMuZmluZCh0aGlzLml0ZW1zKS5jcmVhdGUoKTtcbiAgfVxuXG4gIGluaXRGb2N1cygpIHsgfVxuXG4gIGVuYWJsZUlvbkl0ZW0oaXNFbmFibGVkOiBib29sZWFuKSB7XG4gICAgaWYgKCF0aGlzLmlvbkl0ZW0pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLmlvbkl0ZW0uZGlzYWJsZWQgPSAhaXNFbmFibGVkO1xuICB9XG5cbiAgX2lzTnVsbE9yV2hpdGVTcGFjZSh2YWx1ZTogYW55KTogYm9vbGVhbiB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIC8vIENvbnZlcnQgdmFsdWUgdG8gc3RyaW5nIGluIGNhc2UgaWYgaXQncyBub3QuXG4gICAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCkucmVwbGFjZSgvXFxzL2csICcnKS5sZW5ndGggPCAxO1xuICB9XG5cbiAgX3NldEhhc1NlYXJjaFRleHQoKSB7XG4gICAgdGhpcy5faGFzU2VhcmNoVGV4dCA9ICF0aGlzLl9pc051bGxPcldoaXRlU3BhY2UodGhpcy5fc2VhcmNoVGV4dCk7XG4gIH1cblxuICBfaGFzT25TZWFyY2goKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuaXNPblNlYXJjaEVuYWJsZWQgJiYgdGhpcy5vblNlYXJjaC5vYnNlcnZlcnMubGVuZ3RoID4gMDtcbiAgfVxuXG4gIF9oYXNPblNhdmVJdGVtKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLmNhblNhdmVJdGVtICYmIHRoaXMub25TYXZlSXRlbS5vYnNlcnZlcnMubGVuZ3RoID4gMDtcbiAgfVxuXG4gIF9oYXNPbkFkZEl0ZW0oKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuY2FuQWRkSXRlbSAmJiB0aGlzLm9uQWRkSXRlbS5vYnNlcnZlcnMubGVuZ3RoID4gMDtcbiAgfVxuXG4gIF9oYXNPbkRlbGV0ZUl0ZW0oKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuY2FuRGVsZXRlSXRlbSAmJiB0aGlzLm9uRGVsZXRlSXRlbS5vYnNlcnZlcnMubGVuZ3RoID4gMDtcbiAgfVxuXG4gIF9lbWl0VmFsdWVDaGFuZ2UoKSB7XG4gICAgdGhpcy5wcm9wYWdhdGVPbkNoYW5nZSh0aGlzLnZhbHVlKTtcblxuICAgIHRoaXMub25DaGFuZ2UuZW1pdCh7XG4gICAgICBjb21wb25lbnQ6IHRoaXMsXG4gICAgICB2YWx1ZTogdGhpcy52YWx1ZVxuICAgIH0pO1xuICB9XG5cbiAgX2VtaXRTZWFyY2goKSB7XG4gICAgaWYgKCF0aGlzLmNhblNlYXJjaCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMub25TZWFyY2guZW1pdCh7XG4gICAgICBjb21wb25lbnQ6IHRoaXMsXG4gICAgICB0ZXh0OiB0aGlzLl9zZWFyY2hUZXh0XG4gICAgfSk7XG4gIH1cblxuICBfZW1pdE9uU2VsZWN0KGl0ZW06IGFueSwgaXNTZWxlY3RlZDogYm9vbGVhbikge1xuICAgIHRoaXMub25TZWxlY3QuZW1pdCh7XG4gICAgICBjb21wb25lbnQ6IHRoaXMsXG4gICAgICBpdGVtOiBpdGVtLFxuICAgICAgaXNTZWxlY3RlZDogaXNTZWxlY3RlZFxuICAgIH0pO1xuICB9XG5cbiAgX2VtaXRPbkNsZWFyKGl0ZW1zOiBhbnlbXSkge1xuICAgIHRoaXMub25DbGVhci5lbWl0KHtcbiAgICAgIGNvbXBvbmVudDogdGhpcyxcbiAgICAgIGl0ZW1zOiBpdGVtc1xuICAgIH0pO1xuICB9XG5cbiAgX2VtaXRPblNlYXJjaFN1Y2Nlc3NPckZhaWwoaXNTdWNjZXNzOiBib29sZWFuKSB7XG4gICAgY29uc3QgZXZlbnREYXRhID0ge1xuICAgICAgY29tcG9uZW50OiB0aGlzLFxuICAgICAgdGV4dDogdGhpcy5fc2VhcmNoVGV4dFxuICAgIH07XG5cbiAgICBpZiAoaXNTdWNjZXNzKSB7XG4gICAgICB0aGlzLm9uU2VhcmNoU3VjY2Vzcy5lbWl0KGV2ZW50RGF0YSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMub25TZWFyY2hGYWlsLmVtaXQoZXZlbnREYXRhKTtcbiAgICB9XG4gIH1cblxuICBfZm9ybWF0SXRlbShpdGVtOiBhbnkpOiBzdHJpbmcge1xuICAgIGlmICh0aGlzLl9pc051bGxPcldoaXRlU3BhY2UoaXRlbSkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLml0ZW1UZXh0RmllbGQgPyBpdGVtW3RoaXMuaXRlbVRleHRGaWVsZF0gOiBpdGVtLnRvU3RyaW5nKCk7XG4gIH1cblxuICBfZm9ybWF0VmFsdWVJdGVtKGl0ZW06IGFueSk6IHN0cmluZyB7XG4gICAgaWYgKHRoaXMuX3Nob3VsZFN0b3JlSXRlbVZhbHVlKSB7XG4gICAgICAvLyBHZXQgaXRlbSB0ZXh0IGZyb20gdGhlIGxpc3QgYXMgd2Ugc3RvcmUgaXQncyB2YWx1ZSBvbmx5LlxuICAgICAgY29uc3Qgc2VsZWN0ZWRJdGVtID0gdGhpcy5pdGVtcy5maW5kKF9pdGVtID0+IHtcbiAgICAgICAgcmV0dXJuIF9pdGVtW3RoaXMuaXRlbVZhbHVlRmllbGRdID09PSBpdGVtO1xuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiB0aGlzLl9mb3JtYXRJdGVtKHNlbGVjdGVkSXRlbSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0aGlzLl9mb3JtYXRJdGVtKGl0ZW0pO1xuICAgIH1cbiAgfVxuXG4gIF9nZXRJdGVtVmFsdWUoaXRlbTogYW55KTogYW55IHtcbiAgICBpZiAoIXRoaXMuX2hhc09iamVjdHMpIHtcbiAgICAgIHJldHVybiBpdGVtO1xuICAgIH1cblxuICAgIHJldHVybiBpdGVtW3RoaXMuaXRlbVZhbHVlRmllbGRdO1xuICB9XG5cbiAgX2dldFN0b3JlZEl0ZW1WYWx1ZShpdGVtOiBhbnkpOiBhbnkge1xuICAgIGlmICghdGhpcy5faGFzT2JqZWN0cykge1xuICAgICAgcmV0dXJuIGl0ZW07XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3Nob3VsZFN0b3JlSXRlbVZhbHVlID8gaXRlbSA6IGl0ZW1bdGhpcy5pdGVtVmFsdWVGaWVsZF07XG4gIH1cblxuICBfb25TZWFyY2hiYXJDbGVhcigpIHtcbiAgICAvLyBJb25pYyBTZWFyY2hiYXIgZG9lc24ndCBjbGVhciBiaW5kIHdpdGggbmdNb2RlbCB2YWx1ZS5cbiAgICAvLyBEbyBpdCBvdXJzZWx2ZXMuXG4gICAgdGhpcy5fc2VhcmNoVGV4dCA9ICcnO1xuICB9XG5cbiAgX2ZpbHRlckl0ZW1zKCkge1xuICAgIHRoaXMuX3NldEhhc1NlYXJjaFRleHQoKTtcblxuICAgIGlmICh0aGlzLl9oYXNPblNlYXJjaCgpKSB7XG4gICAgICAvLyBEZWxlZ2F0ZSBmaWx0ZXJpbmcgdG8gdGhlIGV2ZW50LlxuICAgICAgdGhpcy5fZW1pdFNlYXJjaCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBEZWZhdWx0IGZpbHRlcmluZy5cbiAgICAgIGxldCBncm91cHMgPSBbXTtcblxuICAgICAgaWYgKCF0aGlzLl9zZWFyY2hUZXh0IHx8ICF0aGlzLl9zZWFyY2hUZXh0LnRyaW0oKSkge1xuICAgICAgICBncm91cHMgPSB0aGlzLl9ncm91cHM7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBmaWx0ZXJUZXh0ID0gdGhpcy5fc2VhcmNoVGV4dC50cmltKCkudG9Mb3dlckNhc2UoKTtcblxuICAgICAgICB0aGlzLl9ncm91cHMuZm9yRWFjaChncm91cCA9PiB7XG4gICAgICAgICAgY29uc3QgaXRlbXMgPSBncm91cC5pdGVtcy5maWx0ZXIoaXRlbSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpdGVtVGV4dCA9ICh0aGlzLml0ZW1UZXh0RmllbGQgP1xuICAgICAgICAgICAgICBpdGVtW3RoaXMuaXRlbVRleHRGaWVsZF0gOiBpdGVtKS50b1N0cmluZygpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICByZXR1cm4gaXRlbVRleHQuaW5kZXhPZihmaWx0ZXJUZXh0KSAhPT0gLTE7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpZiAoaXRlbXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBncm91cHMucHVzaCh7XG4gICAgICAgICAgICAgIHZhbHVlOiBncm91cC52YWx1ZSxcbiAgICAgICAgICAgICAgdGV4dDogZ3JvdXAudGV4dCxcbiAgICAgICAgICAgICAgaXRlbXM6IGl0ZW1zXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIE5vIGl0ZW1zIGZvdW5kLlxuICAgICAgICBpZiAoIWdyb3Vwcy5sZW5ndGgpIHtcbiAgICAgICAgICBncm91cHMucHVzaCh7XG4gICAgICAgICAgICBpdGVtczogW11cbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB0aGlzLl9maWx0ZXJlZEdyb3VwcyA9IGdyb3VwcztcbiAgICAgIHRoaXMuX2hhc0ZpbHRlcmVkSXRlbXMgPSAhdGhpcy5fYXJlR3JvdXBzRW1wdHkoZ3JvdXBzKTtcbiAgICAgIHRoaXMuX2VtaXRPblNlYXJjaFN1Y2Nlc3NPckZhaWwodGhpcy5faGFzRmlsdGVyZWRJdGVtcyk7XG4gICAgfVxuICB9XG5cbiAgX2lzSXRlbURpc2FibGVkKGl0ZW06IGFueSk6IGJvb2xlYW4ge1xuICAgIGlmICghdGhpcy5kaXNhYmxlZEl0ZW1zKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuZGlzYWJsZWRJdGVtcy5zb21lKF9pdGVtID0+IHtcbiAgICAgIHJldHVybiB0aGlzLl9nZXRJdGVtVmFsdWUoX2l0ZW0pID09PSB0aGlzLl9nZXRJdGVtVmFsdWUoaXRlbSk7XG4gICAgfSk7XG4gIH1cblxuICBfaXNJdGVtU2VsZWN0ZWQoaXRlbTogYW55KSB7XG4gICAgcmV0dXJuIHRoaXMuX3NlbGVjdGVkSXRlbXMuZmluZChzZWxlY3RlZEl0ZW0gPT4ge1xuICAgICAgcmV0dXJuIHRoaXMuX2dldEl0ZW1WYWx1ZShpdGVtKSA9PT0gdGhpcy5fZ2V0U3RvcmVkSXRlbVZhbHVlKHNlbGVjdGVkSXRlbSk7XG4gICAgfSkgIT09IHVuZGVmaW5lZDtcbiAgfVxuXG4gIF9hZGRTZWxlY3RlZEl0ZW0oaXRlbTogYW55KSB7XG4gICAgaWYgKHRoaXMuX3Nob3VsZFN0b3JlSXRlbVZhbHVlKSB7XG4gICAgICB0aGlzLl9zZWxlY3RlZEl0ZW1zLnB1c2godGhpcy5fZ2V0SXRlbVZhbHVlKGl0ZW0pKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fc2VsZWN0ZWRJdGVtcy5wdXNoKGl0ZW0pO1xuICAgIH1cbiAgfVxuXG4gIF9kZWxldGVTZWxlY3RlZEl0ZW0oaXRlbTogYW55KSB7XG4gICAgbGV0IGl0ZW1Ub0RlbGV0ZUluZGV4O1xuXG4gICAgdGhpcy5fc2VsZWN0ZWRJdGVtcy5mb3JFYWNoKChzZWxlY3RlZEl0ZW0sIGl0ZW1JbmRleCkgPT4ge1xuICAgICAgaWYgKFxuICAgICAgICB0aGlzLl9nZXRJdGVtVmFsdWUoaXRlbSkgPT09XG4gICAgICAgIHRoaXMuX2dldFN0b3JlZEl0ZW1WYWx1ZShzZWxlY3RlZEl0ZW0pXG4gICAgICApIHtcbiAgICAgICAgaXRlbVRvRGVsZXRlSW5kZXggPSBpdGVtSW5kZXg7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICB0aGlzLl9zZWxlY3RlZEl0ZW1zLnNwbGljZShpdGVtVG9EZWxldGVJbmRleCwgMSk7XG4gIH1cblxuICBfY2xpY2soKSB7XG4gICAgaWYgKCF0aGlzLmlzRW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMuX2xhYmVsID0gdGhpcy5fZ2V0TGFiZWxUZXh0KCk7XG4gICAgdGhpcy5vcGVuKCkudGhlbigoKSA9PiB7XG4gICAgICB0aGlzLm9uT3Blbi5lbWl0KHtcbiAgICAgICAgY29tcG9uZW50OiB0aGlzXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIF9zYXZlSXRlbShldmVudDogRXZlbnQsIGl0ZW06IGFueSkge1xuICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIHRoaXMuX2l0ZW1Ub0FkZCA9IGl0ZW07XG5cbiAgICBpZiAodGhpcy5faGFzT25TYXZlSXRlbSgpKSB7XG4gICAgICB0aGlzLm9uU2F2ZUl0ZW0uZW1pdCh7XG4gICAgICAgIGNvbXBvbmVudDogdGhpcyxcbiAgICAgICAgaXRlbTogdGhpcy5faXRlbVRvQWRkXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zaG93QWRkSXRlbVRlbXBsYXRlKCk7XG4gICAgfVxuICB9XG5cbiAgX2RlbGV0ZUl0ZW1DbGljayhldmVudDogRXZlbnQsIGl0ZW06IGFueSkge1xuICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIHRoaXMuX2l0ZW1Ub0FkZCA9IGl0ZW07XG5cbiAgICBpZiAodGhpcy5faGFzT25EZWxldGVJdGVtKCkpIHtcbiAgICAgIC8vIERlbGVnYXRlIGxvZ2ljIHRvIGV2ZW50LlxuICAgICAgdGhpcy5vbkRlbGV0ZUl0ZW0uZW1pdCh7XG4gICAgICAgIGNvbXBvbmVudDogdGhpcyxcbiAgICAgICAgaXRlbTogdGhpcy5faXRlbVRvQWRkXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5kZWxldGVJdGVtKHRoaXMuX2l0ZW1Ub0FkZCk7XG4gICAgfVxuICB9XG5cbiAgX2FkZEl0ZW1DbGljaygpIHtcbiAgICBpZiAodGhpcy5faGFzT25BZGRJdGVtKCkpIHtcbiAgICAgIHRoaXMub25BZGRJdGVtLmVtaXQoe1xuICAgICAgICBjb21wb25lbnQ6IHRoaXNcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNob3dBZGRJdGVtVGVtcGxhdGUoKTtcbiAgICB9XG4gIH1cblxuICBfcG9zaXRpb25BZGRJdGVtVGVtcGxhdGUoKSB7XG4gICAgLy8gV2FpdCBmb3IgdGhlIHRlbXBsYXRlIHRvIHJlbmRlci5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGNvbnN0IGZvb3RlciA9IHRoaXMuX21vZGFsQ29tcG9uZW50Ll9lbGVtZW50Lm5hdGl2ZUVsZW1lbnRcbiAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJy5pb25pYy1zZWxlY3RhYmxlLWFkZC1pdGVtLXRlbXBsYXRlIGlvbi1mb290ZXInKTtcblxuICAgICAgdGhpcy5fYWRkSXRlbVRlbXBsYXRlRm9vdGVySGVpZ2h0ID0gZm9vdGVyID8gYGNhbGMoMTAwJSAtICR7Zm9vdGVyLm9mZnNldEhlaWdodH1weClgIDogJzEwMCUnO1xuICAgIH0sIDEwMCk7XG4gIH1cblxuICBfY2xvc2UoKSB7XG4gICAgdGhpcy5jbG9zZSgpLnRoZW4oKCkgPT4ge1xuICAgICAgdGhpcy5vbkNsb3NlLmVtaXQoe1xuICAgICAgICBjb21wb25lbnQ6IHRoaXNcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgaWYgKCF0aGlzLl9oYXNPblNlYXJjaCgpKSB7XG4gICAgICB0aGlzLl9zZWFyY2hUZXh0ID0gJyc7XG4gICAgICB0aGlzLl9zZXRIYXNTZWFyY2hUZXh0KCk7XG4gICAgfVxuICB9XG5cbiAgX2NsZWFyKCkge1xuICAgIGNvbnN0IHNlbGVjdGVkSXRlbXMgPSB0aGlzLl9zZWxlY3RlZEl0ZW1zO1xuXG4gICAgdGhpcy5jbGVhcigpO1xuICAgIHRoaXMuX2VtaXRWYWx1ZUNoYW5nZSgpO1xuICAgIHRoaXMuX2VtaXRPbkNsZWFyKHNlbGVjdGVkSXRlbXMpO1xuICAgIHRoaXMuY2xvc2UoKS50aGVuKCgpID0+IHtcbiAgICAgIHRoaXMub25DbG9zZS5lbWl0KHtcbiAgICAgICAgY29tcG9uZW50OiB0aGlzXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIF9nZXRNb3JlSXRlbXMoKSB7XG4gICAgdGhpcy5vbkluZmluaXRlU2Nyb2xsLmVtaXQoe1xuICAgICAgY29tcG9uZW50OiB0aGlzLFxuICAgICAgdGV4dDogdGhpcy5fc2VhcmNoVGV4dFxuICAgIH0pO1xuICB9XG5cbiAgX3NldEl0ZW1zVG9Db25maXJtKGl0ZW1zOiBhbnlbXSkge1xuICAgIC8vIFJldHVybiBhIGNvcHkgb2Ygb3JpZ2luYWwgYXJyYXksIHNvIGl0IGNvdWxkbid0IGJlIGNoYW5nZWQgZnJvbSBvdXRzaWRlLlxuICAgIHRoaXMuX2l0ZW1zVG9Db25maXJtID0gW10uY29uY2F0KGl0ZW1zKTtcbiAgfVxuXG4gIF9kb1NlbGVjdChzZWxlY3RlZEl0ZW06IGFueSkge1xuICAgIHRoaXMudmFsdWUgPSBzZWxlY3RlZEl0ZW07XG4gICAgdGhpcy5fZW1pdFZhbHVlQ2hhbmdlKCk7XG4gIH1cblxuICBfc2VsZWN0KGl0ZW06IGFueSkge1xuICAgIGNvbnN0IGlzSXRlbVNlbGVjdGVkID0gdGhpcy5faXNJdGVtU2VsZWN0ZWQoaXRlbSk7XG5cbiAgICBpZiAodGhpcy5pc011bHRpcGxlKSB7XG4gICAgICBpZiAoaXNJdGVtU2VsZWN0ZWQpIHtcbiAgICAgICAgdGhpcy5fZGVsZXRlU2VsZWN0ZWRJdGVtKGl0ZW0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5fYWRkU2VsZWN0ZWRJdGVtKGl0ZW0pO1xuICAgICAgfVxuXG4gICAgICB0aGlzLl9zZXRJdGVtc1RvQ29uZmlybSh0aGlzLl9zZWxlY3RlZEl0ZW1zKTtcblxuICAgICAgLy8gRW1pdCBvblNlbGVjdCBldmVudCBhZnRlciBzZXR0aW5nIGl0ZW1zIHRvIGNvbmZpcm0gc28gdGhleSBjb3VsZCBiZSB1c2VkXG4gICAgICAvLyBpbnNpZGUgdGhlIGV2ZW50LlxuICAgICAgdGhpcy5fZW1pdE9uU2VsZWN0KGl0ZW0sICFpc0l0ZW1TZWxlY3RlZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh0aGlzLmhhc0NvbmZpcm1CdXR0b24gfHwgdGhpcy5mb290ZXJUZW1wbGF0ZSkge1xuICAgICAgICAvLyBEb24ndCBjbG9zZSBNb2RhbCBhbmQga2VlcCB0cmFjayBvbiBpdGVtcyB0byBjb25maXJtLlxuICAgICAgICAvLyBXaGVuIGZvb3RlciB0ZW1wbGF0ZSBpcyB1c2VkIGl0J3MgdXAgdG8gZGV2ZWxvcGVyIHRvIGNsb3NlIE1vZGFsLlxuICAgICAgICB0aGlzLl9zZWxlY3RlZEl0ZW1zID0gW107XG5cbiAgICAgICAgaWYgKGlzSXRlbVNlbGVjdGVkKSB7XG4gICAgICAgICAgdGhpcy5fZGVsZXRlU2VsZWN0ZWRJdGVtKGl0ZW0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuX2FkZFNlbGVjdGVkSXRlbShpdGVtKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuX3NldEl0ZW1zVG9Db25maXJtKHRoaXMuX3NlbGVjdGVkSXRlbXMpO1xuXG4gICAgICAgIC8vIEVtaXQgb25TZWxlY3QgZXZlbnQgYWZ0ZXIgc2V0dGluZyBpdGVtcyB0byBjb25maXJtIHNvIHRoZXkgY291bGQgYmUgdXNlZFxuICAgICAgICAvLyBpbnNpZGUgdGhlIGV2ZW50LlxuICAgICAgICB0aGlzLl9lbWl0T25TZWxlY3QoaXRlbSwgIWlzSXRlbVNlbGVjdGVkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmICghaXNJdGVtU2VsZWN0ZWQpIHtcbiAgICAgICAgICB0aGlzLl9zZWxlY3RlZEl0ZW1zID0gW107XG4gICAgICAgICAgdGhpcy5fYWRkU2VsZWN0ZWRJdGVtKGl0ZW0pO1xuXG4gICAgICAgICAgLy8gRW1pdCBvblNlbGVjdCBiZWZvcmUgb25DaGFuZ2UuXG4gICAgICAgICAgdGhpcy5fZW1pdE9uU2VsZWN0KGl0ZW0sIHRydWUpO1xuXG4gICAgICAgICAgaWYgKHRoaXMuX3Nob3VsZFN0b3JlSXRlbVZhbHVlKSB7XG4gICAgICAgICAgICB0aGlzLl9kb1NlbGVjdCh0aGlzLl9nZXRJdGVtVmFsdWUoaXRlbSkpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9kb1NlbGVjdChpdGVtKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9jbG9zZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIF9jb25maXJtKCkge1xuICAgIHRoaXMuY29uZmlybSgpO1xuICAgIHRoaXMuX2Nsb3NlKCk7XG4gIH1cblxuICBwcml2YXRlIF9nZXRMYWJlbFRleHQoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5faW9uTGFiZWxFbGVtZW50ID8gdGhpcy5faW9uTGFiZWxFbGVtZW50LnRleHRDb250ZW50IDogbnVsbDtcbiAgfVxuXG4gIHByaXZhdGUgX2FyZUdyb3Vwc0VtcHR5KGdyb3Vwcykge1xuICAgIHJldHVybiBncm91cHMubGVuZ3RoID09PSAwIHx8IGdyb3Vwcy5ldmVyeShncm91cCA9PiB7XG4gICAgICByZXR1cm4gIWdyb3VwLml0ZW1zIHx8IGdyb3VwLml0ZW1zLmxlbmd0aCA9PT0gMDtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgX2NvdW50Rm9vdGVyQnV0dG9ucygpIHtcbiAgICBsZXQgZm9vdGVyQnV0dG9uc0NvdW50ID0gMDtcblxuICAgIGlmICh0aGlzLmNhbkNsZWFyKSB7XG4gICAgICBmb290ZXJCdXR0b25zQ291bnQrKztcbiAgICB9XG5cbiAgICBpZiAodGhpcy5pc011bHRpcGxlIHx8IHRoaXMuX2hhc0NvbmZpcm1CdXR0b24pIHtcbiAgICAgIGZvb3RlckJ1dHRvbnNDb3VudCsrO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmNhbkFkZEl0ZW0pIHtcbiAgICAgIGZvb3RlckJ1dHRvbnNDb3VudCsrO1xuICAgIH1cblxuICAgIHRoaXMuX2Zvb3RlckJ1dHRvbnNDb3VudCA9IGZvb3RlckJ1dHRvbnNDb3VudDtcbiAgfVxuXG4gIHByaXZhdGUgX3NldEl0ZW1zKGl0ZW1zOiBhbnlbXSkge1xuICAgIC8vIEl0J3MgaW1wb3J0YW50IHRvIGhhdmUgYW4gZW1wdHkgc3RhcnRpbmcgZ3JvdXAgd2l0aCBlbXB0eSBpdGVtcyAoZ3JvdXBzWzBdLml0ZW1zKSxcbiAgICAvLyBiZWNhdXNlIHdlIGJpbmQgdG8gaXQgd2hlbiB1c2luZyBWaXJ0dWFsU2Nyb2xsLlxuICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL2lzc3Vlcy83MC5cbiAgICBsZXQgZ3JvdXBzOiBhbnlbXSA9IFt7XG4gICAgICBpdGVtczogaXRlbXMgfHwgW11cbiAgICB9XTtcblxuICAgIGlmIChpdGVtcyAmJiBpdGVtcy5sZW5ndGgpIHtcbiAgICAgIGlmICh0aGlzLl9oYXNHcm91cHMpIHtcbiAgICAgICAgZ3JvdXBzID0gW107XG5cbiAgICAgICAgaXRlbXMuZm9yRWFjaChpdGVtID0+IHtcbiAgICAgICAgICBjb25zdCBncm91cFZhbHVlID0gdGhpcy5fZ2V0UHJvcGVydHlWYWx1ZShpdGVtLCB0aGlzLmdyb3VwVmFsdWVGaWVsZCksXG4gICAgICAgICAgICBncm91cCA9IGdyb3Vwcy5maW5kKF9ncm91cCA9PiBfZ3JvdXAudmFsdWUgPT09IGdyb3VwVmFsdWUpO1xuXG4gICAgICAgICAgaWYgKGdyb3VwKSB7XG4gICAgICAgICAgICBncm91cC5pdGVtcy5wdXNoKGl0ZW0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBncm91cHMucHVzaCh7XG4gICAgICAgICAgICAgIHZhbHVlOiBncm91cFZhbHVlLFxuICAgICAgICAgICAgICB0ZXh0OiB0aGlzLl9nZXRQcm9wZXJ0eVZhbHVlKGl0ZW0sIHRoaXMuZ3JvdXBUZXh0RmllbGQpLFxuICAgICAgICAgICAgICBpdGVtczogW2l0ZW1dXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuX2dyb3VwcyA9IGdyb3VwcztcbiAgICB0aGlzLl9maWx0ZXJlZEdyb3VwcyA9IHRoaXMuX2dyb3VwcztcbiAgICB0aGlzLl9oYXNGaWx0ZXJlZEl0ZW1zID0gIXRoaXMuX2FyZUdyb3Vwc0VtcHR5KHRoaXMuX2ZpbHRlcmVkR3JvdXBzKTtcbiAgfVxuXG4gIHByaXZhdGUgX2dldFByb3BlcnR5VmFsdWUob2JqZWN0OiBhbnksIHByb3BlcnR5OiBzdHJpbmcpOiBhbnkge1xuICAgIGlmICghcHJvcGVydHkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHJldHVybiBwcm9wZXJ0eS5zcGxpdCgnLicpLnJlZHVjZSgoX29iamVjdCwgX3Byb3BlcnR5KSA9PiB7XG4gICAgICByZXR1cm4gX29iamVjdCA/IF9vYmplY3RbX3Byb3BlcnR5XSA6IG51bGw7XG4gICAgfSwgb2JqZWN0KTtcbiAgfVxuXG4gIHByaXZhdGUgX3NldElvbkl0ZW1IYXNGb2N1cyhoYXNGb2N1czogYm9vbGVhbikge1xuICAgIGlmICghdGhpcy5pb25JdGVtKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQXBwbHkgZm9jdXMgQ1NTIGNsYXNzIGZvciBwcm9wZXIgc3R5bHlpbmcgb2YgaW9uLWl0ZW0vaW9uLWxhYmVsLlxuICAgIHRoaXMuX3NldElvbkl0ZW1Dc3NDbGFzcygnaXRlbS1oYXMtZm9jdXMnLCBoYXNGb2N1cyk7XG4gIH1cblxuICBwcml2YXRlIF9zZXRJb25JdGVtSGFzVmFsdWUoKSB7XG4gICAgaWYgKCF0aGlzLmlvbkl0ZW0pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBBcHBseSB2YWx1ZSBDU1MgY2xhc3MgZm9yIHByb3BlciBzdHlseWluZyBvZiBpb24taXRlbS9pb24tbGFiZWwuXG4gICAgdGhpcy5fc2V0SW9uSXRlbUNzc0NsYXNzKCdpdGVtLWhhcy12YWx1ZScsIHRoaXMuaGFzVmFsdWUoKSk7XG4gIH1cblxuICBwcml2YXRlIF9zZXRIYXNQbGFjZWhvbGRlcigpIHtcbiAgICB0aGlzLl9oYXNQbGFjZWhvbGRlciA9ICF0aGlzLmhhc1ZhbHVlKCkgJiZcbiAgICAgICghdGhpcy5faXNOdWxsT3JXaGl0ZVNwYWNlKHRoaXMucGxhY2Vob2xkZXIpIHx8IHRoaXMucGxhY2Vob2xkZXJUZW1wbGF0ZSkgP1xuICAgICAgdHJ1ZSA6IGZhbHNlO1xuICB9XG5cbiAgcHJpdmF0ZSBwcm9wYWdhdGVPbkNoYW5nZSA9IChfOiBhbnkpID0+IHsgfTtcbiAgcHJpdmF0ZSBwcm9wYWdhdGVPblRvdWNoZWQgPSAoKSA9PiB7IH07XG5cbiAgcHJpdmF0ZSBfc2V0SW9uSXRlbUNzc0NsYXNzKGNzc0NsYXNzOiBzdHJpbmcsIHNob3VsZEFkZDogYm9vbGVhbikge1xuICAgIGlmICghdGhpcy5faW9uSXRlbUVsZW1lbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBDaGFuZ2UgdG8gUmVuZGVyZXIyXG4gICAgaWYgKHNob3VsZEFkZCkge1xuICAgICAgdGhpcy5fcmVuZGVyZXIuYWRkQ2xhc3ModGhpcy5faW9uSXRlbUVsZW1lbnQsIGNzc0NsYXNzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fcmVuZGVyZXIucmVtb3ZlQ2xhc3ModGhpcy5faW9uSXRlbUVsZW1lbnQsIGNzc0NsYXNzKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIF90b2dnbGVBZGRJdGVtVGVtcGxhdGUoaXNWaXNpYmxlOiBib29sZWFuKSB7XG4gICAgLy8gSXQgc2hvdWxkIGJlIHBvc3NpYmxlIHRvIHNob3cvaGlkZSB0aGUgdGVtcGxhdGUgcmVnYXJkbGVzc1xuICAgIC8vIGNhbkFkZEl0ZW0gb3IgY2FuU2F2ZUl0ZW0gcGFyYW1ldGVycywgc28gd2UgY291bGQgaW1wbGVtZW50IHNvbWVcbiAgICAvLyBjdXN0b20gYmVoYXZpb3IuIEUuZy4gYWRkaW5nIGl0ZW0gd2hlbiBzZWFyY2ggZmFpbHMgdXNpbmcgb25TZWFyY2hGYWlsIGV2ZW50LlxuICAgIGlmICghdGhpcy5hZGRJdGVtVGVtcGxhdGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBUbyBtYWtlIFNhdmVJdGVtVGVtcGxhdGUgdmlzaWJsZSB3ZSBqdXN0IHBvc2l0aW9uIGl0IG92ZXIgbGlzdCB1c2luZyBDU1MuXG4gICAgLy8gV2UgZG9uJ3QgaGlkZSBsaXN0IHdpdGggKm5nSWYgb3IgW2hpZGRlbl0gdG8gcHJldmVudCBpdHMgc2Nyb2xsIHBvc2l0aW9uLlxuICAgIHRoaXMuX2lzQWRkSXRlbVRlbXBsYXRlVmlzaWJsZSA9IGlzVmlzaWJsZTtcbiAgICB0aGlzLl9pc0Zvb3RlclZpc2libGUgPSAhaXNWaXNpYmxlO1xuICB9XG5cbiAgLyogQ29udHJvbFZhbHVlQWNjZXNzb3IgKi9cbiAgd3JpdGVWYWx1ZSh2YWx1ZTogYW55KSB7XG4gICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICB9XG5cbiAgcmVnaXN0ZXJPbkNoYW5nZShtZXRob2Q6IGFueSk6IHZvaWQge1xuICAgIHRoaXMucHJvcGFnYXRlT25DaGFuZ2UgPSBtZXRob2Q7XG4gIH1cblxuICByZWdpc3Rlck9uVG91Y2hlZChtZXRob2Q6ICgpID0+IHZvaWQpIHtcbiAgICB0aGlzLnByb3BhZ2F0ZU9uVG91Y2hlZCA9IG1ldGhvZDtcbiAgfVxuXG4gIHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbikge1xuICAgIHRoaXMuaXNFbmFibGVkID0gIWlzRGlzYWJsZWQ7XG4gIH1cbiAgLyogLkNvbnRyb2xWYWx1ZUFjY2Vzc29yICovXG5cbiAgbmdPbkluaXQoKSB7XG4gICAgdGhpcy5faXNJb3MgPSB0aGlzLl9wbGF0Zm9ybS5pcygnaW9zJyk7XG4gICAgdGhpcy5faXNNRCA9ICF0aGlzLl9pc0lvcztcbiAgICB0aGlzLl9oYXNPYmplY3RzID0gIXRoaXMuX2lzTnVsbE9yV2hpdGVTcGFjZSh0aGlzLml0ZW1WYWx1ZUZpZWxkKTtcbiAgICAvLyBHcm91cGluZyBpcyBzdXBwb3J0ZWQgZm9yIG9iamVjdHMgb25seS5cbiAgICAvLyBJb25pYyBWaXJ0dWFsU2Nyb2xsIGhhcyBpdCdzIG93biBpbXBsZW1lbnRhdGlvbiBvZiBncm91cGluZy5cbiAgICB0aGlzLl9oYXNHcm91cHMgPSBCb29sZWFuKHRoaXMuX2hhc09iamVjdHMgJiYgdGhpcy5ncm91cFZhbHVlRmllbGQgJiYgIXRoaXMuaGFzVmlydHVhbFNjcm9sbCk7XG5cbiAgICBpZiAodGhpcy5pb25JdGVtKSB7XG4gICAgICB0aGlzLl9pb25JdGVtRWxlbWVudCA9IHRoaXMuX2VsZW1lbnQubmF0aXZlRWxlbWVudC5jbG9zZXN0KCdpb24taXRlbScpO1xuICAgICAgdGhpcy5fc2V0SW9uSXRlbUNzc0NsYXNzKCdpdGVtLWludGVyYWN0aXZlJywgdHJ1ZSk7XG4gICAgICB0aGlzLl9zZXRJb25JdGVtQ3NzQ2xhc3MoJ2l0ZW0taW9uaWMtc2VsZWN0YWJsZScsIHRydWUpO1xuXG4gICAgICBpZiAodGhpcy5faW9uSXRlbUVsZW1lbnQpIHtcbiAgICAgICAgdGhpcy5faW9uTGFiZWxFbGVtZW50ID0gdGhpcy5faW9uSXRlbUVsZW1lbnQucXVlcnlTZWxlY3RvcignaW9uLWxhYmVsJyk7XG5cbiAgICAgICAgaWYgKHRoaXMuX2lvbkxhYmVsRWxlbWVudCkge1xuICAgICAgICAgIHRoaXMuX2hhc0lvbkxhYmVsID0gdHJ1ZTtcbiAgICAgICAgICB0aGlzLl9pb25MYWJlbFBvc2l0aW9uID0gdGhpcy5faW9uTGFiZWxFbGVtZW50LmdldEF0dHJpYnV0ZSgncG9zaXRpb24nKSB8fCAnZGVmYXVsdCc7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLmVuYWJsZUlvbkl0ZW0odGhpcy5pc0VuYWJsZWQpO1xuICB9XG5cbiAgbmdEb0NoZWNrKCkge1xuICAgIGNvbnN0IGl0ZW1zQ2hhbmdlcyA9IHRoaXMuX2l0ZW1zRGlmZmVyLmRpZmYodGhpcy5pdGVtcyk7XG5cbiAgICBpZiAoaXRlbXNDaGFuZ2VzKSB7XG4gICAgICB0aGlzLl9zZXRJdGVtcyh0aGlzLml0ZW1zKTtcbiAgICAgIHRoaXMudmFsdWUgPSB0aGlzLnZhbHVlO1xuXG4gICAgICB0aGlzLm9uSXRlbXNDaGFuZ2UuZW1pdCh7XG4gICAgICAgIGNvbXBvbmVudDogdGhpc1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgaXRlbS5cbiAgICogKipOb3RlKio6IElmIHlvdSB3YW50IGFuIGl0ZW0gdG8gYmUgYWRkZWQgdG8gdGhlIG9yaWdpbmFsIGFycmF5IGFzIHdlbGwgdXNlIHR3by13YXkgZGF0YSBiaW5kaW5nIHN5bnRheCBvbiBgWyhpdGVtcyldYCBmaWVsZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jYWRkaXRlbSkuXG4gICAqXG4gICAqIEBwYXJhbSBpdGVtIEl0ZW0gdG8gYWRkLlxuICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2hlbiBpdGVtIGhhcyBiZWVuIGFkZGVkLlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBhZGRJdGVtKGl0ZW06IGFueSk6IFByb21pc2U8YW55PiB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICAvLyBBZGRpbmcgaXRlbSB0cmlnZ2VycyBvbkl0ZW1zQ2hhbmdlLlxuICAgIC8vIFJldHVybiBhIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aGVuIG9uSXRlbXNDaGFuZ2UgZmluaXNoZXMuXG4gICAgLy8gV2UgbmVlZCBhIHByb21pc2Ugb3IgdXNlciBjb3VsZCBkbyBzb21ldGhpbmcgYWZ0ZXIgaXRlbSBoYXMgYmVlbiBhZGRlZCxcbiAgICAvLyBlLmcuIHVzZSBzZWFyY2goKSBtZXRob2QgdG8gZmluZCB0aGUgYWRkZWQgaXRlbS5cbiAgICB0aGlzLml0ZW1zLnVuc2hpZnQoaXRlbSk7XG5cbiAgICAvLyBDbG9zZSBhbnkgcnVubmluZyBzdWJzY3JpcHRpb24uXG4gICAgaWYgKHRoaXMuX2FkZEl0ZW1PYnNlcnZhYmxlKSB7XG4gICAgICB0aGlzLl9hZGRJdGVtT2JzZXJ2YWJsZS51bnN1YnNjcmliZSgpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAvLyBDb21wbGV0ZSBjYWxsYmFjayBpc24ndCBmaXJlZCBmb3Igc29tZSByZWFzb24sXG4gICAgICAvLyBzbyB1bnN1YnNjcmliZSBpbiBib3RoIHN1Y2Nlc3MgYW5kIGZhaWwgY2FzZXMuXG4gICAgICBzZWxmLl9hZGRJdGVtT2JzZXJ2YWJsZSA9IHNlbGYub25JdGVtc0NoYW5nZS5hc09ic2VydmFibGUoKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICBzZWxmLl9hZGRJdGVtT2JzZXJ2YWJsZS51bnN1YnNjcmliZSgpO1xuICAgICAgICByZXNvbHZlKCk7XG4gICAgICB9LCAoKSA9PiB7XG4gICAgICAgIHNlbGYuX2FkZEl0ZW1PYnNlcnZhYmxlLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIHJlamVjdCgpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAqIERlbGV0ZXMgaXRlbS5cbiAqICoqTm90ZSoqOiBJZiB5b3Ugd2FudCBhbiBpdGVtIHRvIGJlIGRlbGV0ZWQgZnJvbSB0aGUgb3JpZ2luYWwgYXJyYXkgYXMgd2VsbCB1c2UgdHdvLXdheSBkYXRhIGJpbmRpbmcgc3ludGF4IG9uIGBbKGl0ZW1zKV1gIGZpZWxkLlxuICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jZGVsZXRlaXRlbSkuXG4gKlxuICogQHBhcmFtIGl0ZW0gSXRlbSB0byBkZWxldGUuXG4gKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2hlbiBpdGVtIGhhcyBiZWVuIGRlbGV0ZWQuXG4gKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gKi9cbiAgZGVsZXRlSXRlbShpdGVtOiBhbnkpOiBQcm9taXNlPGFueT4ge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGxldCBoYXNWYWx1ZUNoYW5nZWQgPSBmYWxzZTtcblxuICAgIC8vIFJlbW92ZSBkZWxldGVkIGl0ZW0gZnJvbSBzZWxlY3RlZCBpdGVtcy5cbiAgICBpZiAodGhpcy5fc2VsZWN0ZWRJdGVtcykge1xuICAgICAgdGhpcy5fc2VsZWN0ZWRJdGVtcyA9IHRoaXMuX3NlbGVjdGVkSXRlbXMuZmlsdGVyKF9pdGVtID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2dldEl0ZW1WYWx1ZShpdGVtKSAhPT0gdGhpcy5fZ2V0U3RvcmVkSXRlbVZhbHVlKF9pdGVtKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIFJlbW92ZSBkZWxldGVkIGl0ZW0gZnJvbSB2YWx1ZS5cbiAgICBpZiAodGhpcy52YWx1ZSkge1xuICAgICAgaWYgKHRoaXMuaXNNdWx0aXBsZSkge1xuICAgICAgICBjb25zdCB2YWx1ZXMgPSB0aGlzLnZhbHVlLmZpbHRlcih2YWx1ZSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHZhbHVlLmlkICE9PSBpdGVtLmlkO1xuICAgICAgICB9KTtcblxuICAgICAgICBpZiAodmFsdWVzLmxlbmd0aCAhPT0gdGhpcy52YWx1ZS5sZW5ndGgpIHtcbiAgICAgICAgICB0aGlzLnZhbHVlID0gdmFsdWVzO1xuICAgICAgICAgIGhhc1ZhbHVlQ2hhbmdlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChpdGVtID09PSB0aGlzLnZhbHVlKSB7XG4gICAgICAgICAgdGhpcy52YWx1ZSA9IG51bGw7XG4gICAgICAgICAgaGFzVmFsdWVDaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChoYXNWYWx1ZUNoYW5nZWQpIHtcbiAgICAgIHRoaXMuX2VtaXRWYWx1ZUNoYW5nZSgpO1xuICAgIH1cblxuICAgIC8vIFJlbW92ZSBkZWxldGVkIGl0ZW0gZnJvbSBsaXN0LlxuICAgIGNvbnN0IGl0ZW1zID0gdGhpcy5pdGVtcy5maWx0ZXIoX2l0ZW0gPT4ge1xuICAgICAgcmV0dXJuIF9pdGVtLmlkICE9PSBpdGVtLmlkO1xuICAgIH0pO1xuXG4gICAgLy8gUmVmcmVzaCBpdGVtcyBvbiBwYXJlbnQgY29tcG9uZW50LlxuICAgIHRoaXMuaXRlbXNDaGFuZ2UuZW1pdChpdGVtcyk7XG5cbiAgICAvLyBSZWZyZXNoIGxpc3QuXG4gICAgdGhpcy5fc2V0SXRlbXMoaXRlbXMpO1xuXG4gICAgdGhpcy5vbkl0ZW1zQ2hhbmdlLmVtaXQoe1xuICAgICAgY29tcG9uZW50OiB0aGlzXG4gICAgfSk7XG5cbiAgICAvLyBDbG9zZSBhbnkgcnVubmluZyBzdWJzY3JpcHRpb24uXG4gICAgaWYgKHRoaXMuX2RlbGV0ZUl0ZW1PYnNlcnZhYmxlKSB7XG4gICAgICB0aGlzLl9kZWxldGVJdGVtT2JzZXJ2YWJsZS51bnN1YnNjcmliZSgpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAvLyBDb21wbGV0ZSBjYWxsYmFjayBpc24ndCBmaXJlZCBmb3Igc29tZSByZWFzb24sXG4gICAgICAvLyBzbyB1bnN1YnNjcmliZSBpbiBib3RoIHN1Y2Nlc3MgYW5kIGZhaWwgY2FzZXMuXG4gICAgICBzZWxmLl9kZWxldGVJdGVtT2JzZXJ2YWJsZSA9IHNlbGYub25JdGVtc0NoYW5nZS5hc09ic2VydmFibGUoKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICBzZWxmLl9kZWxldGVJdGVtT2JzZXJ2YWJsZS51bnN1YnNjcmliZSgpO1xuICAgICAgICByZXNvbHZlKCk7XG4gICAgICB9LCAoKSA9PiB7XG4gICAgICAgIHNlbGYuX2RlbGV0ZUl0ZW1PYnNlcnZhYmxlLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIHJlamVjdCgpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogRGV0ZXJtaW5lcyB3aGV0aGVyIGFueSBpdGVtIGhhcyBiZWVuIHNlbGVjdGVkLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNoYXN2YWx1ZSkuXG4gICAqXG4gICAqIEByZXR1cm5zIEEgYm9vbGVhbiBkZXRlcm1pbmluZyB3aGV0aGVyIGFueSBpdGVtIGhhcyBiZWVuIHNlbGVjdGVkLlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBoYXNWYWx1ZSgpOiBib29sZWFuIHtcbiAgICBpZiAodGhpcy5pc011bHRpcGxlKSB7XG4gICAgICByZXR1cm4gdGhpcy5fdmFsdWVJdGVtcy5sZW5ndGggIT09IDA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0aGlzLl92YWx1ZUl0ZW1zLmxlbmd0aCAhPT0gMCAmJiAhdGhpcy5faXNOdWxsT3JXaGl0ZVNwYWNlKHRoaXMuX3ZhbHVlSXRlbXNbMF0pO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyBNb2RhbC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jb3BlbikuXG4gICAqXG4gICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aGVuIE1vZGFsIGhhcyBiZWVuIG9wZW5lZC5cbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgb3BlbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcblxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICBpZiAoIXNlbGYuX2lzRW5hYmxlZCB8fCBzZWxmLl9pc09wZW5lZCkge1xuICAgICAgICByZWplY3QoJ0lvbmljU2VsZWN0YWJsZSBpcyBkaXNhYmxlZCBvciBhbHJlYWR5IG9wZW5lZC4nKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBzZWxmLl9maWx0ZXJJdGVtcygpO1xuICAgICAgc2VsZi5faXNPcGVuZWQgPSB0cnVlO1xuXG4gICAgICBjb25zdCBtb2RhbE9wdGlvbnM6IE1vZGFsT3B0aW9ucyA9IHtcbiAgICAgICAgY29tcG9uZW50OiBJb25pY1NlbGVjdGFibGVNb2RhbENvbXBvbmVudCxcbiAgICAgICAgY29tcG9uZW50UHJvcHM6IHsgc2VsZWN0Q29tcG9uZW50OiBzZWxmIH0sXG4gICAgICAgIGJhY2tkcm9wRGlzbWlzczogc2VsZi5fc2hvdWxkQmFja2Ryb3BDbG9zZVxuICAgICAgfTtcblxuICAgICAgaWYgKHNlbGYubW9kYWxDc3NDbGFzcykge1xuICAgICAgICBtb2RhbE9wdGlvbnMuY3NzQ2xhc3MgPSBzZWxmLm1vZGFsQ3NzQ2xhc3M7XG4gICAgICB9XG5cbiAgICAgIGlmIChzZWxmLm1vZGFsRW50ZXJBbmltYXRpb24pIHtcbiAgICAgICAgbW9kYWxPcHRpb25zLmVudGVyQW5pbWF0aW9uID0gc2VsZi5tb2RhbEVudGVyQW5pbWF0aW9uO1xuICAgICAgfVxuXG4gICAgICBpZiAoc2VsZi5tb2RhbExlYXZlQW5pbWF0aW9uKSB7XG4gICAgICAgIG1vZGFsT3B0aW9ucy5sZWF2ZUFuaW1hdGlvbiA9IHNlbGYubW9kYWxMZWF2ZUFuaW1hdGlvbjtcbiAgICAgIH1cblxuICAgICAgc2VsZi5fbW9kYWxDb250cm9sbGVyLmNyZWF0ZShtb2RhbE9wdGlvbnMpLnRoZW4obW9kYWwgPT4ge1xuICAgICAgICBzZWxmLl9tb2RhbCA9IG1vZGFsO1xuICAgICAgICBtb2RhbC5wcmVzZW50KCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgLy8gU2V0IGZvY3VzIGFmdGVyIE1vZGFsIGhhcyBvcGVuZWQgdG8gYXZvaWQgZmxpY2tlcmluZyBvZiBmb2N1cyBoaWdobGlnaHRpbmdcbiAgICAgICAgICAvLyBiZWZvcmUgTW9kYWwgb3BlbmluZy5cbiAgICAgICAgICBzZWxmLl9zZXRJb25JdGVtSGFzRm9jdXModHJ1ZSk7XG4gICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICB9KTtcblxuICAgICAgICBtb2RhbC5vbldpbGxEaXNtaXNzKCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgc2VsZi5fc2V0SW9uSXRlbUhhc0ZvY3VzKGZhbHNlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgbW9kYWwub25EaWREaXNtaXNzKCkudGhlbihldmVudCA9PiB7XG4gICAgICAgICAgc2VsZi5faXNPcGVuZWQgPSBmYWxzZTtcbiAgICAgICAgICBzZWxmLl9pdGVtc1RvQ29uZmlybSA9IFtdO1xuXG4gICAgICAgICAgLy8gQ2xvc2VkIGJ5IGNsaWNraW5nIG9uIGJhY2tkcm9wIG91dHNpZGUgbW9kYWwuXG4gICAgICAgICAgaWYgKGV2ZW50LnJvbGUgPT09ICdiYWNrZHJvcCcpIHtcbiAgICAgICAgICAgIHNlbGYub25DbG9zZS5lbWl0KHtcbiAgICAgICAgICAgICAgY29tcG9uZW50OiBzZWxmXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2VzIE1vZGFsLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNjbG9zZSkuXG4gICAqXG4gICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aGVuIE1vZGFsIGhhcyBiZWVuIGNsb3NlZC5cbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgY2xvc2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgaWYgKCFzZWxmLl9pc0VuYWJsZWQgfHwgIXNlbGYuX2lzT3BlbmVkKSB7XG4gICAgICAgIHJlamVjdCgnSW9uaWNTZWxlY3RhYmxlIGlzIGRpc2FibGVkIG9yIGFscmVhZHkgY2xvc2VkLicpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIHNlbGYucHJvcGFnYXRlT25Ub3VjaGVkKCk7XG4gICAgICBzZWxmLl9pc09wZW5lZCA9IGZhbHNlO1xuICAgICAgc2VsZi5faXRlbVRvQWRkID0gbnVsbDtcbiAgICAgIHNlbGYuX21vZGFsLmRpc21pc3MoKS50aGVuKCgpID0+IHtcbiAgICAgICAgc2VsZi5fc2V0SW9uSXRlbUhhc0ZvY3VzKGZhbHNlKTtcbiAgICAgICAgc2VsZi5oaWRlQWRkSXRlbVRlbXBsYXRlKCk7XG4gICAgICAgIHJlc29sdmUoKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENsZWFycyB2YWx1ZS5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jY2xlYXIpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBjbGVhcigpIHtcbiAgICB0aGlzLnZhbHVlID0gdGhpcy5pc011bHRpcGxlID8gW10gOiBudWxsO1xuICAgIHRoaXMuX2l0ZW1zVG9Db25maXJtID0gW107XG4gICAgdGhpcy5wcm9wYWdhdGVPbkNoYW5nZSh0aGlzLnZhbHVlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb25maXJtcyBzZWxlY3RlZCBpdGVtcyBieSB1cGRhdGluZyB2YWx1ZS5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jY29uZmlybSkuXG4gICAqXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIGNvbmZpcm0oKSB7XG4gICAgaWYgKHRoaXMuaXNNdWx0aXBsZSkge1xuICAgICAgdGhpcy5fZG9TZWxlY3QodGhpcy5fc2VsZWN0ZWRJdGVtcyk7XG4gICAgfSBlbHNlIGlmICh0aGlzLmhhc0NvbmZpcm1CdXR0b24gfHwgdGhpcy5mb290ZXJUZW1wbGF0ZSkge1xuICAgICAgdGhpcy5fZG9TZWxlY3QodGhpcy5fc2VsZWN0ZWRJdGVtc1swXSB8fCBudWxsKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU2VsZWN0cyBvciBkZXNlbGVjdHMgYWxsIG9yIHNwZWNpZmljIGl0ZW1zLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiN0b2dnbGVpdGVtcykuXG4gICAqXG4gICAqIEBwYXJhbSBpc1NlbGVjdCBEZXRlcm1pbmVzIHdoZXRoZXIgdG8gc2VsZWN0IG9yIGRlc2VsZWN0IGl0ZW1zLlxuICAgKiBAcGFyYW0gW2l0ZW1zXSBJdGVtcyB0byB0b2dnbGUuIElmIGl0ZW1zIGFyZSBub3Qgc2V0IGFsbCBpdGVtcyB3aWxsIGJlIHRvZ2dsZWQuXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIHRvZ2dsZUl0ZW1zKGlzU2VsZWN0OiBib29sZWFuLCBpdGVtcz86IGFueVtdKSB7XG4gICAgaWYgKGlzU2VsZWN0KSB7XG4gICAgICBjb25zdCBoYXNJdGVtcyA9IGl0ZW1zICYmIGl0ZW1zLmxlbmd0aDtcbiAgICAgIGxldCBpdGVtc1RvVG9nZ2xlID0gdGhpcy5fZ3JvdXBzLnJlZHVjZSgoYWxsSXRlbXMsIGdyb3VwKSA9PiB7XG4gICAgICAgIHJldHVybiBhbGxJdGVtcy5jb25jYXQoZ3JvdXAuaXRlbXMpO1xuICAgICAgfSwgW10pO1xuXG4gICAgICAvLyBEb24ndCBhbGxvdyB0byBzZWxlY3QgYWxsIGl0ZW1zIGluIHNpbmdsZSBtb2RlLlxuICAgICAgaWYgKCF0aGlzLmlzTXVsdGlwbGUgJiYgIWhhc0l0ZW1zKSB7XG4gICAgICAgIGl0ZW1zVG9Ub2dnbGUgPSBbXTtcbiAgICAgIH1cblxuICAgICAgLy8gVG9nZ2xlIHNwZWNpZmljIGl0ZW1zLlxuICAgICAgaWYgKGhhc0l0ZW1zKSB7XG4gICAgICAgIGl0ZW1zVG9Ub2dnbGUgPSBpdGVtc1RvVG9nZ2xlLmZpbHRlcihpdGVtVG9Ub2dnbGUgPT4ge1xuICAgICAgICAgIHJldHVybiBpdGVtcy5maW5kKGl0ZW0gPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldEl0ZW1WYWx1ZShpdGVtVG9Ub2dnbGUpID09PSB0aGlzLl9nZXRJdGVtVmFsdWUoaXRlbSk7XG4gICAgICAgICAgfSkgIT09IHVuZGVmaW5lZDtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gVGFrZSB0aGUgZmlyc3QgaXRlbSBmb3Igc2luZ2xlIG1vZGUuXG4gICAgICAgIGlmICghdGhpcy5pc011bHRpcGxlKSB7XG4gICAgICAgICAgaXRlbXNUb1RvZ2dsZS5zcGxpY2UoMCwgMSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaXRlbXNUb1RvZ2dsZS5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgICB0aGlzLl9hZGRTZWxlY3RlZEl0ZW0oaXRlbSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fc2VsZWN0ZWRJdGVtcyA9IFtdO1xuICAgIH1cblxuICAgIHRoaXMuX3NldEl0ZW1zVG9Db25maXJtKHRoaXMuX3NlbGVjdGVkSXRlbXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNjcm9sbHMgdG8gdGhlIHRvcCBvZiBNb2RhbCBjb250ZW50LlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNzY3JvbGx0b3RvcCkuXG4gICAqXG4gICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aGVuIHNjcm9sbCBoYXMgYmVlbiBjb21wbGV0ZWQuXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIHNjcm9sbFRvVG9wKCk6IFByb21pc2U8YW55PiB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgaWYgKCFzZWxmLl9pc09wZW5lZCkge1xuICAgICAgICByZWplY3QoJ0lvbmljU2VsZWN0YWJsZSBjb250ZW50IGNhbm5vdCBiZSBzY3JvbGxlZC4nKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBzZWxmLl9tb2RhbENvbXBvbmVudC5fY29udGVudC5zY3JvbGxUb1RvcCgpLnRoZW4oKCkgPT4ge1xuICAgICAgICByZXNvbHZlKCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTY3JvbGxzIHRvIHRoZSBib3R0b20gb2YgTW9kYWwgY29udGVudC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jc2Nyb2xsdG9ib3R0b20pLlxuICAgKlxuICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2hlbiBzY3JvbGwgaGFzIGJlZW4gY29tcGxldGVkLlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBzY3JvbGxUb0JvdHRvbSgpOiBQcm9taXNlPGFueT4ge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIGlmICghc2VsZi5faXNPcGVuZWQpIHtcbiAgICAgICAgcmVqZWN0KCdJb25pY1NlbGVjdGFibGUgY29udGVudCBjYW5ub3QgYmUgc2Nyb2xsZWQuJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgc2VsZi5fbW9kYWxDb21wb25lbnQuX2NvbnRlbnQuc2Nyb2xsVG9Cb3R0b20oKS50aGVuKCgpID0+IHtcbiAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogU3RhcnRzIHNlYXJjaCBwcm9jZXNzIGJ5IHNob3dpbmcgTG9hZGluZyBzcGlubmVyLlxuICAgKiBVc2UgaXQgdG9nZXRoZXIgd2l0aCBgb25TZWFyY2hgIGV2ZW50IHRvIGluZGljYXRlIHNlYXJjaCBzdGFydC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jc3RhcnRzZWFyY2gpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBzdGFydFNlYXJjaCgpIHtcbiAgICBpZiAoIXRoaXMuX2lzRW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMuc2hvd0xvYWRpbmcoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFbmRzIHNlYXJjaCBwcm9jZXNzIGJ5IGhpZGluZyBMb2FkaW5nIHNwaW5uZXIgYW5kIHJlZnJlc2hpbmcgaXRlbXMuXG4gICAqIFVzZSBpdCB0b2dldGhlciB3aXRoIGBvblNlYXJjaGAgZXZlbnQgdG8gaW5kaWNhdGUgc2VhcmNoIGVuZC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jZW5kc2VhcmNoKS5cbiAgICpcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgZW5kU2VhcmNoKCkge1xuICAgIGlmICghdGhpcy5faXNFbmFibGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5oaWRlTG9hZGluZygpO1xuXG4gICAgLy8gV2hlbiBpbnNpZGUgSW9uaWMgTW9kYWwgYW5kIG9uU2VhcmNoIGV2ZW50IGlzIHVzZWQsXG4gICAgLy8gbmdEb0NoZWNrKCkgZG9lc24ndCB3b3JrIGFzIF9pdGVtc0RpZmZlciBmYWlscyB0byBkZXRlY3QgY2hhbmdlcy5cbiAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS9pc3N1ZXMvNDQuXG4gICAgLy8gUmVmcmVzaCBpdGVtcyBtYW51YWxseS5cbiAgICB0aGlzLl9zZXRJdGVtcyh0aGlzLml0ZW1zKTtcbiAgICB0aGlzLl9lbWl0T25TZWFyY2hTdWNjZXNzT3JGYWlsKHRoaXMuX2hhc0ZpbHRlcmVkSXRlbXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEVuYWJsZXMgaW5maW5pdGUgc2Nyb2xsLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNlbmFibGVpbmZpbml0ZXNjcm9sbCkuXG4gICAqXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIGVuYWJsZUluZmluaXRlU2Nyb2xsKCkge1xuICAgIGlmICghdGhpcy5faGFzSW5maW5pdGVTY3JvbGwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLl9tb2RhbENvbXBvbmVudC5faW5maW5pdGVTY3JvbGwuZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEaXNhYmxlcyBpbmZpbml0ZSBzY3JvbGwuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2Rpc2FibGVpbmZpbml0ZXNjcm9sbCkuXG4gICAqXG4gICAqIEBtZW1iZXJvZiBJb25pY1NlbGVjdGFibGVDb21wb25lbnRcbiAgICovXG4gIGRpc2FibGVJbmZpbml0ZVNjcm9sbCgpIHtcbiAgICBpZiAoIXRoaXMuX2hhc0luZmluaXRlU2Nyb2xsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5fbW9kYWxDb21wb25lbnQuX2luZmluaXRlU2Nyb2xsLmRpc2FibGVkID0gdHJ1ZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFbmRzIGluZmluaXRlIHNjcm9sbC5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jZW5kaW5maW5pdGVzY3JvbGwpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBlbmRJbmZpbml0ZVNjcm9sbCgpIHtcbiAgICBpZiAoIXRoaXMuX2hhc0luZmluaXRlU2Nyb2xsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5fbW9kYWxDb21wb25lbnQuX2luZmluaXRlU2Nyb2xsLmNvbXBsZXRlKCk7XG4gICAgdGhpcy5fc2V0SXRlbXModGhpcy5pdGVtcyk7XG4gIH1cblxuICAvKipcbiAgICogVHJpZ2dlcnMgc2VhcmNoIG9mIGl0ZW1zLlxuICAgKiAqKk5vdGUqKjogYGNhblNlYXJjaGAgaGFzIHRvIGJlIGVuYWJsZWQuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI3NlYXJjaCkuXG4gICAqXG4gICAqIEBwYXJhbSB0ZXh0IFRleHQgdG8gc2VhcmNoIGl0ZW1zIGJ5LlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBzZWFyY2godGV4dDogc3RyaW5nKSB7XG4gICAgaWYgKCF0aGlzLl9pc0VuYWJsZWQgfHwgIXRoaXMuX2lzT3BlbmVkIHx8ICF0aGlzLmNhblNlYXJjaCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMuX3NlYXJjaFRleHQgPSB0ZXh0O1xuICAgIHRoaXMuX3NldEhhc1NlYXJjaFRleHQoKTtcbiAgICB0aGlzLl9maWx0ZXJJdGVtcygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNob3dzIExvYWRpbmcgc3Bpbm5lci5cbiAgICogU2VlIG1vcmUgb24gW0dpdEh1Yl0oaHR0cHM6Ly9naXRodWIuY29tL2Vha29yaWFraW4vaW9uaWMtc2VsZWN0YWJsZS93aWtpL0RvY3VtZW50YXRpb24jc2hvd2xvYWRpbmcpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBzaG93TG9hZGluZygpIHtcbiAgICBpZiAoIXRoaXMuX2lzRW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMuX2lzU2VhcmNoaW5nID0gdHJ1ZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBIaWRlcyBMb2FkaW5nIHNwaW5uZXIuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2hpZGVsb2FkaW5nKS5cbiAgICpcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgaGlkZUxvYWRpbmcoKSB7XG4gICAgaWYgKCF0aGlzLl9pc0VuYWJsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLl9pc1NlYXJjaGluZyA9IGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFNob3dzIGBpb25pY1NlbGVjdGFibGVBZGRJdGVtVGVtcGxhdGVgLlxuICAgKiBTZWUgbW9yZSBvbiBbR2l0SHViXShodHRwczovL2dpdGh1Yi5jb20vZWFrb3JpYWtpbi9pb25pYy1zZWxlY3RhYmxlL3dpa2kvRG9jdW1lbnRhdGlvbiNzaG93YWRkaXRlbXRlbXBsYXRlKS5cbiAgICpcbiAgICogQG1lbWJlcm9mIElvbmljU2VsZWN0YWJsZUNvbXBvbmVudFxuICAgKi9cbiAgc2hvd0FkZEl0ZW1UZW1wbGF0ZSgpIHtcbiAgICB0aGlzLl90b2dnbGVBZGRJdGVtVGVtcGxhdGUodHJ1ZSk7XG5cbiAgICAvLyBQb3NpdGlvbiB0aGUgdGVtcGxhdGUgb25seSB3aGVuIGl0IHNob3VzIHVwLlxuICAgIHRoaXMuX3Bvc2l0aW9uQWRkSXRlbVRlbXBsYXRlKCk7XG4gIH1cblxuICAvKipcbiAgICogSGlkZXMgYGlvbmljU2VsZWN0YWJsZUFkZEl0ZW1UZW1wbGF0ZWAuXG4gICAqIFNlZSBtb3JlIG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9lYWtvcmlha2luL2lvbmljLXNlbGVjdGFibGUvd2lraS9Eb2N1bWVudGF0aW9uI2hpZGVhZGRpdGVtdGVtcGxhdGUpLlxuICAgKlxuICAgKiBAbWVtYmVyb2YgSW9uaWNTZWxlY3RhYmxlQ29tcG9uZW50XG4gICAqL1xuICBoaWRlQWRkSXRlbVRlbXBsYXRlKCkge1xuICAgIC8vIENsZWFuIGl0ZW0gdG8gYWRkIGFzIGl0J3Mgbm8gbG9uZ2VyIG5lZWRlZCBvbmNlIEFkZCBJdGVtIE1vZGFsIGhhcyBiZWVuIGNsb3NlZC5cbiAgICB0aGlzLl9pdGVtVG9BZGQgPSBudWxsO1xuICAgIHRoaXMuX3RvZ2dsZUFkZEl0ZW1UZW1wbGF0ZShmYWxzZSk7XG4gIH1cbn1cbiJdfQ==

/***/ }),

/***/ "R7F3":
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-item-end-template.directive.js ***!
  \************************************************************************************************************************************************/
/*! exports provided: IonicSelectableItemEndTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemEndTemplateDirective", function() { return IonicSelectableItemEndTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableItemEndTemplateDirective {
}
IonicSelectableItemEndTemplateDirective.ɵfac = function IonicSelectableItemEndTemplateDirective_Factory(t) { return new (t || IonicSelectableItemEndTemplateDirective)(); };
IonicSelectableItemEndTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableItemEndTemplateDirective, selectors: [["", "ionicSelectableItemEndTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableItemEndTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableItemEndTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1pdGVtLWVuZC10ZW1wbGF0ZS5kaXJlY3RpdmUuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUtaXRlbS1lbmQtdGVtcGxhdGUuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzFDLE1BQU0sT0FBTyx1Q0FBdUM7QUFBRzttRUFIdEQsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSxrQ0FBa0MsZUFDN0M7Ozs7Ozs7MEJBQ0k7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaW9uaWNTZWxlY3RhYmxlSXRlbUVuZFRlbXBsYXRlXScsXG59KVxuZXhwb3J0IGNsYXNzIElvbmljU2VsZWN0YWJsZUl0ZW1FbmRUZW1wbGF0ZURpcmVjdGl2ZSB7IH1cbiJdfQ==

/***/ }),

/***/ "TnqW":
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-add-item-template.directive.js ***!
  \************************************************************************************************************************************************/
/*! exports provided: IonicSelectableAddItemTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableAddItemTemplateDirective", function() { return IonicSelectableAddItemTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableAddItemTemplateDirective {
}
IonicSelectableAddItemTemplateDirective.ɵfac = function IonicSelectableAddItemTemplateDirective_Factory(t) { return new (t || IonicSelectableAddItemTemplateDirective)(); };
IonicSelectableAddItemTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableAddItemTemplateDirective, selectors: [["", "ionicSelectableAddItemTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableAddItemTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableAddItemTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1hZGQtaXRlbS10ZW1wbGF0ZS5kaXJlY3RpdmUuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUtYWRkLWl0ZW0tdGVtcGxhdGUuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzFDLE1BQU0sT0FBTyx1Q0FBdUM7QUFBRzttRUFIdEQsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSxrQ0FBa0MsZUFDN0M7Ozs7Ozs7MEJBQ0k7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaW9uaWNTZWxlY3RhYmxlQWRkSXRlbVRlbXBsYXRlXScsXG59KVxuZXhwb3J0IGNsYXNzIElvbmljU2VsZWN0YWJsZUFkZEl0ZW1UZW1wbGF0ZURpcmVjdGl2ZSB7IH1cbiJdfQ==

/***/ }),

/***/ "UY7p":
/*!********************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-icon-template.directive.js ***!
  \********************************************************************************************************************************************/
/*! exports provided: IonicSelectableIconTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableIconTemplateDirective", function() { return IonicSelectableIconTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableIconTemplateDirective {
}
IonicSelectableIconTemplateDirective.ɵfac = function IonicSelectableIconTemplateDirective_Factory(t) { return new (t || IonicSelectableIconTemplateDirective)(); };
IonicSelectableIconTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableIconTemplateDirective, selectors: [["", "ionicSelectableIconTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableIconTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableIconTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1pY29uLXRlbXBsYXRlLmRpcmVjdGl2ZS5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9jb21wb25lbnRzL2lvbmljLXNlbGVjdGFibGUvaW9uaWMtc2VsZWN0YWJsZS1pY29uLXRlbXBsYXRlLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQUsxQyxNQUFNLE9BQU8sb0NBQW9DO0FBQUc7Z0VBSG5ELFNBQVMsU0FBQyxrQkFDVCxRQUFRLEVBQUUsK0JBQStCLGNBQzFDOzs7Ozs7OzBCQUNJO0FBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW2lvbmljU2VsZWN0YWJsZUljb25UZW1wbGF0ZV0nXG59KVxuZXhwb3J0IGNsYXNzIElvbmljU2VsZWN0YWJsZUljb25UZW1wbGF0ZURpcmVjdGl2ZSB7IH1cbiJdfQ==

/***/ }),

/***/ "VqCF":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-group-end-template.directive.js ***!
  \*************************************************************************************************************************************************/
/*! exports provided: IonicSelectableGroupEndTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableGroupEndTemplateDirective", function() { return IonicSelectableGroupEndTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableGroupEndTemplateDirective {
}
IonicSelectableGroupEndTemplateDirective.ɵfac = function IonicSelectableGroupEndTemplateDirective_Factory(t) { return new (t || IonicSelectableGroupEndTemplateDirective)(); };
IonicSelectableGroupEndTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableGroupEndTemplateDirective, selectors: [["", "ionicSelectableGroupEndTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableGroupEndTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableGroupEndTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1ncm91cC1lbmQtdGVtcGxhdGUuZGlyZWN0aXZlLmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL2NvbXBvbmVudHMvaW9uaWMtc2VsZWN0YWJsZS9pb25pYy1zZWxlY3RhYmxlLWdyb3VwLWVuZC10ZW1wbGF0ZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLMUMsTUFBTSxPQUFPLHdDQUF3QztBQUFHO29FQUh2RCxTQUFTLFNBQUMsa0JBQ1QsUUFBUSxFQUFFLG1DQUFtQyxlQUM5Qzs7Ozs7OzswQkFDSTtBQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tpb25pY1NlbGVjdGFibGVHcm91cEVuZFRlbXBsYXRlXScsXG59KVxuZXhwb3J0IGNsYXNzIElvbmljU2VsZWN0YWJsZUdyb3VwRW5kVGVtcGxhdGVEaXJlY3RpdmUgeyB9XG4iXX0=

/***/ }),

/***/ "Ys55":
/*!**********************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-footer-template.directive.js ***!
  \**********************************************************************************************************************************************/
/*! exports provided: IonicSelectableFooterTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableFooterTemplateDirective", function() { return IonicSelectableFooterTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableFooterTemplateDirective {
}
IonicSelectableFooterTemplateDirective.ɵfac = function IonicSelectableFooterTemplateDirective_Factory(t) { return new (t || IonicSelectableFooterTemplateDirective)(); };
IonicSelectableFooterTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableFooterTemplateDirective, selectors: [["", "ionicSelectableFooterTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableFooterTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableFooterTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1mb290ZXItdGVtcGxhdGUuZGlyZWN0aXZlLmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL2NvbXBvbmVudHMvaW9uaWMtc2VsZWN0YWJsZS9pb25pYy1zZWxlY3RhYmxlLWZvb3Rlci10ZW1wbGF0ZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLMUMsTUFBTSxPQUFPLHNDQUFzQztBQUFHO2tFQUhyRCxTQUFTLFNBQUMsa0JBQ1QsUUFBUSxFQUFFLGlDQUFpQyxlQUM1Qzs7Ozs7OzswQkFDSTtBQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tpb25pY1NlbGVjdGFibGVGb290ZXJUZW1wbGF0ZV0nLFxufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVGb290ZXJUZW1wbGF0ZURpcmVjdGl2ZSB7IH1cbiJdfQ==

/***/ }),

/***/ "dP2w":
/*!***************************************************!*\
  !*** ./src/app/patient/patient-routing.module.ts ***!
  \***************************************************/
/*! exports provided: PatientPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientPageRoutingModule", function() { return PatientPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _patient_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./patient.page */ "gpqs");




const routes = [
    {
        path: '',
        component: _patient_page__WEBPACK_IMPORTED_MODULE_3__["PatientPage"]
    }
];
let PatientPageRoutingModule = class PatientPageRoutingModule {
};
PatientPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PatientPageRoutingModule);



/***/ }),

/***/ "j+ev":
/*!********************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-item-template.directive.js ***!
  \********************************************************************************************************************************************/
/*! exports provided: IonicSelectableItemTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableItemTemplateDirective", function() { return IonicSelectableItemTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableItemTemplateDirective {
}
IonicSelectableItemTemplateDirective.ɵfac = function IonicSelectableItemTemplateDirective_Factory(t) { return new (t || IonicSelectableItemTemplateDirective)(); };
IonicSelectableItemTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableItemTemplateDirective, selectors: [["", "ionicSelectableItemTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableItemTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableItemTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1pdGVtLXRlbXBsYXRlLmRpcmVjdGl2ZS5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9jb21wb25lbnRzL2lvbmljLXNlbGVjdGFibGUvaW9uaWMtc2VsZWN0YWJsZS1pdGVtLXRlbXBsYXRlLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQUsxQyxNQUFNLE9BQU8sb0NBQW9DO0FBQUc7Z0VBSG5ELFNBQVMsU0FBQyxrQkFDVCxRQUFRLEVBQUUsK0JBQStCLGNBQzFDOzs7Ozs7OzBCQUNJO0FBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW2lvbmljU2VsZWN0YWJsZUl0ZW1UZW1wbGF0ZV0nXG59KVxuZXhwb3J0IGNsYXNzIElvbmljU2VsZWN0YWJsZUl0ZW1UZW1wbGF0ZURpcmVjdGl2ZSB7IH1cbiJdfQ==

/***/ }),

/***/ "kNd2":
/*!***************************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-placeholder-template.directive.js ***!
  \***************************************************************************************************************************************************/
/*! exports provided: IonicSelectablePlaceholderTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectablePlaceholderTemplateDirective", function() { return IonicSelectablePlaceholderTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectablePlaceholderTemplateDirective {
}
IonicSelectablePlaceholderTemplateDirective.ɵfac = function IonicSelectablePlaceholderTemplateDirective_Factory(t) { return new (t || IonicSelectablePlaceholderTemplateDirective)(); };
IonicSelectablePlaceholderTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectablePlaceholderTemplateDirective, selectors: [["", "ionicSelectablePlaceholderTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectablePlaceholderTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectablePlaceholderTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1wbGFjZWhvbGRlci10ZW1wbGF0ZS5kaXJlY3RpdmUuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUtcGxhY2Vob2xkZXItdGVtcGxhdGUuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzFDLE1BQU0sT0FBTywyQ0FBMkM7QUFBRzt1RUFIMUQsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSxzQ0FBc0MsZUFDakQ7Ozs7Ozs7MEJBQ0k7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaW9uaWNTZWxlY3RhYmxlUGxhY2Vob2xkZXJUZW1wbGF0ZV0nLFxufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVQbGFjZWhvbGRlclRlbXBsYXRlRGlyZWN0aXZlIHsgfVxuIl19

/***/ }),

/***/ "qPfB":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-value-template.directive.js ***!
  \*********************************************************************************************************************************************/
/*! exports provided: IonicSelectableValueTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableValueTemplateDirective", function() { return IonicSelectableValueTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableValueTemplateDirective {
}
IonicSelectableValueTemplateDirective.ɵfac = function IonicSelectableValueTemplateDirective_Factory(t) { return new (t || IonicSelectableValueTemplateDirective)(); };
IonicSelectableValueTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableValueTemplateDirective, selectors: [["", "ionicSelectableValueTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableValueTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableValueTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS12YWx1ZS10ZW1wbGF0ZS5kaXJlY3RpdmUuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvY29tcG9uZW50cy9pb25pYy1zZWxlY3RhYmxlL2lvbmljLXNlbGVjdGFibGUtdmFsdWUtdGVtcGxhdGUuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzFDLE1BQU0sT0FBTyxxQ0FBcUM7QUFBRztpRUFIcEQsU0FBUyxTQUFDLGtCQUNULFFBQVEsRUFBRSxnQ0FBZ0MsZUFDM0M7Ozs7Ozs7MEJBQ0k7QUFBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaW9uaWNTZWxlY3RhYmxlVmFsdWVUZW1wbGF0ZV0nLFxufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVWYWx1ZVRlbXBsYXRlRGlyZWN0aXZlIHsgfVxuIl19

/***/ }),

/***/ "t6yK":
/*!***********************************************************************************************************************************************!*\
  !*** ./node_modules/ionic-selectable/__ivy_ngcc__/esm2015/src/app/components/ionic-selectable/ionic-selectable-message-template.directive.js ***!
  \***********************************************************************************************************************************************/
/*! exports provided: IonicSelectableMessageTemplateDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicSelectableMessageTemplateDirective", function() { return IonicSelectableMessageTemplateDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class IonicSelectableMessageTemplateDirective {
}
IonicSelectableMessageTemplateDirective.ɵfac = function IonicSelectableMessageTemplateDirective_Factory(t) { return new (t || IonicSelectableMessageTemplateDirective)(); };
IonicSelectableMessageTemplateDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: IonicSelectableMessageTemplateDirective, selectors: [["", "ionicSelectableMessageTemplate", ""]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IonicSelectableMessageTemplateDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
        args: [{
                selector: '[ionicSelectableMessageTemplate]'
            }]
    }], null, null); })();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9uaWMtc2VsZWN0YWJsZS1tZXNzYWdlLXRlbXBsYXRlLmRpcmVjdGl2ZS5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9jb21wb25lbnRzL2lvbmljLXNlbGVjdGFibGUvaW9uaWMtc2VsZWN0YWJsZS1tZXNzYWdlLXRlbXBsYXRlLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQUsxQyxNQUFNLE9BQU8sdUNBQXVDO0FBQUc7bUVBSHRELFNBQVMsU0FBQyxrQkFDVCxRQUFRLEVBQUUsa0NBQWtDLGVBQzdDOzs7Ozs7OzBCQUNJO0FBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW2lvbmljU2VsZWN0YWJsZU1lc3NhZ2VUZW1wbGF0ZV0nLFxufSlcbmV4cG9ydCBjbGFzcyBJb25pY1NlbGVjdGFibGVNZXNzYWdlVGVtcGxhdGVEaXJlY3RpdmUgeyB9XG4iXX0=

/***/ })

}]);
//# sourceMappingURL=patient-patient-module.js.map